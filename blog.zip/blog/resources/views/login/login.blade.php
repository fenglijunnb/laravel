<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="js/jquery.min.js"></script>
</head>
<body>
姓名：<input type="text" name='name' value="lisi"><br/>
密码：<input type="password" name="pwd" value="lisi"><br/>
<input type="button" value="登录" id="btn">

</body>
</html>
<script>
    $(document).ready(function () {
        $("#btn").click(function(){
            var url="loginDo";
            var name=$("[name='name']").val();
            var pwd=$("[name='pwd']").val();
            var id=2;
            $.ajax({
                type:"post",
                data:{name:name,pwd:pwd,id:id},
                dataType:"json",
                url:url,
                success:function (msg) {
                    if(msg.code==1) {
                        alert(msg.msg);
                        window.location.href = "loginIndex";
                    }else{
                        alert(msg.msg);
                    }
                }
            })
        });

    })

</script>