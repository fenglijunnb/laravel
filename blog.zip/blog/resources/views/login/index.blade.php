<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>标签管理-有点</title>
    <link rel="stylesheet" type="text/css" href="../css/css.css" />
    <script type="text/javascript" src="../js/jquery.min.js"></script>
    <!-- <script type="text/javascript" src="js/page.js" ></script> -->
</head>

<body>
<div id="pageAll">
    <div class="pageTop">
        <div class="page">
            <img src="img/coin02.png" /><span><a href="#">首页</a>&nbsp;-&nbsp;<a
                        href="#">管理</a>&nbsp;-</span>&nbsp;管理
        </div>
    </div>
    <div class="add">
        <a class="addA" href="add">上传&nbsp;&nbsp;+</a>
    </div>
    <div class="page">
        <!-- balance页面样式 -->
        <div class="connoisseur">
            <div class="conShow">
                <table border=1 style="float:left;margin-right:50px;width: 100%">
                    <thead>
                    <tr>
                        <td>id</td>
                        <td>name</td>
                        <td>price</td>
                    </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
            <div class="bbD">
                <p class="bbDP">
                    <button class="btn_ok btn_yes" href="javascript:;">开始</button>
                    <a class="btn_ok btn_no" href="javascript:;">结束</a>
                    <a class="btn_ok btn_no"  id="clear" href="javascript:;">清空</a>
                </p>
            </div>
            <!-- balance 表格 显示 end-->
        </div>
        <!-- balance页面样式end -->
    </div>

</div>

</body>
</html>
<script src="js/jquery-1.7.2.min.js"></script>
<script>
    $(function(){
        //开始

        var Interval=null;
        $(".btn_yes").click(function(){
            $.post('getInfo','',function(res){
                var goods=res;
                var page=1;
                clearInterval(Interval);
                Interval=setInterval(function(){
                    $.post('quInfo',{str:goods},function(res){
                        var str="";
                        $.each(res,function(i,v){
                            str+="<tr>" +
                                "<td>"+v['goods_id']+"</td>" +
                                "<td>"+v['goods_name']+"</td>" +
                                "<td>"+v['goods_price']+"</td>" +
                                "</tr>";
                        });
                        if($("tbody").find('tr').length==0){
                            $("tbody").append(str);
                        }else{
                            $("tbody").find('tr').last().after(str);
                        }
                    },'json');
                    page++;
                },10000);
            },'json');
        });
        //结束
        $(".btn_no").click(function(){
            clearInterval(Interval);
        });
        $("#clear").click(function(){
            $("tbody").empty();
        });
    })

</script>
