<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        .paywrapp{
            margin-left: 520px;
        }
    </style>
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="css/cartlist.css">
    <link rel="stylesheet" href="layui/css/layui.css">
</head>
<body>

<div class="paywrapp">
    <span class="lip">请扫描微信二维码</span>
    {{--<span class="title">潮人购充值</span>--}}
    {{--<span class="money">￥<i>1.00</i></span>--}}
    <form action="" method="post" name="payPassword" id="form_paypsw">
        <div id="payPassword_container" class="alieditContainer clearfix" data-busy="0">
            <div class="i-block" data-error="i_error">
                <div id="qrcode" class="qrcode">
                </div>
            </div>
        </div>
    </form>
    <div class="submit">
        <a href="payment" class="button  cancel">取消</a>
        <a href="index"  class="button">返回</a>
    </div>
</div>
</body>
</html>
<script src="js/jquery.min.js"></script>
<script src="js/qrcode.min.js"></script>
<script>
    // new QRCode(document.getElementById('qrcode'), 'your content');

    // 设置参数方式
    var qrcode = new QRCode('qrcode', {
        text: '{{$url}}',
        width: 256,
        height: 256,
        colorDark : '#000000',
        colorLight : '#ffffff',
        correctLevel : QRCode.CorrectLevel.H
    });

    // 使用 API
    // qrcode.clear();
    // qrcode.makeCode('new content');




</script>
