<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>商品详情</title>
    <meta content="app-id=984819816" name="apple-itunes-app" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta content="telephone=no" name="format-detection" />
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link href="css/goods.css" rel="stylesheet" type="text/css" />
     <link rel="stylesheet" href="css/idangerous.swiper.css">
</head>
<body fnav="2" class="g-acc-bg">
        
<!--触屏版内页头部-->
<div class="m-block-header" id="div-header" style="display: none">
    <strong id="m-title"></strong>
    <a href="javascript:history.back();" class="m-back-arrow"><i class="m-public-icon"></i></a>
    <a href="/" class="m-index-icon"><i class="m-public-icon"></i></a>
</div>

        <!-- 焦点图 -->
        <div class="hotimg-wrapper">
            <div class="hotimg-top"></div>
            <section id="sliderBox" class="hotimg">
                <ul class="slides" style="width: 600%; transition-duration: 0.4s; transform: translate3d(-828px, 0px, 0px);">
                    <li style="width: 414px; float: left; display: block;" class="clone">
                        <a href="http://weixin.1yyg.com/v27/products/23559.do?pf=weixin">
                            <img src="https://img.1yyg.net/Poster/20170227170302909.png" alt="">
                        </a>
                    </li>
                    <li class="" style="width: 414px; float: left; display: block;">
                        <a href="http://weixin.1yyg.com/v40/GoodsSearch.do?q=%E5%B0%8F%E7%B1%B36&amp;pf=weixin">
                            <img src="https://img.1yyg.net/Poster/20170609151005929.jpg" alt="">
                        </a>
                    </li>
                    <li style="width: 414px; float: left; display: block;" class="flex-active-slide">
                        <a href="http://weixin.1yyg.com/v40/GoodsSearch.do?q=%E6%B8%85%E5%87%89%E4%B8%80%E5%A4%8F&amp;pf=weixin"><img src="https://img.1yyg.net/Poster/20170605084728556.jpg" alt="">
                        </a>
                    </li>
                    <li style="width: 414px; float: left; display: block;" class="">
                        <a href="http://weixin.1yyg.com/v40/GoodsSearch.do?q=%E6%96%B0%E9%B2%9C%E6%B0%B4%E6%9E%9C&amp;pf=weixin"><img src="https://img.1yyg.net/Poster/20170518163741543.jpg" alt=""></a>
                    </li>
                    <li style="width: 414px; float: left; display: block;" class="">
                        <a href="http://weixin.1yyg.com/v27/products/23559.do?pf=weixin">
                            <img src="https://img.1yyg.net/Poster/20170227170302909.png" alt="">
                        </a>
                    </li>
                    <li class="clone" style="width: 414px; float: left; display: block;">
                        <a href="http://weixin.1yyg.com/v40/GoodsSearch.do?q=%E5%B0%8F%E7%B1%B36&amp;pf=weixin">
                            <img src="https://img.1yyg.net/Poster/20170609151005929.jpg" alt="">
                        </a>
                    </li>
                </ul>
            </section>
        </div>
        <!-- 产品信息 -->
        <div class="pro_info">
            <h2 class="gray6">
                
                (第<em id='Period'>10363</em>云)
                小米（MIUI）红米Note 4 32GB 全网通 4G手机<span>十核处理器，4100mAh电池，千元旗舰新标杆！（颜色随机发）</span>
            </h2>
            <div class="purchase-txt gray9 clearfix">
                价值：￥1099.00
            </div>
            <div class="clearfix">
                
                <div class="gRate">
                    
                </div>
            </div>
            <!--本商品已结束-->
            
        </div>
        <!--揭晓倒计时-->
        <div id="divLotteryTime" class="Countdown-con">
            <div class="g-Countdown">
                <p class="orange">已满员，揭晓结果即将公布</p>
                <div>
                    <cite class="clearfix time-wrapper" value="1500631200">
                        <em>00</em>
                        <span>:</span>
                        <em>00</em>
                        <span>:</span>
                        <em>00</em>
                    </cite>
                </div>
            </div>
            <p class="declare">声明：所有商品及活动均与苹果公司（Apple Inc）无关。</p>
            <div class="state">
            	<em></em>
            	<span>我已阅读《潮购声明》</span>
            </div>
            <div class="guide">您还没有参与哦，试试吧！</div>
        </div>
        <div class="imgdetail">
        	<div class="ann_btn">
        		<a href="">图文详情<s class="fr"></s></a>
        	</div>
        </div>
        <div class="listtab clearfix	">
        	<a href="javascript:;" class="active">参与记录</a>
        	<a href="javascript:;">历史获得者</a>
        </div>

      

        <div class="swiper-container">
        	<div class="swiper-wrapper clearfix">
        		<div class="swiper-slide">
        			<div class="ann_btn part-record">
			            <!--所有参与记录-->
			            <div class="ann_list">
			            	<div class="fl">
			            		<img src="images/goods2.jpg" alt="">
			            	</div>
			            	<div class="fl">
			            		<h3>被小冉</h3>
			            		<p>2017-06-25 15:38:12:645</p>
			            	</div>
			            	<div class="fr people-num">
			            		<span>16人次</span><s class="fr"></s>
			            	</div>
			            </div>	
			            <div class="ann_list">
			            	<div class="fl">
			            		<img src="images/goods2.jpg" alt="">
			            	</div>
			            	<div class="fl">
			            		<h3>被小冉</h3>
			            		<p>2017-06-25 15:38:12:645</p>
			            	</div>
			            	<div class="fr people-num">
			            		<span>16人次</span><s class="fr"></s>
			            	</div>
			            </div>		
			            <div class="ann_list">
			            	<div class="fl">
			            		<img src="images/goods2.jpg" alt="">
			            	</div>
			            	<div class="fl">
			            		<h3>被小冉</h3>
			            		<p>2017-06-25 15:38:12:645</p>
			            	</div>
			            	<div class="fr people-num">
			            		<span>16人次</span><s class="fr"></s>
			            	</div>
			            </div>	
			           <div class="ann_list">
			            	<div class="fl">
			            		<img src="images/goods2.jpg" alt="">
			            	</div>
			            	<div class="fl">
			            		<h3>被小冉</h3>
			            		<p>2017-06-25 15:38:12:645</p>
			            	</div>
			            	<div class="fr people-num">
			            		<span>16人次</span><s class="fr"></s>
			            	</div>
			            </div>		    
			        </div>
        		</div>
        		<div class="swiper-slide">
        			<div class="history-win">
			            <div class="win-list clearfix">
			                <div class="win-left fl">
			                    <p class="chao">第2779潮购</p>
			                    <img src="images/goods2.jpg" alt="">
			                </div>
			                <div class="win-right fl">
			                    <p class="show-time">揭晓时间:2017-06-28 15:16:46:000</p>
			                    <p class="winner">获得者：<i>穿越狂信者</i></p>
			                    <p class="show-count">本潮购参与：1480人次</p>
			                    <p class="show-code">幸运潮购码：10003664</p>
			                </div>
			            </div>
			            <div class="win-list clearfix">
			                <div class="win-left fl">
			                    <p class="chao">第2779潮购</p>
			                    <img src="images/goods2.jpg" alt="">
			                </div>
			                <div class="win-right fl">
			                    <p class="show-time">揭晓时间: <i>2017-06-28 15:16:46:000</i></p>
			                    <p class="winner">获得者：<i>穿越狂信者</i></p>
			                    <p class="show-count">本潮购参与：<i>1480</i>人次</p>
			                    <p class="show-code">幸运潮购码：<i>10003664</i></p>
			                </div>
			            </div>
			            <div class="win-list clearfix">
			                <div class="win-left fl">
			                    <p class="chao">第2779潮购</p>
			                    <img src="images/goods2.jpg" alt="">
			                </div>
			                <div class="win-right fl">
			                    <p class="show-time">揭晓时间:2017-06-28 15:16:46:000</p>
			                    <p class="winner">获得者：<i>穿越狂信者</i></p>
			                    <p class="show-count">本潮购参与：1480人次</p>
			                    <p class="show-code">幸运潮购码：10003664</p>
			                </div>
			            </div>
			            <div class="win-list clearfix">
			                <div class="win-left fl">
			                    <p class="chao">第2779潮购</p>
			                    <img src="images/goods2.jpg" alt="">
			                </div>
			                <div class="win-right fl">
			                    <p class="show-time">揭晓时间: <i>2017-06-28 15:16:46:000</i></p>
			                    <p class="winner">获得者：<i>穿越狂信者</i></p>
			                    <p class="show-count">本潮购参与：<i>1480</i>人次</p>
			                    <p class="show-code">幸运潮购码：<i>10003664</i></p>
			                </div>
			            </div>
			        </div>
        		</div>   
        	</div>
        </div>
        <div class="pro_foot"> 
        		<a href="" class="">第10364云正在进行中<span class="dotting"></span></a>
        		<a href="" class="shopping">立即参与</a>         
        </div>
    </div>
<div class="footer clearfix">
    <ul>
		<li class="f_home"><a href="index" ><i></i>潮购</a></li>
		<li class="f_announced"><a href="allshops" ><i></i>所有商品</a></li>
		<li class="f_single"><a href="willshow" class="hover"><i></i>最新揭晓</a></li>
		<li class="f_car"><a id="btnCart" href="cart" ><i></i>购物车</a></li>
		<li class="f_personal"><a href="/userpage" ><i></i>我的潮购</a></li>
    </ul>
</div>

 <script src="js/jquery-1.11.2.min.js"></script>
 <script src="js/idangerous.swiper.min.js"></script>
 <script src="http://cdn.bootcss.com/flexslider/2.6.2/jquery.flexslider.min.js"></script>
<script>
    $(function () {  
        $('.hotimg').flexslider({   
            directionNav: false,   //是否显示左右控制按钮   
            controlNav: true,   //是否显示底部切换按钮   
            pauseOnAction: false,  //手动切换后是否继续自动轮播,继续(false),停止(true),默认true   
            animation: 'slide',   //淡入淡出(fade)或滑动(slide),默认fade
            slideshowSpeed: 3000,  //自动轮播间隔时间(毫秒),默认5000ms
            animationSpeed: 150,   //轮播效果切换时间,默认600ms   
            direction: 'horizontal',  //设置滑动方向:左右horizontal或者上下vertical,需设置animation: "slide",默认horizontal   
            randomize: false,   //是否随机幻切换   
            animationLoop: true   //是否循环滚动  
        });  
        setTimeout($('.flexslider img').fadeIn()); 
    }); 
</script>
<script type="text/javascript">
	  var tabsSwiper = new Swiper('.swiper-container',{
	    loop: true,
		autoplay:false,
		calculateHeight:true,
		calculateWidth:true,
		onSlideChangeStart: function(){
	      $(".tabs .active").removeClass('active')
	      $(".tabs a").eq(tabsSwiper.activeIndex).addClass('active')
	    }
	  });  

	  $(".listtab a").on('touchstart mousedown',function(e){
	    e.preventDefault()
	    $(".listtab .active").removeClass('active')
	    $(this).addClass('active')
	    tabsSwiper.swipeTo( $(this).index() )
	  })
	  $(".listtab a").click(function(e){
	    e.preventDefault()
	  })
</script>
<!-- <script src="js/all.js"></script> -->
</body>
</html>
