<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class  GoodsModel extends Model
{
    protected $table = 'goods';
    public $timestamps = false;
}
