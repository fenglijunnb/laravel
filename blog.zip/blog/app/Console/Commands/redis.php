<?php

namespace App\Console\Commands;

use http\Env\Request;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use App\models\GoodsModel;
class redis extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'redis';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '历史记录';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
//        //
//        $user_id=Cache::get("user_id");
//        $redis=new \Redis();
//        $redis->connect('127.0.0.1',6379);
//        $id=$redis->incr('id');
//        $key="$user_id";
//        $hkey="$user_id"."_$id";
//        $arr=$redis->lRange("$user_id"."_list",0,-1);
//        foreach($arr as $v){
//            $data[]=$redis->hGetAll($v);
//        }
//        $res=DB::table('history')->insert($data);
//        $redis->del($key);
        $redis = new \redis;
        $redis->connect('127.0.0.1',6379);
        $data=GoodsModel::where('goods_show',1)->get()->toarray();
        $arr = json_encode($data);
        $str = "goods";
        $redis = new \redis;
        $redis->connect('127.0.0.1',6379);
        $private_key = "/tmp/rsa_private_key.pem";
        $privatekey=file_get_contents($private_key);
        $encryptData="";
        openssl_private_encrypt($str,$encryptData,$privatekey);
        $content = base64_encode($encryptData);
        $redis->set('goods',$arr);
    }
}
