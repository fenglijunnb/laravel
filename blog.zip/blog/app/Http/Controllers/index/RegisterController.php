<?php

namespace App\Http\Controllers\index;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Cache;
use App\models\User;

class RegisterController extends Controller
{
    /**
     * 注册展示页面
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    public function register(){
        return view('index.register');
    }

    /**
     * 注册执行页面
     * @param Request $request
     */
    public function register_do(Request $request){
        $arr=$request->input();
        $tel=$arr['tel'];
        $pwd=$arr['pwd'];
        $code=$arr['userCode'];
        $conpwd=$arr['conpwd'];
        //验证密码
        if($pwd!=$conpwd){
//            echo 1111;
            $arr=array(
                'code'=>0,
                'msg'=>'俩次密码不一致'
            );
            echo json_encode($arr);
        }
        //验证 唯一
        $name=User::where('name',$tel)->first();
        if(!empty($name)&&!empty($name['pwd'])){
            $arr=array(
                'code'=>0,
                'msg'=>'手机号已经存在'
            );
            echo json_encode($arr);
        }
        //验证验证码
        $code_info=DB::table('code')->where('tel',$tel)->where('status',1)->orderBy('c_id','desc')->first();
        if(empty($code_info)){
            echo json_encode(['code'=>0,'msg'=>'请输入收取验证码的手机号！']);die;
        }
        if(time()>$code_info->timeout){
            echo json_encode(['code'=>0,'msg'=>'您的验证码过期！']);die;
        }
        if($code!=$code_info->code){
            echo json_encode(['code'=>0,'msg'=>'您的验证码有误！']);die;
        }
        $pwd=md5($pwd);
       $arrInfo=array(
           'name'=>$tel,
           'pwd'=>$pwd
       );
       $res=DB::table('user')->insert($arrInfo);
       if($res){
           $arr=array(
               'code'=>1,
               'msg'=>'注册成功'
           );
           echo json_encode($arr);
           $id=$code_info->c_id;
           DB::table('code')->where('c_id',$id)->update(['status'=>0]);
       }else{
           $arr=array(
               'code'=>0,
               'msg'=>'注册失败'
           );
           echo json_encode($arr);
       }
    }

    /**
     * 登录页面
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    public function login(){
        $newurl = urlencode("http://47.107.93.29/token");
        $appid="wx20f1b2d5677b24f8";
        $scope="snsapi_userinfo";
        $url="https://open.weixin.qq.com/connect/oauth2/authorize?appid=$appid&redirect_uri=$newurl&response_type=code&scope=$scope&state=STATE#wechat_redirect";
        return view('index.login',['url'=>$url]);
    }

    /**
     * 登录执行页面
     * @param Request $request
     */
    public function login_do(Request $request){
        $arr=$request->input();
        $tel=$arr['tel'];
        $pwd=$arr['pwd'];
        $pwd=md5($pwd);
        $where=[
            'name'=>$tel,
            'pwd'=>$pwd
            ];
        $data=DB::table('user')->where($where)->first();
        if(empty($pwd)||empty($tel)){
            $arr=array(
                'code'=>0,
                'msg'=>'参数错误'
            );
            echo json_encode($arr);
        }
        if($data){
            $id=$data->user_id;
            $openid=$data->openid;
            $time="86400";
            Cache::put('openid', $openid, $time);
            $name=$data->name;
            Cache::put('user_id',$id,$time);
            Cache::put('name', $name, $time);
            session(['u_id'=>$id,'name'=>$name]);
            if(empty($openid)){
                $arr=array(
                    'code'=>1,
                    'msg'=>'登录成功'
                );
                echo json_encode($arr);
            }else{
                $access_token=Cache::get("accessToken");
                $json=[
                    'touser'=>$openid,
                    "template_id"=>"oH9NZqcxFfKP0ZAs6GTImyTVcWHAnrNUaExC17KstHA",
                    "data"=>[
                        'info'=>[
                            'value'=>"恭喜用户你：",
                            'color'=>'#f00'
                        ],
                        'name'=>[
                            'value'=>$name,
                            'color'=>'#f00'
                        ]
                    ]
                ];
                $url="https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=$access_token";
                $json=json_encode($json,256);
                $obj=new \curl();
                $res=$obj->sendPost($url,$json);
                $res=json_decode($res,true);
                    if($res['errcode']==0){
                        echo json_encode(['code'=>1,'msg'=>'登录成功！']);
                    }else{
                        echo json_encode(['code'=>0,'msg'=>'发生错误！']);
                    }
            }
        }else{
            $arr=array(
                'code'=>0,
                'msg'=>'账号或密码错误'
            );
            echo json_encode($arr);
        }
    }

    /**
     * 发送短信的方法
     * @param Request $request
     */
    public function send(Request $request){
        $arr=$request->input();
        $num = rand(1000,9999);
//        dump($arr);exit;
        $tel=$arr['tel'];
        $obj=new \send();
        $code=$obj->show($tel,$num);
//        print_r($code);die;
        if($code==100){
            $data=[
                'code'=>$num,
                'tel'=>$tel,
                'status'=>1,
                'timeout'=>time()+60*60
            ];
            $res=DB::table('code')->insert($data);
            $arr=array(
                'code'=>1,
                'msg'=>'短信发送成功'
            );
            echo json_encode($arr);
        }else{
            $arr=array(
                'code'=>0,
                'msg'=>'短信发送失败'
            );
            echo json_encode($arr);
        }
    }

    //获取oppenid
    public function token(Request $request){
        $u_id=$request->session()->get('u_id');
        $arr = $request->input();
        $code = $arr['code'];
        $appid = "wx20f1b2d5677b24f8";
        $appkey = "a4850c255fb9dd90f3ba77fa1a4134a0";
        $access="https://api.weixin.qq.com/sns/oauth2/access_token?appid=$appid&secret=$appkey&code=$code&grant_type=authorization_code";
        $info=file_get_contents($access);
        $arr = json_decode($info,true);
        $openid=$arr['openid'];
        $arrUser=DB::table('user')->where('openid',$openid)->first();
        if(!empty($arrUser)){
            $user_id=$arrUser->user_id;
            $user_tel=$arrUser->name;
            session(['u_id'=>$user_id,'name'=>$user_tel,'openid'=>$openid]);
            $data=[
                'name'=>$user_tel,
                'openid'=>$openid
            ];
            $this->cachesend($data);
            echo "已经绑定了微信，请换取微信";die;
        }else{
            $url=$request->session()->get('url');
            $u_id=$request->session()->get('u_id');
            $name=$request->session()->get('name');
            $arr=array(
                'user_id'=>$u_id,
                'name'=>$name
            );
            $user=DB::table('user')->where('user_id',$u_id)->update(['openid'=>$openid]);
            return view('index.userpage',['url'=>$url,'arr'=>$arr]);
        }
    }
    //储存redis
    public function cachesend($data)
    {
        $objredis=new \redis();
        $objredis->connect("127.0.0.1",6379);
        $redisid=$objredis->incr('id');
        $objredis->hmset("login_$redisid",[
            "name" => $data['name'],
            'openid' => $data['openid'],
            'createtime' => time()
        ]);
        $key='login';
        $objredis->lPush($key,"login_$redisid");
    }


    public function accessToken(){
//        Cache::flush();
        $appID="wx20f1b2d5677b24f8";
        $appsecret="a4850c255fb9dd90f3ba77fa1a4134a0";
        $url="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appID&secret=$appsecret";
        $obj=new \curl();
        $info=$obj->sendGet($url);
        $arrInfo=json_decode($info,true);
        $access=$arrInfo['access_token'];
        $time=$arrInfo['expires_in'];
        Cache::put('accessToken', $access, $time);
        return $arrInfo;
    }
}
