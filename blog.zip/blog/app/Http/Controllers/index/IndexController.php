<?php

namespace App\Http\Controllers\index;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Cache;
class IndexController extends Controller
{
    public static $arrCate=[];
    //潮购主页
    public function index(Request $request){
        $num=6;
        $arr=DB::table('goods')->where('goods_show',1)->where('is_like',1)->paginate($num);
        if($request->ajax()){
            return view('index.ajaxIndex',['arr'=>$arr]);
        }else{
            $count=DB::table('goods')->where('goods_show',1)->count();
            $page=ceil($count/6);
            $data=DB::table('goods')->where(['goods_show'=>1,'is_tell'=>1])->paginate(2);
            return view('index.index',['arr'=>$arr,'data'=>$data,'page'=>$page]);
        }
    }
    //我的潮购
    public function userpage(Request $request){
        $user_id=$request->session()->get('u_id');
        $name=$request->session()->get('name');
        $newurl = urlencode("http://47.107.93.29/token");
        $appid="wx20f1b2d5677b24f8";
        $scope="snsapi_userinfo";
        $url="https://open.weixin.qq.com/connect/oauth2/authorize?appid=$appid&redirect_uri=$newurl&response_type=code&scope=$scope&state=STATE#wechat_redirect";
        if(!empty($user_id)){
            $arr=array(
                'user_id'=>$user_id,
                'name'=>$name
            );
        }else{
            $arr=array();
        }
        session(['url'=>$url]);
        return view('index.userpage',['arr'=>$arr,'url'=>$url]);
    }
    //潮购记录
    public function buyrecord(Request $request){
        $user_id=$request->session()->get('u_id');
        $data=DB::table('order_info')->where('user_id',$user_id)->get();
//        dump($data);
        foreach ($data as $k=>$v){
            if($v->order_pay_type==1){
                $data[$k]->order_pay_type='线上支付';
            }else{
                $data[$k]->order_pay_type='货到付款';
            }
            if($v->pay_status==1){
                $data[$k]->pay_status='未支付';
            }else{
                $data[$k]->pay_status='已支付';
            }
            if($v->pay_id==1){
                $data[$k]->pay_id='支付宝';
            }else if($v->pay_id==2){
                $data[$k]->pay_id='微信';
            }else if($v->pay_id==3){
                $data[$k]->pay_id='网银';
            }else if($v->pay_id==4){
                $data[$k]->pay_id='网银支付';
            }else if($v->pay_id==5){
                $data[$k]->pay_id='货到付款';
            }
            if($v->order_status==1){
                $data[$k]->order_status='未支付';
            }else if($v->order_status==2){
                $data[$k]->order_status='已支付';
            }else if($v->order_status==3){
                $data[$k]->order_status='已确认';
            }else if($v->order_status==4){
                $data[$k]->order_status='备货中';
            }else if($v->order_status==5){
                $data[$k]->order_status='发货中';
            }else if($v->order_status==6){
                $data[$k]->order_status='已发货';
            }else if($v->order_status==7){
                $data[$k]->order_status='订单完成';
            }
        }
        $ishot=[
            'goods_hot'=>1
        ];
        $goodshot=DB::table('goods')->where($ishot)->paginate(4);
        return view("index.buyrecord",['data'=>$data,'goodshot'=>$goodshot]);
    }

    /**
     * 个人中心
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    public function userprofile(Request $request){
        $user_id=$user_id=$request->session()->get('u_id');
        if(empty($user_id)){
            echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
        }
        $arr=DB::table('order_info')->where('order_info.user_id',$user_id)->get();
        foreach ($arr as $v){
            $v->add_time=date('Y-m-d H:i:s',$v->add_time);
            if($v->pay_status==1){
                $v->pay_status="未支付";
            }else{
                $v->pay_status="已支付";
            }
        }
//        dump($arr);
        return view('index.userprofile',['arr'=>$arr]);
    }

    //设置页面
    public function set(){
        return view('index.set');
    }
    //所有商品
    public function allshops(Request $request){
        $num=6;
        //获取分类id
        $cate_id=$request->input('cate_id');
//        echo $cate_id;die;
        if(!empty($cate_id)){
            $arrIds=DB::table('category')->select('cate_id')->where('pid',0)->get();
            $this->get($cate_id);
        }
       $cate_id=self::$arrCate;
        //获取搜索信息
        $search=$request->input('search','');
        $where=[
            'goods_show'=>1
        ];
        //点击排序
        $order=$request->input('order','goods_id');
        $order_type=$request->input('order_type','asc');
        if($order=='goods_hot'||$order=='goods_new'){
            $where[$order]=1;
        }
        if(!empty($cate_id)){
            //查询分类下的商品
            $goods_info=DB::table('goods')->where($where)
                ->whereIn('cate_id',$cate_id)
                ->where('goods_name','like',"%$search%")
                ->orderBy($order,$order_type)
                ->paginate($num);

        }else{
            //查询所有商品
            $goods_info=DB::table('goods')->where($where)
                ->where('goods_name','like',"%$search%")
                ->orderBy($order,$order_type)
                ->paginate($num);
        }
//        echo 111;die;
        if($request->ajax()){
            return view('index.ajaxGoods',['goods_info'=>$goods_info]);
        }else{
            $cate_info=DB::table('category')->where('pid',0)->get();
            return view('index.allshops',['cate_info'=>$cate_info,'goods_info'=>$goods_info]);
        }
    }
    /**
     * 获取分类的id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    private  function get($id){
            $arrIds=DB::table('category')->select('cate_id')->where('pid',$id)->get();
            if(count($arrIds)!=0){
                foreach($arrIds as $k=>$v){
                    $cateId=$v->cate_id;
                    $arrNews=$this->get($cateId);
                }
            }
            foreach($arrIds as $v){
                $cate_id=$v->cate_id;
                array_push(self::$arrCate,$cate_id);
            }
        }

    /**
     * 条数
     * @param Request $request
     * @return float
     */
    public function shopCount(Request $request){
        $num=6;
        //获取分类id
        $cate_id=$request->input('cate_id');
        if(!empty($cate_id)){
            $arrIds=DB::table('category')->select('cate_id')->where('pid',0)->get();
            $this->get($cate_id);
        }
        $cate_id=self::$arrCate;
        //获取搜索信息
        $search=$request->input('search','');
        $where=[
            'goods_show'=>1
        ];
        //点击排序
        $order=$request->input('order','goods_id');
        $order_type=$request->input('order_type','asc');
        if($order=='goods_hot'||$order=='goods_new'){
            $where[$order]=1;
        }
        if(!empty($cate_id)){
            //查询分类下的商品
            $count=DB::table('goods')->where($where)
                ->whereIn('cate_id',$cate_id)
                ->where('goods_name','like',"%$search%")
                ->orderBy($order,$order_type)
                ->count();
        }else{
            //查询所有商品
            $count=DB::table('goods')->where($where)
                ->where('goods_name','like',"%$search%")
                ->orderBy($order,$order_type)
                ->count();
        }
        $page=ceil($count/$num);
        echo $page;
        return $page;
    }
    //最新揭晓
    public function willshow(){
        return view('index.willshow');
    }
    //退出
    public function out(Request $request){
        session(['u_id'=>null,'name'=>null]);
        $usersession=$request->session()->get('u_id');
        if(empty($usersession)){
            echo json_encode(['code'=>0,'msg'=>'退出成功']);
        }
    }
    //支付宝同步
    public function true(Request $request){
        $data=DB::table('cart')->join('goods','goods.goods_id','=','cart.goods_id')->where('status',1)->select("*")->get();
        $goods_info=DB::table('goods')->where('goods_hot',1)->limit(4)->select('goods_img','goods_price','goods_name','goods_id')->get();
        return view('index.paysuccess',['goods_info'=>$goods_info]);
    }
    //支付订单展示
    public function alipayShow(Request $request){
        $order_id=$_REQUEST['order_id'];

        $arr=DB::table('order_info')->where('order_id',$order_id)->get()->toArray()[0];
        return view('index.show',['arr'=>$arr]);
    }
    //支付执行
    public function addshow(Request $request){
        $arr=$request->input();
        $orderSn=$arr['WIDout_trade_no'];
        $orderName=$arr['WIDsubject'];
        $orderMoney=$arr['WIDtotal_amount'];
        $orderDesc=$arr['WIDbody'];
        $timeout_express="1m";

        $payRequestBuilder=new \AlipayTradeWapPayContentBuilder();
        $payRequestBuilder->setBody($orderDesc);
        $payRequestBuilder->setSubject($orderName);
        $payRequestBuilder->setOutTradeNo($orderSn);
        $payRequestBuilder->setTotalAmount($orderMoney);
        $payRequestBuilder->setTimeExpress($timeout_express);

        $configAll=app_path()."/extend/alipay/config.php";
        $config=require_once($configAll);

        $payResponse = new \AlipayTradeService($config);
        $result=$payResponse->wapPay($payRequestBuilder,$config['return_url'],$config['notify_url']);
    }

    //异步
    public function result(Request $request){
        $arr=$_REQUEST;

        $configAll=app_path()."/extend/alipay/config.php";
//        $add=app_path()."/extend/alipay/wappay/service/AlipayTradeService.php";
//        require_once($add);
        $config=require_once($configAll);
        $alipaySevice = new \AlipayTradeService($config);
        $alipaySevice->writeLog(var_export($_REQUEST,true));
        $result = $alipaySevice->check($arr);

        $str=var_export($result,true);
//        file_put_contents("/tmp/alipay.log",$str,FILE_APPEND);
        if($result) {
            if($_POST['trade_status'] == 'TRADE_FINISHED') {

                //判断该笔订单是否在商户网站中已经做过处理
                //如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
                //请务必判断请求时的total_amount与通知时获取的total_fee为一致的
                //如果有做过处理，不执行商户的业务程序

                //注意：
                //退款日期超过可退款期限后（如三个月可退款），支付宝系统发送该交易状态通知
            }
            else if ($_POST['trade_status'] == 'TRADE_SUCCESS') {
                //判断该笔订单是否在商户网站中已经做过处理
                //如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
                //请务必判断请求时的total_amount与通知时获取的total_fee为一致的
                //如果有做过处理，不执行商户的业务程序
                //注意：
                //付款完成后，支付宝系统发送该交易状态通知
                $order_sn= $arr['out_trade_no'];
                //支付宝交易号
                $trade_no = $arr['trade_no'];
                //交易状态
                $trade_status = $arr['trade_status'];
                $total_amount=$arr['total_amount'];

                $order_info=DB::table('order_info')->where('order_sn',$order_sn)->select('order_amount','order_sn','order_id','order_amount')->first();
                $goods_info=DB::table('order_goods')->where('order_id',$order_info->order_id)->select('goods_id','buy_number','goods_name')->get();
                $goods_name=[];
                foreach($goods_info as $k=>$v){
                    $name=$v->goods_name;
                    array_push($goods_name,$name);
                    $goods_num=DB::table('goods')->where('goods_id',$v->goods_id)->value('goods_pnum');
                    if($v->buy_number<$goods_num){
                        $goods_num=$goods_num-$v->buy_number;
                        $res=DB::table('goods')->where('goods_id',$v->goods_id)->update(['goods_pnum'=>$goods_num]);
                    }else{
                        DB::table('order_info')->where('order_sn',$order_sn)->update(['order_status'=>8]);
                    }
                }
                $data=implode($goods_name,',');
                if($order_sn==$order_info->order_sn&&$total_amount==$order_info->order_amount){
                    $update=['order_pay_type'=>2,'order_status'=>2,'add_time'=>time()];
                    DB::table('order_info')->where('order_sn',$order_sn)->update($update);
                    $access_token=Cache::get("accessToken");
                    $name=Cache::get("name");
                    $openid=Cache::get("openid");
                    $json=[
                        'touser'=>$openid,
                        "template_id"=>"NDOF9C-OTmSUVOWvY3LiXE2-IxrOUFapDamWev8w52I",
                        "data"=>[
                            'name'=>[
                                'value'=>"恭喜用户你："."$name",
                                'color'=>'#f00'
                            ],
                            'info'=>[
                                'value'=>"购买的商品："."$data",
                                'color'=>'#f00'
                            ],
                            'age'=>[
                                'value'=>$order_info->order_amount."支付成功",
                                'color'=>'#f00'
                            ]
                        ]
                    ];
                    $url="https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=$access_token";
                    $json=json_encode($json,256);
                    $obj=new \curl();
                    $res=$obj->sendPost($url,$json);
                }else{
                    DB::table('order_info')->where('order_sn',$order_sn)->update(['order_status'=>8]);
                }

            }
            //——请根据您的业务逻辑来编写程序（以上代码仅作参考）——

            echo "success";		//请不要修改或删除

        }else {
            //验证失败
            echo "fail";	//请不要修改或删除

        }
    }
    public function  check(Request $request){
//        echo $_REQUEST['echostr'];
//        echo $request->input('echostr');
        $str=file_get_contents('php://input');
        $objxml=simplexml_load_string($str);
        $type=$objxml->MsgType;
        if($type=='image'){
//            file_put_contents("/tmp/bb.log",$str,FILE_APPEND);die;
            $arr=array(
                'type'=>$objxml->MsgType,
                'mediaid'=>$objxml->MediaId,
                'createtime'=>$objxml->CreateTime,
            );
            $access=Cache::get('accessToken');
            $url="https://api.weixin.qq.com/cgi-bin/media/get?access_token=$access&media_id=$objxml->MediaId";
            $obj=new \curl();
            $info=$obj->sendGet($url);
            $time=date("YmdHis",time());
            file_put_contents("./picture/$time.jpg",$info,FILE_APPEND);
        }else{
            $arr=array(
                'openid'=>$objxml->FromUserName,
                'type'=>$objxml->MsgType,
                'createtime'=>$objxml->CreateTime,
                'content'=> $objxml->Content
            );
            $redis=new \Redis();
            $redis->connect('127.0.0.1',6379);
            $key="$objxml->FromUserName";
            $id=$redis->incr($key);
            $hkey="$objxml->FromUserName"."_$id";
            $res=$redis->rPush("$key"."_list",$hkey);
            $redis->hSet($hkey,'id',$id);
            $redis->hSet($hkey,'openid',$key);
            $redis->hSet($hkey,'content',"$objxml->Content");
            $redis->hSet($hkey,'time',"$objxml->CreateTime");
            $redis->hSet($hkey,'status',1);
        }

//        $time=time();
//        if($objxml->Event=='SCAN'){
//            $str="<xml>
//                      <ToUserName><![CDATA[$objxml->FromUserName]]></ToUserName>
//                        <FromUserName><![CDATA[$objxml->ToUserName]]></FromUserName>
//                          <CreateTime><![CDATA[$time]]>/CreateTime>
//                            <MsgType><![CDATA[text]]></MsgType>
//                              <Content><![CDATA[$arr[event]]]></Content>
//                              </xml>";
//            echo $str;
//        }
//        $redis=new \Redis();
//        $redis->connect('127.0.0.1',6379);
//        $res=$redis->zAdd('code2',"id","$arr[openid]"."$arr[type]");
//        if($res==1) {
//            $code_id=$redis->incr('code_id');
//            $key="code_".$code_id;
//            $redis->hset("$arr[openid]"."$arr[type]",'id',"$code_id");
//            $redis->hset("$arr[openid]"."$arr[type]",'openid',"$arr[openid]");
//            $redis->hset("$arr[openid]"."$arr[type]",'type',"$arr[type]");
//            $redis->hset("$arr[openid]"."$arr[type]",'time',"$arr[createtime]");
//        }
    }
}
