<?php

namespace App\Http\Controllers\pay;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class PayController extends Controller
{
    //生成微信支付
    public function weCat(Request $request){
        $user_id=session('u_id');
        if(empty($user_id)){
            echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
        }
        $order_id=$request->input('order_id');
        $data=DB::table('order_info')->where('order_id',$order_id)->select('order_sn','order_amount')->get()->toArray()[0];
        $orderId=$data->order_sn;
        $order_amount=ceil($data->order_amount);
        $url="https://api.mch.weixin.qq.com/pay/unifiedorder";
        $str=md5(time());
        $key="7c4a8d09ca3762af61e59520943AB26Q";
//        $orderId=date("YmdHis",rand(1000000000,9999999999));
        $ip=$_SERVER['REMOTE_ADDR'];
        $notify_url="http://47.107.93.29/wePay";
        $arr=array(
            'appid'=>"wxd5af665b240b75d4",
            'mch_id'=>"1500086022",
            'nonce_str'=>$str,
            'sign_type'=>"MD5",
            'body'=>'微信支付',
            'out_trade_no'=>$orderId,
            'total_fee'=>1,
            'spbill_create_ip'=>$ip,
            'notify_url'=>$notify_url,
            'trade_type'=>'NATIVE',
        );
        //签名算法NATIVE
        ksort($arr);
        $sign_str=urldecode(http_build_query($arr));
        $sign_str.="&key=$key";
        $endstr=md5($sign_str);
        $arr['sign']=$endstr;
        $obj=new \curl();
        $xml=$obj->arr2xml($arr);
        //调用接口
        $info=$obj->sendPost($url,$xml);
        $objxml=simplexml_load_string($info);
        $url=$objxml->code_url;
        return view('pay.pay',['url'=>$url]);
    }
    public function wePay(Request $request){
        $xml=file_get_contents("php://input");
        $arr=json_decode(json_encode(simplexml_load_string($xml,'SimpleXMLElement',LIBXML_NOCDATA)),true);
//        file_put_contents("/tmp/aaa.log",var_export($arr,true),FILE_APPEND);
        $sign=$arr['sign'];
//        $sign="weixin:$sign\n";
        unset($arr['sign']);
        $newstr=$this->checkSign($arr);
        $newStr=strtoupper($newstr);
//        $newstr="localhost:{$newStr}\n";
        $newstr=$newStr;
        if($sign==$newstr){
            $order_sn=$arr['out_trade_no'];
            $order_info=DB::table('order_info')->where('order_sn',$order_sn)->select('order_sn','order_id','order_amount')->first();
            $order_amount=$order_info->order_amount;
            $goods_info=DB::table('order_goods')->where('order_id',$order_info->order_id)->select('goods_id','buy_number','goods_name')->get();
            $goods_name=[];
            foreach($goods_info as $k=>$v){
                $name=$v->goods_name;
                array_push($goods_name,$name);
                $goods_num=DB::table('goods')->where('goods_id',$v->goods_id)->value('goods_pnum');
                if($v->buy_number<$goods_num){
                    $goods_num=$goods_num-$v->buy_number;
                    $res=DB::table('goods')->where('goods_id',$v->goods_id)->update(['goods_pnum'=>$goods_num]);
                }else{
                    DB::table('order_info')->where('order_sn',$order_sn)->update(['order_status'=>8]);
                }
            }
            $data=implode($goods_name,',');
            if($order_sn==$order_info->order_sn){
                $update=['order_pay_type'=>3,'order_status'=>2];
                $res= DB::table('order_info')->where('order_sn',$order_sn)->update($update);
                if($res){
                    $name=Cache::get("name");
                    $access_token=Cache::get("accessToken");
                    $openid=Cache::get("openid");
                    $json=[
                        'touser'=>$openid,
                        "template_id"=>"NDOF9C-OTmSUVOWvY3LiXE2-IxrOUFapDamWev8w52I",
                        "data"=>[
                            'name'=>[
                                'value'=>"恭喜用户你：".$name,
                                'color'=>'#f00'
                            ],
                            'info'=>[
                                'value'=>"购买的商品：".$data,
                                'color'=>'#f00'
                            ],
                            'age'=>[
                                'value'=>"总共支付：".$order_info->order_amount."元",
                                'color'=>'#f00'
                            ]
                        ]
                    ];
                    $url="https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=$access_token";
                    $json=json_encode($json,256);
                    $obj=new \curl();
                    $obj->sendPost($url,$json);
                }
            }else{
                DB::table('order_info')->where('order_sn',$order_sn)->update(['order_status'=>8]);
            }
        }
//        file_put_contents("/tmp/sign.log",$sign,FILE_APPEND);
//        file_put_contents("/tmp/sign.log",$newstr,FILE_APPEND);
    }
    private function checkSign($arr){
        ksort($arr);
        $key="7c4a8d09ca3762af61e59520943AB26Q";
        $strParams=urldecode(http_build_query($arr));
        $strParams.="&key=$key";
        $endstr=md5($strParams);
        return $endstr;
    }
}
