<?php
namespace App\Http\Controllers\login;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use App\models\GoodsModel;

class LoginController extends Controller
{
    public function loginDo(Request $request)
    {
        $user_tel = $request->input('name');
        $user_pwd = $request->input('pwd');
        $id=$request->input('id');
        $obj=new \memcached();
        $arr=array(
            'name'=>$user_tel,
            'pwd'=>$user_pwd,
            'id'=>$id
        );
//        echo $res=$obj->get('name');
        $obj->addServer("127.0.0.1",11211);
//        $obj->delete('name');die;
        $res=$obj->add('name',$arr,30000);
        if($res==false){
            echo json_encode(['code'=>1,'msg'=>'登录成功']);
        }else{
            echo json_encode(['code'=>0,'msg'=>'登录失败']);
        };
    }
    public function login2(){
        return  view('login.login');
    }
    public function loginIndex(){
        $obj=new \memcached();
        $obj->addServer("127.0.0.1",11211);
        if($obj->get('name')['id']==1){
            echo "<script>alert('已经在其他客户端登录');location.href='login2'</script>";die;
        }else{
            echo "欢迎来到你的世界";die;
        }
    }
    public function logined(){
        $obj=new \memcached();
        $obj->addServer("127.0.0.1",11211);
        if($obj->get('name')['id']==2){
            echo  json_encode(['code'=>0,'msg'=>'已经在其他客户端登录']);
        }else{
            echo json_encode(['code'=>1,'msg'=>'登录成功']);
        }
    }
    //存数据redis
    public function getInfo(Request $request){
        $data=GoodsModel::where('goods_show',1)->get()->toarray();
        $arr = json_encode($data);
        $str = "goods";
        $redis = new \redis;
        $redis->connect('127.0.0.1',6379);
        $private_key = "/tmp/rsa_private_key.pem";
        $privatekey=file_get_contents($private_key);
        $encryptData="";
        openssl_private_encrypt($str,$encryptData,$privatekey);
        $content = base64_encode($encryptData);
        $redis->set('goods',$arr);
        echo json_encode($content);
    }
    //取数据
    public function quInfo(Request $request){
        $str = $request->input('str');
        $str = str_replace(' ','+',$str);
        $content = base64_decode($str);
        $pblic_key ="/tmp/rsa_public_key.pem";
        $publickey = file_get_contents($pblic_key);
        $go = "";
        openssl_public_decrypt($content,$go,$publickey);
        $redis = new \Redis;
        $redis->connect('127.0.0.1',6379);
        $arr = $redis->get($go);
        return $arr;
    }
    public function showIndex(){
        return view('login.index');
    }
}
