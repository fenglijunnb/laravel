<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <!-- 上传广告页面样式 -->
        <div class="banneradd bor">
            <input type="hidden" value="<?php echo e($data->id); ?>"  id="hidden"/>
            <div class="baTop">
                <span>友链修改</span>
            </div>
            <div class="baBody">
                <div class="bbD">
                    友链名称：<input type="text" id="name" class="input1" value="<?php echo e($data->name); ?>"/>
                </div>
                <div class="bbD">
                    友链网址：<input type="text" id="url" class="input1" value="<?php echo e($data->url); ?>"/>
                </div>
                <div class="bbD">
                    <p class="bbDP">
                        <button class="btn_ok btn_yes config_update" href="#">提交</button>
                        <a class="btn_ok btn_no" href="goods">取消</a>
                    </p>
                </div>
            </div>
        </div>

        <!-- 上传广告页面样式end -->
    </div>
</div>
</body>
</html>
<script>
     $(document).ready(function(){
        $('.config_update').click(function(){
            var name = $("#name").val();
            var c_url = $("#url").val();
            var hidden=$("#hidden").val();
            var url='config_up';
            $.ajax({
                type: 'post',
                data: {name:name,hidden:hidden,c_url:c_url},
                url: url,
                dataType: 'json',
                success: function (msg) {
                    //console.log(res);
                    if(msg.code==1){
                        alert(msg.msg);
                        window.location.href="configlist";
                    }else{
                        alert(msg.msg);
                    }
                }
            })        
        })

    })
</script>