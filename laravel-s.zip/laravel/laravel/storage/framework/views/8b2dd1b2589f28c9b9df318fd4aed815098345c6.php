<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <!-- 上传广告页面样式 -->
        <div class="banneradd bor">
            <div class="baTop">
                <span>商品属性添加</span>
            </div>
            <div class="baBody">
                <div class="bbD">
                    商品属性名称：<input type="text" name="attr_name" class="input1" />
                </div>
                <div class="bbD">
                    所属商品类型：
                    <select class="input3">
                        <?php $__currentLoopData = $typeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v -> type_id); ?>"><?php echo e($v -> type_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="bbD attr_input_type">
                    属性/规格：<input type="radio" name="attr_input_type" value="1" checked>属性
                               <input type="radio" name="attr_input_type" value="2">规格
                </div>
                <div class="bbD way attr_type">
                    录入方式：<input type="radio" name="attr_type" value="1" onclick="attr_t(1)" checked>手工录入
                              <input type="radio" name="attr_type" value="2" onclick="attr_t(2)">从下面的列表中选择</br>
                    可选值：<textarea name="attr_value" class="attr_value" id="attr_value" disabled cols="30" rows="10"></textarea>
                </div>
                <div class="bbD">
                    <p class="bbDP">
                        <button class="btn_ok btn_yes" href="#" onclick="goods_add()">提交</button>
                        <a class="btn_ok btn_no" href="attr_show">取消</a>
                    </p>
                </div>
            </div>
        </div>

        <!-- 上传广告页面样式end -->
    </div>
</div>
</body>
</html>
<script>
    function attr_t(attr_t) {
        if(attr_t==1){
            $("#attr_value").attr('disabled','disabled');
        }else{
            $("#attr_value").removeAttr('disabled');
        }
    }

    function goods_add() {

        var attr_name = $('.input1').val();
        var type_id = $('.input3').val();
        var attr_input_type = $("[name='attr_input_type']:checked").val();
        var attr_type = $("[name='attr_type']:checked").val();
        var attr_value = $('.attr_value').val();
        var data = {};
        data.attr_name = attr_name;
        data.type_id = type_id;
        data.attr_input_type = attr_input_type;
        data.attr_type = attr_type;
        data.attr_value = attr_value;
        var url = "attr_do";

        $.ajax({
            url : url,
            data : data,
            type : "post",
            success : function( msg ){
                if( msg.status == 0 ){

                    alert( msg.msg );

                    window.location.href = '/attr_show';

                }else{

                    alert( msg.msg );

                    window.location.href = '/attr_show';

                }
            }
        });

    }
</script>