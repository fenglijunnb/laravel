<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <!-- 上传广告页面样式 -->
        <div class="banneradd bor">
            <div class="bbD">
                <form class="form-control">
                    <input type="hidden"  name="hidden" value="<?php echo e($goods_id); ?>">
                    <table id="properties-table">
                        <tbody>
                        <tr>
                            <td class="label">商品类型：</td>
                            <td>
                                <?php if($data!=''): ?>
                                    <select class='form-control goods_type' name="goods_type" >
                                        <option value="0">请选择</option>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($v->type_id); ?>"><?php echo e($v->type_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php else: ?>/
                                <select class='form-control goods_type' name="goods_type" >
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($v->type_id); ?>"><?php echo e($v->type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td id="tbody-goodsAttr" colspan="2" style="padding:0">

                            </td>
                        </tr>
                        </tbody>
                    </table>
                </form>
            </div>
            <div class="bbD">
                <p class="bbDP">
                    <button class="btn_ok btn_yes" href="#" id="sub">提交</button>
                    <a class="btn_ok btn_no" href="goodslist">取消</a>
                </p>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script src="/js/jquery.js"></script>
<script>
    $(document).on('change','.goods_type',function(){
        var typeid = $(this).val();
        if( typeid ){
            $.ajax({
                type: "POST",
                url: "getAttribute",
                data: "type_id="+typeid,
                success: function(msg){
                    $('#tbody-goodsAttr').html(msg);
                }
            });
        }
    });

    //追加一行
    function addSpec(obj){
        //  alert('123');
        var nextnode = $(obj).parent().parent().clone();
        $(obj).parent().parent().after(nextnode);
        $(obj).parent().parent().next().find('a').text('[ - ]');
        $(obj).parent().parent().next().find('a').attr('onclick','lessSpec(this)');
        // alert(nextnode);
    }
    //减一行
    function lessSpec(obj){
        $(obj).parent().parent().remove();
    }
    $(document).on('click','#sub',function(){
        var  form=$(".form-control").serialize();
        $.ajax({
            type: "POST",
            url: "getattrdo",
            data:form,
            success: function(msg){
                if(msg.code==1){
                    alert(msg.msg);
                    window.location.href="goodslist";
                }else{
                    alert(msg.msg);
                }
            }
        });
    });
</script>