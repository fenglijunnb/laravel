<script type="text/javascript" charset="utf-8" src="js/jquery.min.js"></script>
<link rel="stylesheet" href="css/css.css" />

<style>
    input[type="checkbox"] { height:20px;width:20px; }
    tr{height: 40px;}
    td{text-align:center;}
</style>

<div class="list-div" style="margin-bottom: 5px; margin-top: 10px;" id="listDiv">
    <form name="addForm" id="addForm">
        <input type="hidden" name="goods_id"  value="<?php echo e($goods_info->goods_id); ?>">
        <table width="100%" cellpadding="3" cellspacing="1" id="table_list" border="1">
            <tbody><tr>
                <th colspan="20" scope="col">商品名称：<?php echo e($goods_info->goods_name); ?>&nbsp;&nbsp;&nbsp;&nbsp;货号：<?php echo e($goods_info->goods_sn); ?></th>
            </tr>
            <tr>
                <!-- start for specifications -->
                <?php $__currentLoopData = $attr_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td scope="col" style="background-color: rgb(255, 255, 255);"><div align="center"><strong><?php echo e($v); ?></strong></div></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- end for specifications -->
                <td class="label_2" style="background-color: rgb(255, 255, 255);">库存</td>
                <td class="label_2" style="background-color: rgb(255, 255, 255);">&nbsp;</td>
            </tr>
            <?php if(!empty($product_info)): ?>
                <?php $__currentLoopData = $product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php $__currentLoopData = $v->goods_attr_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk=>$vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($vv); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($v->product_num); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <tr id="attr_row">
                <!-- start for specifications_value -->
                <?php $__currentLoopData = $attr_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td align="center">
                        <select name="attr[<?php echo e($k); ?>][]">
                            <option value="0" selected="">请选择...</option>
                            <?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- end for specifications_value -->

                <td class="label_2"><input type="text" name="product_number[]" value="1" size="10"></td>
                <td><input type="button" class="button" value=" + " onclick="javascript:add_attr_product(this);"></td>
            </tr>

            <tr>
                <td align="center" colspan="7">
                    <input type="button" class="button"  id='btn' value=" 保存 " >
                </td>
            </tr>
            </tbody></table>
    </form>

</div>
<script>
    //追加一行
    function add_attr_product(obj){
        var newtr=$(obj).parent().parent().clone();
        newtr.find('.button').val(" - ");
        newtr.find('.button').attr("onclick",'less_attr_product(this)');
        $(obj).parent().parent().after(newtr);
    }
    //减少一行
    function less_attr_product(obj){
        console.log($(obj));
        $(obj).parent().parent().remove();
    }
</script>
<script>
    $(function(){
        $("#btn").click(function(){
            var form=$("#addForm").serialize();
            var goods_id=$("[name='goods_id']").val();
            var url="productdo";
            $.ajax({
                url:url,
                type:'post',
                data:form,
                dataType:'json',
                success:function(res){
                    alert(res.msg);
                    if(res.code==1){
                        location.href='product?id='+goods_id;
                    }
                }
            });
        });
    })
</script>
