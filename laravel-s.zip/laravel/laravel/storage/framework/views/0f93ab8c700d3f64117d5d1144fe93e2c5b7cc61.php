<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <!-- 上传广告页面样式 -->
        <div class="banneradd bor">
            <input type="hidden" value="<?php echo e($data->brand_id); ?>"  id="hidden"/>
            <div class="baTop">
                <span>品牌修改</span>
            </div>
            <div class="baBody">
                <div class="bbD">
                    品牌名称：<input type="text" id="brand_name" class="input1" value="<?php echo e($data->brand_name); ?>"/>
                </div>
                <div class="bbD">
                    品牌图片：
                    <div class="bbDd">
                        <div class="bbDImg"><img src="<?php echo e($data->brand_logo); ?>" height="180px;"  width="160px;" /></div>
                        <input type="file" class="file" />
                    </div>
                </div>
                <div class="bbD">
                    <p class="bbDP">
                        <button class="btn_ok btn_yes brand_update" href="#">提交</button>
                        <a class="btn_ok btn_no" href="goods">取消</a>
                    </p>
                </div>
            </div>
        </div>

        <!-- 上传广告页面样式end -->
    </div>
</div>
</body>
</html>
<script>
     $(document).ready(function(){
        $('.brand_update').click(function(){
            var brand_name = $("#brand_name").val();
            // console.log(brand_name);
            // return false;
            var hidden=$("#hidden").val();
            var url='brand_up';
            $.ajax({
                type: 'post',
                data: {brand_name:brand_name,hidden:hidden},
                url: url,
                dataType: 'json',
                success: function (msg) {
                    //console.log(res);
                    if(msg.code==1){
                        alert(msg.msg);
                        window.location.href="brandlist";
                    }
                }
            })        
        })

    })
</script>