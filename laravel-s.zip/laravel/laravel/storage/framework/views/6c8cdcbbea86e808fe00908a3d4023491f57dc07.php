<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>约见管理-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <link rel="stylesheet" href="/css/bootstrap.min.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <!-- <script type="text/javascript" src="js/page.js" ></script> -->
</head>

<body>
<div id="pageAll">


    <div class="page">
        <!-- banner页面样式 -->
        <div class="connoisseur">
            <div class="conform">
                <form>
                    <div class="cfD">
                        <a class="addA addA1" href="attradd">添加属性+</a>
                    </div>
                </form>
            </div>
            <div class="conShow">
                <table border="1" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="66px" class="tdColor tdC">商品属性id</td>
                        <td width="355px" class="tdColor">商品属性名称</td>
                        <td width="355px" class="tdColor">商品属性所属类型</td>
                        <td width="355px" class="tdColor">属性/规格</td>
                        <td width="355px" class="tdColor">商品属性录入方式</td>
                        <td width="355px" class="tdColor">商品属性可选值</td>
                        <td width="355px" class="tdColor">状态</td>
                        <td width="130px" class="tdColor">操作</td>
                    </tr>
                    <?php $__currentLoopData = $attrList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td width="66px" ><?php echo e($v -> attr_id); ?></td>
                            <td width="355px"><?php echo e($v -> attr_name); ?></td>
                            <td width="355px" ><?php echo e($v -> type_name); ?></td>
                            <?php if( $v -> attr_input_type == 1 ): ?>
                                <td width="355px" >属性</td>
                            <?php else: ?>
                                <td width="355px" >规格</td>
                            <?php endif; ?>
                            <?php if( $v -> attr_type == 1 ): ?>
                            <td width="355px">手工录入</td>
                            <?php else: ?>
                            <td width="355px" >从下面的列表中选择</td>
                            <?php endif; ?>
                            <td width="355px" ><?php echo e($v -> attr_values); ?></td>
                            <?php if( $v -> attr_status == 1 ): ?>
                                <td width="355px" >正常</td>
                            <?php else: ?>
                                <td width="355px" >已删除</td>
                            <?php endif; ?>

                            <td>
                                <a href="attr_update?attr_id=<?php echo e($v -> attr_id); ?>">
                                    <img class="operation" src="img/update.png">
                                </a>
                                <img class="operation delban" src="img/delete.png" onclick="brand_del(<?php echo e($v -> attr_id); ?>)">
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <div class="paging"><?php echo e($attrList->links()); ?></div>
            </div>
            <!-- banner 表格 显示 end-->
        </div>
        <!-- banner页面样式end -->
    </div>

</div>

</body>

</html>
<script>
    function brand_del( attr_id ) {

        var url = "attr_del";
        var data = {};
        data.attr_id = attr_id;
        $.ajax({
            url : url,
            data : data,
            type : "post",
            success : function( msg ){
                if( msg.status == 0 ){

                    alert( msg.msg );

                    window.location.href = '/attr_show';

                }else{

                    alert( msg.msg );

                    window.location.href = '/attr_show';

                }
            }
        });
    }
</script>