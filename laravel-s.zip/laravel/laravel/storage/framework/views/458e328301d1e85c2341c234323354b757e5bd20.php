<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>约见管理-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <link rel="stylesheet" href="/css/bootstrap.min.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <!-- <script type="text/javascript" src="js/page.js" ></script> -->
</head>

<body>
<div id="pageAll">


    <div class="page">
        <!-- banner页面样式 -->
        <div class="connoisseur">
            <!-- banner 表格 显示 -->
            <div class="conShow">
                <table border="1" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="66px" class="tdColor tdC">友链id</td>
                        <td width="200px" class="tdColor">添加人</td>
                        <td width="200px" class="tdColor">友链名称</td>
                        <td width="355px" class="tdColor">友链网址</td>
                        <td width="450px" class="tdColor">是否展示</td>
                        <td width="250px" class="tdColor">操作</td>
                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="100px" ><?php echo e($v->id); ?></td>
                        <td width="66px" class=" tdC"><?php echo e($v->admin_name); ?></td>
                        <td width="355px" ><?php echo e($v->name); ?></td>
                        <td width="355px" ><?php echo e($v->url); ?></td>
                        <?php if($v->default==1): ?>
                            <td><a href="javascript:;" class="defu" defaul="1" id="<?php echo e($v->id); ?>">是</a></td>
                        <?php else: ?>
                            <td><a href="javascript:;" class="defu" defaul="2" id="<?php echo e($v->id); ?>">否</a></td>
                        <?php endif; ?>
                        <td>
                            <a href="config_update?id=<?php echo e($v->id); ?>">
                                <img class="operation" src="img/update.png">
                            </a>
                            <img class="operation delban" src="img/delete.png" id="<?php echo e($v->id); ?>">
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <div class="paging"><?php echo e($data->links()); ?></div>
            </div>
            <!-- banner 表格 显示 end-->
        </div>
        <!-- banner页面样式end -->
    </div>

</div>

</body>
 
</html>
<script>
    $(document).ready(function(){
        $('.delban').click(function(){
            var data={};
            var _this=$(this);
            var id=_this.attr('id');
            data.id=id;
            var url='configdel';
            $.ajax({
                type: 'post',
                data: data,
                url: url,
                dataType: 'json',
                success: function (msg) {
                    //console.log(res);
                    if(msg.code==1){
                        alert(msg.msg);
                        _this.parents('tr').remove()
                    }else{
                        alert(msg.msg);
                    }
                }
            })        
        })

    })
</script>
<script>
    $('.defu').click(function(){
        var defaul = $(this).attr('defaul');
        var id = $(this).attr('id');
        $.ajax({
            type:'post',
            data:{'default':defaul,'id':id},
            url:'config_default',
            success:function(msg){
                if(msg==1){
                    window.location.reload();
                }
            }
        });
    });
</script>