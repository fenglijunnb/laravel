<table width="100%" id="attrTable">
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($val->attr_type==0 && $val->attr_input_type==0): ?>
            <tr>
                <td class="label"><?php echo e($val->attr_name); ?></td>
                <td>
                    <input name="attr_value_list[<?php echo e($val->attr_id); ?>]" type="text" value="" size="40">
            </tr>
        <?php endif; ?>
        <?php if($val->attr_type==0 && $val->attr_input_type==1): ?>
            <tr><td class="label"><?php echo e($val->attr_name); ?></td><td>
                    <select name="attr_value_list[<?php echo e($val->attr_id); ?>]">
                        <option value="">请选择...</option>
                        <?php $__currentLoopData = $val->attr_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($v!=''): ?>
                                <option value="<?php echo e($v); ?>"><?php echo e($v); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select></td>
            </tr>
        <?php endif; ?>
        <?php if($val->attr_type==1 && $val->attr_input_type==0): ?>
            <tr><td class="label">
                    <a href="javascript:;" onclick="addSpec(this)">[+]</a><?php echo e($val->attr_name); ?>

                </td>
                <td>
                    <input name="attr_value_list[<?php echo e($val->attr_id); ?>][]" type="text" value="" size="40">
                    属性价格 <input type="text" name="attr_price_list[<?php echo e($val->attr_id); ?>][]" value="<?php echo e($val->attr_price); ?>" size="5" maxlength="10">
                </td>
            </tr>
        <?php endif; ?>
        <?php if($val->attr_type==1 && $val->attr_input_type==1): ?>
            <tr><td class="label">
                    <a href="javascript:;" onclick="addSpec(this)">[+]</a><?php echo e($val->attr_name); ?></td>
                <td>
                    <select name="attr_value_list[<?php echo e($val->attr_id); ?>][]">
                        <option value="">请选择...</option>
                        <?php $__currentLoopData = $val->attr_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($v!=''): ?>
                                <option value="<?php echo e($v); ?>"><?php echo e($v); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> 属性价格
                    <input type="text" name="attr_price_list[<?php echo e($val->attr_id); ?>][]" value="" size="5" maxlength="10">
                </td>
            </tr>
        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>