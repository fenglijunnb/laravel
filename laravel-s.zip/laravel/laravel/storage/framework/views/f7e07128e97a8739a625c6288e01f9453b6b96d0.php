<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>广告-有点</title>
<link rel="stylesheet" type="text/css" href="css/css.css" />
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<!-- <script type="text/javascript" src="js/page.js" ></script> -->
</head>

<body>
	<div id="pageAll">
		<div class="pageTop">
			<div class="page">
				<img src="img/coin02.png" /><span><a href="#">首页</a>&nbsp;-&nbsp;<a
					href="#">商品管理</a>&nbsp;-</span>&nbsp;商品管理
			</div>
		</div>
		<div class="page">
			<!-- banner页面样式 -->
			<div class="banner">
				<div class="add">
					<a class="addA" href="/goodsbot">添加商品&nbsp;&nbsp;+</a>
				</div>
				<!-- banner 表格 显示 -->
				<div class="banShow">
					<table border="1" cellspacing="0" cellpadding="0">
						<tr>
							<td width="66px" class="tdColor tdC">商品货号</td>
							<td width="315px" class="tdColor">名称</td>
							<td width="308px" class="tdColor">图片</td>
							<td width="308px" class="tdColor">商品所属分类</td>
							<td width="308px" class="tdColor">商品所属品牌</td>
							<td width="450px" class="tdColor">商品库存</td>
							<td width="215px" class="tdColor">商品价格</td>
							<td width="180px" class="tdColor">购买商品获赠积分</td>
							<td width="215px" class="tdColor">所属活动名称</td>
							<td width="308px" class="tdColor">SKU</td>
							<td width="308px" class="tdColor">货品展示</td>
							<td width="125px" class="tdColor">操作</td>
						</tr>
						<?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($v->goods_sn); ?></td>
							<td><?php echo e($v->goods_name); ?></td>
							<td><div class="bsImg">
									<img src="<?php echo e($v->goods_img); ?>">
								</div></td>
							<td><?php echo e($v->cate_name); ?></td>
							<td><?php echo e($v->brand_name); ?></td>
							<td><?php echo e($v->goods_num); ?></td>
							<td><?php echo e($v->goods_price); ?></td>
							<td><?php echo e($v->score); ?></td>
							<td><?php echo e($v->name); ?></td>
							<td><a href="/goods_attr?id=<?php echo e($v->goods_id); ?>">SKU管理</a></td>
							<td><a href="/product?id=<?php echo e($v->goods_id); ?>">货品展示</a></td>
							<td><a href="goods_up?id=<?php echo e($v->goods_id); ?>"><img  class="operation up"
									src="img/update.png"></a> <img class="operation delban"
								src="img/delete.png" id="<?php echo e($v->goods_id); ?>"></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					<div class="paging"><?php echo e($arr->links()); ?></div>
				</div>
				<!-- banner 表格 显示 end-->
			</div>
			<!-- banner页面样式end -->
		</div>

	</div>
</body>


</html>
<script src="/js/jquery.js"></script>
<script>
	$('.delban').click(function(){
		var id = $(this).attr('id');
    	$.ajax({
    		type:'post',
    		data:{'id':id},
    		url:"goods_del",
    		success:function(msg){
    			if(msg==1){
    				alert("删除成功");
    				window.location.reload();
    			}else{
    				alert("删除失败");
    			}
    		}
    	});
	});
</script>
