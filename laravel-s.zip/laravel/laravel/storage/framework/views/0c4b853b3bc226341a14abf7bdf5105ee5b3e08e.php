<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <!-- 上传广告页面样式 -->
        <div class="banneradd bor">
            <div class="baTop">
                <span>商品属性修改</span>
            </div>
            <div class="baBody">
                <div class="bbD">
                    商品属性名称：
                    <input type="text" value="<?php echo e($attrList -> attr_name); ?>" name="attr_name" class="input1" />
                </div>
                <div class="bbD">
                    所属商品类型：
                    <select class="input3">
                        <?php $__currentLoopData = $typeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v -> type_id); ?>" <?php if( $v -> type_id == $attrList -> type_id): ?> selected <?php else: ?>  <?php endif; ?>><?php echo e($v -> type_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="bbD attr_input_type">
                    属性/规格：
                    <?php if( $attrList -> attr_input_type == 1 ): ?>
                        <input type="radio" name="attr_input_type" value="1" checked>属性
                        <input type="radio" name="attr_input_type" value="2">规格
                    <?php else: ?>
                        <input type="radio" name="attr_input_type" value="1">属性
                        <input type="radio" name="attr_input_type" value="2" checked>规格
                    <?php endif; ?>
                </div>
                <div class="bbD way attr_type">
                    录入方式：
                    <?php if( $attrList -> attr_type == 1 ): ?>
                    <input type="radio" name="attr_type" value="1" onclick="attr_t(1)" checked>手工录入
                    <input type="radio" name="attr_type" value="2" onclick="attr_t(1)">从下面的列表中选择</br>
                    <?php else: ?>
                        <input type="radio" name="attr_type" value="1" onclick="attr_t(1)">手工录入
                        <input type="radio" name="attr_type" value="2" onclick="attr_t(2)" checked>从下面的列表中选择</br>
                    <?php endif; ?>

                    可选值：
                    <textarea name="attr_values"  class="attr_value" id="attr_values"  cols="30" rows="10"><?php echo e($attrList -> attr_values); ?></textarea>
                </div>
                <div class="bbD">
                    <p class="bbDP">
                        <button class="btn_ok btn_yes" href="#" onclick="goods_add(<?php echo e($attrList -> attr_id); ?>)">提交</button>
                        <a class="btn_ok btn_no" href="goods">取消</a>
                    </p>
                </div>
            </div>
        </div>

        <!-- 上传广告页面样式end -->
    </div>
</div>
</body>
</html>
<script>
    var attr_all=$("[name='attr_type']:checked").val();
    console.log(attr_all);
    if(attr_t==1){
        $("#attr_value").attr('disabled','disabled');
    }else{
        $("#attr_value").removeAttr('disabled');
    }
    function attr_t(attr_t) {
        if(attr_t==1){
            $("#attr_value").attr('disabled','disabled');
        }else{
            $("#attr_value").removeAttr('disabled');
        }
    }
    function goods_add( attr_id ) {

        var attr_name = $('.input1').val();
        var type_id = $('.input3').val();
        var attr_input_type = $("[name='attr_input_type']:checked").val();
        var attr_type = $("[name='attr_type']:checked").val();
        var attr_value = $('.attr_value').val();
        var data = {};
        data.attr_id = attr_id;
        data.attr_name = attr_name;
        data.type_id = type_id;
        data.attr_input_type = attr_input_type;
        data.attr_type = attr_type;
        data.attr_value = attr_value;
        var url = "attr_update_do";

        $.ajax({
            url : url,
            data : data,
            type : "post",
            success : function( msg ){
                if( msg.status == 0 ){

                    alert( msg.msg );

                    window.location.href = '/attr_show';

                }else{

                    alert( msg.msg );

                    window.location.href = '/attr_show';

                }
            }
        });

    }
</script>