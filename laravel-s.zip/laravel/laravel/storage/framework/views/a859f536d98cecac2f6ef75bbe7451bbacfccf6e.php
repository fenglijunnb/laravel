<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <div class="conShow">
        <table border="1" cellspacing="0" cellpadding="0" width="100%">
            <colgroup>
                <col width="200">
                <col width="100">
            </colgroup>
            <thead>
            <tr>
                <td  width="30px" class="tdColor tdC">节点id</td>
                <td  width="66px" class="tdColor tdC">节点名称</td>
                <td  width="66px" class="tdColor tdC">控制器名</td>
                <td  width="66px" class="tdColor tdC">方法名称</td>
                <td  width="66px" class="tdColor tdC">操作</td>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr pid="<?php echo e($v->pid); ?>" node_id="<?php echo e($v->node_id); ?>">
                <td width="66px" class="tdColor tdC">
                    <?php echo e(str_repeat('&nbsp;&nbsp;',$v->level*2)); ?>

                    <a href="javascript:;" class="flag">+</a>
                    <?php echo e($v->node_id); ?>

                </td>
                <td width="200px">
                    <?php echo e(str_repeat('&nbsp;&nbsp;',$v->level*2)); ?>

                    <div class="div">
                        <span class="clk"><?php echo e($v->node_name); ?></span>
                        <input type="text" class="imp" field="node_name" value="<?php echo e($v->node_name); ?>" style='width:110px; display:none;'>
                    </div>
                </td>

                <td width="200px">
                    <?php echo e(str_repeat('&nbsp;&nbsp;',$v->level*2)); ?>

                    <div class="div">
                        <span class="clk"><?php echo e($v->controller_name); ?></span>
                        <input type="text" class="imp" field="controller_name" value="<?php echo e($v->controller_name); ?>" style='width:110px; display:none;'>
                    </div>
                </td>

                <td width="200px">
                    <?php echo e(str_repeat('&nbsp;&nbsp;',$v->level*2)); ?>

                    <div class="div">
                        <span class="clk"><?php echo e($v->action_name); ?></span>
                        <input type="text" class="imp" field="action_name" value="<?php echo e($v->action_name); ?>" style='width:110px; display:none;'>
                    </div>
                </td>
                
                <td>
                    <a href="javascript:;" class="del"  node_id="<?php echo e($v->node_id); ?>">删除</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
        <!-- 上传广告页面样式end -->
    </div>
</div>
</body>
</html>
<script>
    $(function(){
            $("tbody>tr[pid!=0]").hide();

            $('.flag').click(function(){
                var _this=$(this);
                var flag=_this.text();
                var node_id=_this.parents('tr').attr('node_id');
                if(flag=='+'){
                    if($("tbody>tr[pid="+node_id+"]").length>0){
                        $("tbody>tr[pid="+node_id+"]").show();
                        _this.text('-');
                    }
                }else{
                    trHide(node_id);
                    _this.text('+');
                }
            });
            // 收缩
            function trHide(node_id){
                var _tr=$("tbody>tr[pid="+node_id+"]");
                _tr.hide();
                _tr.find('td').find("a[class='flag']").text('+');
                for(var i=0;i<_tr.length;i++){
                    var c_id=_tr.eq(i).attr('node_id');
                    trHide(c_id);
                }
            }
            $('.del').click(function(){
                var _this=$(this);
                var node_id=_this.attr('node_id');
                $.get('nodedelete',{node_id:node_id},function(res){
                    if(res==1){
                        alert('删除成功');
                        _this.parents('tr').remove();
                    }else if(res==2){
                        alert('此节点下有子节点不能删除');
                    }else{
                        alert('删除失败');
                    }
                })
            });

            // 即点即改
            $('.clk').click(function(){
                var _this=$(this);
                _this.hide();
                _this.next('input').show();
            });

            $('.imp').blur(function(){
                var _this=$(this);
                var value=_this.val();
                var field=_this.attr('field');
                var node_id=_this.parents('tr').attr('node_id');
                $.post(
                    "nodeupdate",
                    {value:value,field:field,node_id:node_id},
                    function(res){
                        alert('修改成功');
                        _this.hide();
                        _this.prev('span').html(value).show();
                    },
                    'json'
                )
            });


    })
</script>