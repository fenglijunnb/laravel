<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <div class="conShow">
        <table border="1" cellspacing="0" cellpadding="0" width="100%">
            <colgroup>
                <col width="200">
                <col width="100">
            </colgroup>
            <thead>
            <tr>
                <td  width="66px" class="tdColor tdC">id</td>
                <td  width="66px" class="tdColor tdC">名称</td>
                <td  width="66px" class="tdColor tdC">是否展示</td>
                <td  width="66px" class="tdColor tdC">是否导航栏展示</td>
                <td  width="66px" class="tdColor tdC">操作</td>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr pid="<?php echo e($v->pid); ?>" cate_id="<?php echo e($v->cate_id); ?>">
                <td width="66px" class="tdColor tdC">
                    <?php echo e(str_repeat('&nbsp;&nbsp;',$v->level*2)); ?>

                    <a href="javascript:;" class="flag">+</a>
                    <?php echo e($v->cate_id); ?>

                </td>
                <td width="200px" class="tdColor tdC">
                    <?php echo e(str_repeat('&nbsp;&nbsp;',$v->level*2)); ?>

                    <div class="div">
                        <span class="clk"><?php echo e($v->cate_name); ?></span>
                        <input type="text" class="imp" field="cate_name" value="<?php echo e($v->cate_name); ?>" style='width:110px; display:none;'>
                    </div>
                </td>
                <td width="100px" class="show tdColor tdC" field="cate_show" status="<?php echo e($v->cate_show); ?>" >
                    <?php if($v->cate_show==1): ?>
                        √
                    <?php else: ?>
                        ×
                    <?php endif; ?>
                </td>
                <td width="100px" class="show tdColor tdC"  field="cate_navshow" status="<?php echo e($v->cate_navshow); ?>">
                    <?php if($v->cate_navshow==1): ?>
                        √
                    <?php else: ?>
                        ×
                    <?php endif; ?>
                </td>
                <td  class="tdColor tdC">
                    <a href="javascript:;" class="del"  cate_id="<?php echo e($v->cate_id); ?>">删除</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
        <!-- 上传广告页面样式end -->
    </div>
</div>
</body>
</html>
<script>
    $(function(){
            $("tbody>tr[pid!=0]").hide();

            $('.flag').click(function(){
                var _this=$(this);
                var flag=_this.text();
                var cate_id=_this.parents('tr').attr('cate_id');
                if(flag=='+'){
                    if($("tbody>tr[pid="+cate_id+"]").length>0){
                        $("tbody>tr[pid="+cate_id+"]").show();
                        _this.text('-');
                    }
                }else{
                    trHide(cate_id);
                    _this.text('+');
                }
            });
            // 收缩
            function trHide(cate_id){
                var _tr=$("tbody>tr[pid="+cate_id+"]");
                _tr.hide();
                _tr.find('td').find("a[class='flag']").text('+');
                for(var i=0;i<_tr.length;i++){
                    var c_id=_tr.eq(i).attr('cate_id');
                    trHide(c_id);
                }
            }
            $('.del').click(function(){
                var _this=$(this);
                var cate_id=_this.attr('cate_id');
//                 console.log(cate_id);
                $.get('catedelete',{cate_id:cate_id},function(res){
                    if(res.code==1){
                        alert(res.msg);
                        _this.parents('tr').remove();
                    }else if(res.code==2){
                        alert(res.msg);
                    }else{
                        alert(res.msg);
                    }
                },'json')
            });

            // 即点即改
            $('.clk').click(function(){
                var _this=$(this);

                _this.hide();
                _this.next('input').show();
            });

            $('.imp').blur(function(){
                var _this=$(this);
                var value=_this.val();
                var field=_this.attr('field');
                var cate_id=_this.parents('tr').attr('cate_id');
                // console.log(value)
                // console.log(field)
                // console.log(cate_id)
                $.post(
                    "cateupdate",
                    {value:value,field:field,cate_id:cate_id},
                    function(res){
                        alert('修改成功');
                        _this.hide();
                        _this.prev('span').html(value).show();
                    },
                    'json'
                )
            });

            $('.show').click(function(){
                var _this=$(this);
                var field=_this.attr('field');
                var status=_this.attr('status');
                var cate_id=_this.parent().attr('cate_id');
                if(status==1){
                    status=2;
                }else{
                    status=1;
                }

                $.post(
                    "cateupdate",
                    {value:status,field:field,cate_id:cate_id},
                    function(res){
                        if(res==1){
                            alert('修改成功');
                            if(status==1){
                                _this.html('√');
                                _this.attr('status',1);
                            }else{
                                _this.html('×');
                                _this.attr('status',2);
                            }
                        }else{
                            alert('修改失败');
                        }
                    }
                    ,'json'
                )

            })
    })
</script>