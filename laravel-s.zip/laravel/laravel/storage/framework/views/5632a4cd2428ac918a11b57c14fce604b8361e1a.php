<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>约见管理-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <link rel="stylesheet" href="/css/bootstrap.min.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <!-- <script type="text/javascript" src="js/page.js" ></script> -->
</head>

<body>
<div id="pageAll">


    <div class="page">
        <!-- banner页面样式 -->
        <div class="connoisseur">
            <!-- banner 表格 显示 -->
            <div class="conShow">
                <table border="1" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="200px" class="tdColor">角色ID</td>
                        <td width="355px" class="tdColor">角色名称</td>
                        <td width="250px" class="tdColor">操作</td>
                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="355px" ><?php echo e($v->role_id); ?></td>
                        <td width="355px" ><?php echo e($v->role_name); ?></td>
                        <td>
                            <img class="operation delban" src="img/delete.png" id="<?php echo e($v->role_id); ?>">
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <div class="paging"><?php echo e($data->links()); ?></div>
            </div>
            <!-- banner 表格 显示 end-->
        </div>
        <!-- banner页面样式end -->
    </div>

</div>

</body>
 
</html>
<script>
    $(document).ready(function(){
        $('.delban').click(function(){
            var data={};
            var _this=$(this);
            var id=_this.attr('id');
            data.id=id;
            var url='roledel';
            $.ajax({
                type: 'post',
                data: data,
                url: url,
                dataType: 'json',
                success: function (msg) {
                    //console.log(res);
                    if(msg.code==1){
                        alert(msg.msg);
                        _this.parents('tr').remove()
                    }else{
                        alert(msg.msg);
                    }
                }
            })        
        })

    })
</script>