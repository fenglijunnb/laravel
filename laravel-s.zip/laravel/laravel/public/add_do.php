<?php
header("content-type:text/html;charset=utf-8");
ob_start();
$name=$request->post['goods_name'];
$price=$request->post['goods_price'];
$controller=$request->post['goods_desc'];
$is_rm=$request->post['is_hot'];
$arr=[
    'goods_name'=>$name,
    'goods_price'=>$price,
    'goods_desc'=>$controller,
    'goods_hot'=>$is_rm
];
$data=$arr;
$redis=new Redis();
$key="goodsInfo";
$redis->connect('127.0.0.1',6379);
$goods_info = $redis->get("$key");
if(!empty($goods_info)){
    $goods_info = json_decode($goods_info,true);
}

$goods_info[] = $data;

$res = $redis->set("$key",json_encode($goods_info));
if($redis->get($key)){
    $redis->incr("goods_count");
    echo "<script>alert('添加成功');location.href='show.php';</script>";
}else{
    echo "<script>alert('添加失败');location.href='add.html';</script>";
}
$content = ob_get_contents();
return $content;
?>
