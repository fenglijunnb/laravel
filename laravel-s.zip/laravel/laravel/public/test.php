<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="Author" contect="http://www.webqin.net">
    <title>三级分销</title>
    <link href="css/mui.min.css" rel="stylesheet"/>
    <script src="js/mui.min.js"></script>
    <link rel="shortcut icon" href="images/favicon.ico" />

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/response.css" rel="stylesheet">
    <script src="layui/layui.js"></script>
    <link rel="stylesheet" href="layui/css/layui.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="maincont">
    <header>
        <a href="javascript:history.back(-1)" class="back-off fl"><span class="glyphicon mui-action-back glyphicon-menu-left"></span></a>
        <div class="head-mid">
            <h1>产品详情</h1>
        </div>
    </header>
    <div id="sliderA" class="slider">
        <img src="images/image1.jpg" />
        <img src="images/image2.jpg" />
        <img src="images/image3.jpg" />
        <img src="images/image4.jpg" />
        <img src="images/image5.jpg" />
    </div><!--sliderA/-->
    <table class="jia-len">
        <tr>
            <th><span style='color: #f60;'>￥</span><strong class="orange">299</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;商品数量：<span class="goods_number">35</span></th>
            <td>
                <input type="hidden" class="spinnerExample"  />
            </td>
            <input type="hidden" class='goods_num'>
        </tr>
        <tr>
            <td>
                <strong class='goods_name'></strong>
                <b class='goods_desc'></b>
            </td>
            <td align="right">
                <a class="shoucang" href="javascript:;"><span class="glyphicon glyphicon-star-empty"></span></a>
            </td>
        </tr>
    </table>
    <div class="height2"></div>
    <h3 class="proTitle">商品规格</h3>
    <ul class="guige">
        <!-- <li class="guigeCur"><a href="javascript:;">50ML</a></li>
         <li><a href="javascript:;">100ML</a></li>
         <li><a href="javascript:;">150ML</a></li>
         <li><a href="javascript:;">200ML</a></li>
         <li><a href="javascript:;">300ML</a></li> -->
        <div class="clearfix"></div>
    </ul><!--guige/-->
    <div class="height2"></div>
    <div class="zhaieq">
        <a href="javascript:;" class="desc" value='1'>商品简介</a>
        <a href="javascript:;"  class="desc" value='2'>商品参数</a>
        <a href="javascript:;" style="background:none;"  class="desc" value='3'>订购列表</a>
        <div class="clearfix"></div>
    </div><!--zhaieq/-->
    <div class="proinfoList proinfoList1" style="display: block;">
    </div><!--proinfoList/-->
    <div class="proinfoList proinfoList2">

    </div><!--proinfoList/-->
    <div class="proinfoList proinfoList3">

    </div><!--proinfoList/-->
    <table class="jrgwc">
        <tr>
            <th>
                <a href="index.html"><span class="glyphicon glyphicon-home"></span></a>
            </th>
            <td>
                <button class="layui-btn layui-btn-radius addCart">加入购物车</button>
            </td>
            <td>
                <button class="layui-btn layui-btn-radius addCollection">加入收藏</button>
            </td>
        </tr>
    </table>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/style.js"></script>
    <!--焦点轮换-->
    <script src="js/jquery.js"></script>
    <script src="js/jquery.excoloSlider.js"></script>
    <script>
        $(function () {
            $("#sliderA").excoloSlider();
        });
    </script>
    <!--  jq加减
     <script src="js/jquery.spinner.js"></script>
     <script>
      $('.spinnerExample').spinner({});
      </script> -->
</body>
</html>
<script>
    $(document).ready(function(){
        var goods_attr="";
        $("#sliderA").empty();
        $(".guige").empty();
        //商品信息
        var url="http://47.107.93.29:8080/search";
        mui.plusReady(function() {
            var self = plus.webview.currentWebview();
            var goods_id = self.goods_id;
            $.get(url,{goods_id:goods_id},function(res){
                if(res.attrInfo==""){
                    $(".guige").addClass('attr_none');
                    $(".guige").text("该商品没有规格！");

                }else{
                    var str="";
                    mui.each(res.attrInfo,function (i,v) {
                        str+="<li><a href='javascript:;' attr_price='"+v.attr_price+"'  goods_attr='"+v.goods_attr_id+"' class='attr' >"+v.attr_value+'￥'+v.attr_price+"</a></li>";
                    });
                    str+="<div class='clearfix'></div>";
                    $(".guige").html(str);
                }
                if(res.goodsInfo.goods_imgs==null){
                    var str="<img src='http://47.107.93.29:8080/img/318250.jpg' style='width: 640px; height: 250px;'>";
                    $("#sliderA").html(str);
                }else{
                    var str="";
                    $.each(res.goodsInfo.goods_imgs,function(i,v){
                        str+="<img src='http://47.107.93.29:8080/"+v+"'>";
                    });
                    $("#sliderA").html(str);
                    $("#sliderA").excoloSlider();
                }

                var proinfoList="商品名称："+res.goodsInfo.goods_name+"</br>"+
                    "商品价格：￥"+res.goodsInfo.goods_price+"</br>"+
                    "商品积分："+res.goodsInfo.score+"</br>"+
                    "商品添加的时间："+res.goodsInfo.createtime+"	  ";
                $(".proinfoList").html(proinfoList);
                $(document).on('click',".desc",function(){
                    var _this=$(this).attr('value');
                    if(_this==1){
                        $(this).siblings().removeClass('zhaiCur');
                        $(".proinfoList").html(proinfoList);
                        $(this).addClass('zhaiCur');
                    }else if(_this==2){
                        $(this).siblings().removeClass('zhaiCur');
                        $(".proinfoList").html(res.goodsInfo.goods_desc);
                        $(this).addClass('zhaiCur');
                    }else{
                        $(this).siblings().removeClass('zhaiCur');
                        $(".proinfoList").html('暂无信息...');
                        $(this).addClass('zhaiCur');
                    }
                })
                $(document).on('click','.attr',function(){

                    var price=parseInt(res.goodsInfo.goods_price);
                    var priceAll=(Number(price)+Number($(this).attr('attr_price')));
                    $(".orange").text(priceAll);
                    $(this).addClass('attr_click');
                    var borther = $('.attr').prevAll();

                });
            },'json');



        });
        mui.plusReady(function() {
            var self = plus.webview.currentWebview();
            var goods_id = self.goods_id;
            var user_id=plus.storage.getItem("user_id");
            mui.ajax('http://47.107.93.29:8080/goodsDetail',{
                data:{
                    goods_id:goods_id,
                    user_id:user_id,
                },
                dataType:'json',//服务器返回json格式数据
                type:'post',//HTTP请求类型
                timeout:10000,//超时时间设置为10秒；
                headers:{'Content-Type':'application/json'},
                success:function(data){
                    $(".orange").html(data.goods_price);
                    $(".goods_name").html(data.goods_name);
                    $(".goods_number").text(data.goods_num);
                    $(".goods_num").val(data.goods_num);
                    $(".goods_desc").html(data.goods_desc);
                }
            });
        })
        //加入购物车
        $(document).on('click','.addCart',function(){
            var price=$(".orange").text();
            mui.plusReady(function() {
                var self = plus.webview.currentWebview();
                var goods_id = self.goods_id;
                var user_id=plus.storage.getItem("user_id");
                var goods_attr=$(".attr_click").attr('goods_attr');
                $.each($(".attr"),function(i,v){
                    alert($(".attr").parent().html());
                });

                var a_tr = $('.attr_click').attr('goods_attr')
                alert(a_tr)
                //alert(goods_attr);
                return false;
                if(!$(".guige").hasClass('attr_none')){
                    if(goods_attr==undefined){
                        mui.toast('请选择规格！',{ duration:'long'});
                        return false;
                    }
                }else{
                    $(".guige").siblings.removeClass('attr_none');
                }
                mui.ajax('http://47.107.93.29:8080/addCart',{
                    data:{
                        goods_id:goods_id,
                        user_id:user_id,
                        goods_attr:goods_attr,
                        price:price
                    },
                    dataType:'json',//服务器返回json格式数据
                    type:'post',//HTTP请求类型
                    timeout:10000,//超时时间设置为10秒；
                    headers:{'Content-Type':'application/json'},
                    success:function(data){
                        if(data.code==1){
                            mui.toast(data.msg,{ duration:'long'});
                        }else if(data.code==2){
                            mui.toast(data.msg,{ duration:'long'});
                        }else if(data.code==3){
                            mui.toast(data.msg,{ duration:'long'});
                            mui.openWindow({
                                url:"login.html"
                            })
                        }
                    },
                });
            })
        })
        //加入收藏
        $(document).on('click','.addCollection',function(){
            mui.plusReady(function() {
                var self = plus.webview.currentWebview();
                var goods_id = self.goods_id;
                var user_id=plus.storage.getItem("user_id");
                mui.ajax('http://47.107.93.29:8080/addCollection',{
                    data:{
                        goods_id:goods_id,
                        user_id:user_id
                    },
                    dataType:'json',//服务器返回json格式数据
                    type:'post',//HTTP请求类型
                    timeout:10000,//超时时间设置为10秒；
                    headers:{'Content-Type':'application/json'},
                    success:function(data){
                        if(data.code==1){
                            mui.toast(data.msg,{ duration:'long'});
                        }else if(data.code==2){
                            mui.toast(data.msg,{ duration:'long'});
                        }else if(data.code==3){
                            mui.toast(data.msg,{ duration:'long'});
                            mui.openWindow({
                                url:"login.html"
                            })
                        }
                    },
                });
            })
        })
    })
</script>