<?php

$server = new Swoole\WebSocket\Server("0.0.0.0", 9501);

$server->on('open', function (Swoole\WebSocket\Server $server, $request) {
    echo "server: handshake success with fd{$request->fd}\n";
});

$server->on('message', function (Swoole\WebSocket\Server $server, $frame) {
    $data = $frame->data;
    print_r(json_decode($data, true));
    if (!empty(json_decode($data, true)['str'])) {
        echo 4;
    }
    $redis = new \redis();
    $redis->connect('127.0.0.1', '6379');
    if (!empty(json_decode($data, true)['name'])) {
        $id = 1;
        $id = $redis->incr($id);
        $redis->rpush("demo", "uid$id");
        $redis->set("uid$id", $data);
        $data = json_decode($data, true);
        $name = $data['name'];
        $redis->sAdd('name', "$name");
        $c[0] = $data;
        $c[1] = 0;
        $c[2] = $redis->sMembers('name');
        $c = json_encode($c, true);
        foreach ($server->connections as $fd) {
            $server->push($fd, $c);
        }
    } else if ($data == 1) {
        $demo = $redis->lRange("demo", 0, -1);
        foreach ($demo as $k => $v) {
            $arr[] = $redis->get($v);
        }
        if (empty($arr)) {
            $c[0] = "";
        } else {
            $c[0] = $arr;
        }
        $c[1] = 1;
        $c[2] = $redis->sMembers('name');
        $c = json_encode($c, true);
        $server->push($frame->fd, $c);
    } else if (!empty(json_decode($data, true)['str'])) {
        echo 2;
        $demo = $redis->lRange("demo", 0, -1);
        foreach ($demo as $k => $v) {
            $arr[] = $redis->get($v);
        }
        if (empty($arr)) {
            $c[0] = "";
        } else {
            $c[0] = $arr;
        }
        $c[1] = 4;
        $name = $data['name'];
        $redis->sRem("$name");
        $c[2] = $redis->sMembers('name');
        $c = json_encode($c, true);
        $server->push($frame->fd, $c);
    } else if ($data == 0) {
        $demo = $redis->lRange("demo", 0, -1);
        foreach ($demo as $k => $v) {
            $arr[] = $redis->get($v);
        }
        if (empty($arr)) {
            $c[0] = "";
        } else {
            $c[0] = $arr;
        }
        $c[1] = 2;
        $c[2] = $redis->sMembers('name');
        $c = json_encode($c, true);
        $server->push($frame->fd, $c);
    }

});

$server->on('close', function ($ser, $fd) {
    echo "client {$fd} closed\n";
});

$server->start();
?>
