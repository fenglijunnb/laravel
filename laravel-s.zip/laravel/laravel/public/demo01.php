<?php
	use Swoole\Http\Server;
	$http = new Swoole\Http\Server("0.0.0.0", 9501);
	$http->on('request', function ($request, $response) {
//    		$response->end("<h1>Hello Swoole. #".rand(1000, 9999)."</h1>");
		$filename = $request->server['request_uri'];
		$filepath="/usr/www/laravel/laravel/public";
		$file = $filepath.$filename;
		if(file_exists($file)){
			$filename = strrpos($file,'.');
			$filename = substr($file,$filename);
			if($filename=='.html'){
				require $file;
				$num = file_get_contents($file);
				$response->end($num);
			}else{
				$num=require $file;
				$response->end($num);
			}
		}
	});
	$http->start();
?>
