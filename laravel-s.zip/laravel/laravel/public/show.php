<?php
ob_start();
$page = $request->get['page'];
$key = "goodsInfo";
$redis = new \Redis();
$redis->connect("127.0.0.1",6379);
$num = 2;
$count = $redis->get("goods_count");
$lastPage = ceil($count/$num);
$page = !empty($page) ? $page < 1 ? 1 : $page >= $lastPage ? $lastPage :$page :1;
//    $goods_info = $redis->get("$key"."_$page");
$data = [];

//    if(empty($goods_info)){
$goods_info = $redis->get("$key");
if(!empty($goods_info)){
    $start = ($page-1)*$num;
    $goods_info = json_decode($goods_info,true);
//    print_r($goods_info);

    $goods_info = array_slice($goods_info,$start,$num);

//            $redis->set("$key"."_$page",$goods_info);
}
//    }
$data = $goods_info;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<table border="1">
    <tr>
        <td>商品名字</td>
        <td>商品价格</td>
        <td>商品描述</td>
        <td>是否热卖</td>
    </tr>
    <?php foreach($data as $v){ ?>
        <tr>
            <td><?php
                    echo $v['goods_name'];
               ?></td>
            <td><?php
                    echo $v['goods_price'];
               ?></td>
            <td><?php
                    echo $v['goods_desc'];
               ?></td>
            <td><?php
                if($v['goods_hot']==1){
                    echo "热卖";
                }else{
                    echo "冷卖";
                }
                ?></td>
        </tr>
    <?php }?>
    <tr>
        <td colspan="5">
            <a href="?page=1">首页</a>
            <a href="?page=<?php echo $page-1<1?:1;?>">上一页</a>
            <a href="?page=<?php echo $page+1>$lastPage?$lastPage:$page+1;?>">下一页</a>
            <a href="?page=<?php echo $lastPage;?>">尾页</a>
        </td>
    </tr>
</table>
</body>
</html>
<?php
$content = ob_get_contents();
return $content;