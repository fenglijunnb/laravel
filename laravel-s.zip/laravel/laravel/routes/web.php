<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/','login\LoginContoller@adminlogin')->middleware('nomoney');
Route::get('index','index\IndexController@index')->middleware('nomoney');
Route::any('head','index\IndexController@head')->middleware('nomoney');
Route::any('resetpwd','index\IndexController@resetpwd')->middleware('nomoney');//重置密码
Route::any('reset','index\IndexController@reset')->middleware('nomoney');//执行重置
Route::any('loginout','index\IndexController@loginout')->middleware('nomoney');
Route::any('register','user\UserController@register')->middleware('nomoney');//注册
Route::any('login','user\UserController@login')->middleware('nomoney') ;//登录
Route::any('upPwd','user\UserController@upPwd')->middleware('nomoney');//修改密码
Route::any('getCode','user\UserController@getCode')->middleware('nomoney');//获取验证码
Route::any('getUser','user\UserController@getUser')->middleware('nomoney');//登录成功存储本地缓存
Route::any('userInfo','user\UserController@userInfo')->middleware('nomoney');//登录成功存储本地缓存
Route::any('score','user\UserController@score')->middleware('nomoney');
Route::any('userData','user\UserController@userData')->middleware('nomoney');
Route::any('duihuan','user\UserController@duihuan')->middleware('nomoney');
Route::any('score_user','user\UserController@score_user')->middleware('nomoney');
Route::any('coupon_show','user\UserController@coupon_show')->middleware('nomoney');

Route::any('addCart','cart\CartController@addCart')->middleware('nomoney');//加入购物车
Route::any('cartShow','cart\CartController@cartShow')->middleware('nomoney');//购物车展示
Route::any('cartUpdate','cart\CartController@cartUpdate')->middleware('nomoney');//购物车数量修改
Route::any('addCollection','cart\CartController@addCollection')->middleware('nomoney');//加入收藏
Route::any('collection','cart\CartController@collection')->middleware('nomoney');//我的收藏
Route::any('collectionDel','cart\CartController@collectionDel')->middleware('nomoney');//取消收藏
Route::any('num','cart\CartController@num')->middleware('nomoney');   
Route::any('center','user\UserController@center')->middleware('nomoney');//个人中心
Route::any('count','cart\CartController@count')->middleware('nomoney');
Route::any('cartdel','cart\CartController@cartdel')->middleware('nomoney');
//登录
Route::get('adminlogin','login\LoginContoller@adminlogin')->middleware('nomoney');
Route::any('codeImg/{tmp}','login\LoginContoller@codeImg')->middleware('nomoney');
Route::any('adminlogin_do','login\LoginContoller@adminlogin_do')->middleware('nomoney');
//管理员
//->middleware('rbac');
Route::get('admin','admin\AdminController@admin')->middleware('nomoney');
Route::post('adminadd','admin\AdminController@adminadd')->middleware('nomoney');
Route::any('adminlist','admin\AdminController@adminlist')->middleware('nomoney');
Route::any('admindel','admin\AdminController@admindel')->middleware('nomoney');
Route::any('admin_update','admin\AdminController@admin_update')->middleware('nomoney');
Route::any('admin_up','admin\AdminController@admin_up')->middleware('nomoney');
Route::any('role_list','admin\AdminController@role_list')->middleware('nomoney');
Route::any('admin_role','admin\AdminController@admin_role')->middleware('nomoney');




//品牌
Route::get('brand','brand\brandController@brand')->middleware('nomoney')->middleware('rbac');
Route::post('brandadd','brand\brandController@brandadd')->middleware('nomoney')->middleware('rbac');
Route::post('upload','brand\brandController@upload')->middleware('nomoney');
Route::get('brandlist','brand\brandController@brandlist')->middleware('nomoney');
Route::get('brandInfo','brand\brandController@brandInfo')->middleware('nomoney');//获取品牌信息
Route::post('brand_del','brand\brandController@brand_del')->middleware('nomoney');
Route::any('brand_update','brand\brandController@brand_update')->middleware('nomoney');
Route::any('brand_up','brand\brandController@brand_up')->middleware('nomoney');
//商品
Route::get('goodsbot','goods\GoodsController@goodsbot')->middleware('nomoney');
Route::post('goodsuploadi','goods\GoodsController@goodsuploadi')->middleware('nomoney');
Route::post('goodsadd','goods\GoodsController@goodsadd')->middleware('nomoney');
Route::post('uploadview','goods\GoodsController@uploadview')->middleware('nomoney');
Route::any('goodsInfo','goods\GoodsController@goodsInfo')->middleware('nomoney');
Route::any('goodsInfos','goods\GoodsController@goodsInfos')->middleware('nomoney');
Route::any('goodslist','goods\GoodsController@goodslist')->middleware('nomoney');
Route::any('goods_attr','goods\GoodsController@goods_attr')->middleware('nomoney');
Route::any('goods_del','goods\GoodsController@goods_del')->middleware('nomoney');
Route::any('attr_up','goods\GoodsController@attr_up')->middleware('nomoney');
Route::any('goodsDetail','goods\GoodsController@goodsDetail')->middleware('nomoney');
Route::any('getAttribute','goods\GoodsController@getAttribute')->middleware('nomoney');
Route::any('getattrdo','goods\GoodsController@getattrdo')->middleware('nomoney');
Route::any('product','goods\GoodsController@product')->middleware('nomoney');
Route::any('productdo','goods\GoodsController@productdo')->middleware('nomoney');
Route::any('goods_up','goods\GoodsController@goods_up')->middleware('nomoney');
Route::any('goodsup','goods\GoodsController@goodsup')->middleware('nomoney');
Route::any('history','goods\GoodsController@history')->middleware('nomoney');
Route::any('search','goods\GoodsController@search')->middleware('nomoney');
Route::any('length_good','goods\GoodsController@length_good')->middleware('nomoney');
Route::any('historyDel','goods\GoodsController@historyDel')->middleware('nomoney');
//分类
Route::get('cateadd','category\CateController@cateadd')->middleware('nomoney');
Route::any('catedo','category\CateController@catedo')->middleware('nomoney');
Route::any('cateshow','category\CateController@cateshow')->middleware('nomoney');
Route::any('catedelete','category\CateController@catedelete')->middleware('nomoney');
Route::any('getInfo','category\CateController@getInfo')->middleware('nomoney');//获取分类信息
Route::any('cateupdate','category\CateController@cateupdate')->middleware('nomoney');
Route::any('only','category\CateController@only')->middleware('nomoney');
//sku
Route::any('type','type\TypeController@type')->middleware('nomoney');
Route::any('typeadd','type\TypeController@typeadd')->middleware('nomoney');
Route::any('typedo','type\TypeController@typedo')->middleware('nomoney');
Route::any('typedelete','type\TypeController@typedelete')->middleware('nomoney');
Route::any('typeupdate','type\TypeController@typeupdate')->middleware('nomoney');
Route::any('typeupddo','type\TypeController@typeupddo')->middleware('nomoney');
//属性
Route::any('attr_do','attr\AttrController@attr_do')->middleware('nomoney');
Route::any('attradd','attr\AttrController@attradd')->middleware('nomoney');
Route::any('attr_show','attr\AttrController@attr_show')->middleware('nomoney');
Route::any('attr_del','attr\AttrController@attr_del')->middleware('nomoney');
Route::any('attr_update','attr\AttrController@attr_update')->middleware('nomoney');
Route::any('attr_update_do','attr\AttrController@attr_update_do')->middleware('nomoney');

//活动
Route::get('activity','Activity\ActivityController@activity')->middleware('nomoney');
Route::post('activityadd','Activity\ActivityController@activityadd')->middleware('nomoney');
Route::get('activitylist','Activity\ActivityController@activitylist')->middleware('nomoney');
Route::any('activitydel','Activity\ActivityController@activitydel')->middleware('nomoney');
Route::any('activityupdate','Activity\ActivityController@activityupdate')->middleware('nomoney');
Route::any('activityupdate_do','Activity\ActivityController@activityupdate_do')->middleware('nomoney');
//优惠券
Route::get('coupon','coupon\CouponController@coupon')->middleware('nomoney');
Route::post('couponadd','coupon\CouponController@couponadd')->middleware('nomoney');
Route::any('couponlist','coupon\CouponController@couponlist')->middleware('nomoney');
Route::post('coupondel','coupon\CouponController@coupondel')->middleware('nomoney');
Route::any('couponupdate','coupon\CouponController@couponupdate')->middleware('nomoney');
Route::any('couponupdate_do','coupon\CouponController@couponupdate_do')->middleware('nomoney');
Route::any('coupon_do','coupon\CouponController@coupon_do')->middleware('nomoney');
Route::any('getUserCoupon','coupon\CouponController@getUserCoupon')->middleware('nomoney');
//友链
Route::post('configadd','config\ConfigController@configadd')->middleware('nomoney');
Route::get('config','config\ConfigController@config')->middleware('nomoney');
Route::any('configlist','config\ConfigController@configlist')->middleware('nomoney');
Route::any('configdel','config\ConfigController@configdel')->middleware('nomoney');
Route::any('config_update','config\ConfigController@config_update')->middleware('nomoney');
Route::any('config_up','config\ConfigController@config_up')->middleware('nomoney');
Route::any('config_default','config\ConfigController@config_default')->middleware('nomoney');
Route::any('friend','config\ConfigController@friend')->middleware('nomoney');

//广告
Route::any('advert','advert\advertController@advert')->middleware('nomoney');
Route::any('advert_add','advert\advertController@advert_add')->middleware('nomoney');
Route::any('advertlist','advert\advertController@advertlist')->middleware('nomoney');
Route::any('advert_del','advert\advertController@advert_del')->middleware('nomoney');
Route::any('advert_a','advert\advertController@advert_a')->middleware('nomoney');
Route::any('advert_default','advert\advertController@advert_default')->middleware('nomoney');

//rbac
Route::any('node','node\nodeController@node')->middleware('nomoney');
Route::any('nodeadd','node\nodeController@nodeadd')->middleware('nomoney');
Route::any('nodelist','node\nodeController@nodelist')->middleware('nomoney');
Route::any('nodeInfo','node\nodeController@nodeInfo')->middleware('nomoney');
Route::any('nodedelete','node\nodeController@nodedelete')->middleware('nomoney');
Route::any('nodeupdate','node\nodeController@nodeupdate')->middleware('nomoney');



//角色添加
Route::any('role','role\roleController@role')->middleware('nomoney');
Route::any('roleadd','role\roleController@roleadd')->middleware('nomoney');
Route::any('rolelist','role\roleController@rolelist')->middleware('nomoney');
Route::any('roledel','role\roleController@roledel')->middleware('nomoney');
//用户地址
Route::any('addressAdd','address\AddressController@addressAdd')->middleware('nomoney');
Route::any('getregion','address\AddressController@getregion')->middleware('nomoney');
Route::any('selregion','address\AddressController@selregion')->middleware('nomoney');
Route::any('upaddress','address\AddressController@upaddress')->middleware('nomoney');
Route::any('addressGet','address\AddressController@addressGet')->middleware('nomoney');
Route::any('addressDel','address\AddressController@addressDel')->middleware('nomoney');

//订单
Route::any('order','order\orderController@order')->middleware('nomoney');
Route::any('address_order','order\orderController@address_order')->middleware('nomoney');
Route::any('orderc','order\orderController@orderc')->middleware('nomoney');
Route::any('order_list','order\orderController@order_list')->middleware('nomoney');
Route::any('order_del','order\orderController@order_del')->middleware('nomoney');
Route::any('orderGoods','order\orderController@orderGoods')->middleware('nomoney');
Route::any('orderte','order\orderController@orderte')->middleware('nomoney');
Route::any('order_status','order\orderController@order_status')->middleware('nomoney');
Route::any('order_success','order\orderController@order_success')->middleware('nomoney');
Route::any('pay','order\orderController@pay')->middleware('nomoney');
//分类品牌
Route::any('cb','cate\CateController@cb')->middleware('nomoney');
Route::any('cate_add','cate\CateController@cate_add')->middleware('nomoney');
Route::any('catelist','cate\CateController@catelist')->middleware('nomoney');
Route::any('cate_del','cate\CateController@cate_del')->middleware('nomoney');
Route::any('cate_update','cate\CateController@cate_update')->middleware('nomoney');
Route::any('cate_updatedo','cate\CateController@cate_updatedo')->middleware('nomoney');

//面部识别
Route::any('fice_add','upload\uploadcontroller@fice_add')->middleware('nomoney');
Route::any('fice_seach','upload\uploadcontroller@fice_seach')->middleware('nomoney');