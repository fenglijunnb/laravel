<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <div class="banneradd bor">
            <div class="baTop">
                <span>优惠劵添加</span>
            </div>
            <div class="baBody">
                <div class="bbD">
                    优惠劵名称：<input type="text" name="coupon_name" class="input1" />
                </div>
                <div class="bbD">
                    最大价格<input type="text" name="max_price" class="input1" />
                </div>
                <div class="bbD">
                    最小价格<input type="text" name="small_price" class="input1" />
                </div>
                 <div class="bbD">
                    优惠价格<input type="text" name="money" class="input1" />
                </div>
                <div class="bbD">
                    需要积分<input type="text" name="score" class="input1" />
                </div>
                <div class="bbD">
                    优惠劵可以开始使用时间：<input type="date" name="start_time" class="input1" />
                </div>
                <div class="bbD">
                    优惠劵过期时间：<input type="date" name="end_time" class="input1" />
                </div>
                {{--<div class="bbD">--}}
                    {{--是否显示：<label><input type="radio" name="show" value="0" />是</label> <label><input--}}
                                {{--type="radio" name="show" value="1" />否</label>--}}
                {{--</div>--}}
                <div class="bbD">
                    <p class="bbDP">
                        <button class="btn_ok btn_yes" href="#" id="sub">提交</button>
                        <a class="btn_ok btn_no" href="#">取消</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-1.7.2.min.js"></script>
<script>
    $('#sub').click(function () {
        var coupon_name=$("input[name='coupon_name']").val();
        var max_price=$("input[name='max_price']").val();
        var small_price=$("input[name='small_price']").val();
        var money=$("input[name='money']").val();
        var score=$("input[name='score']").val();
        var start_time=$("input[name='start_time']").val();
        var end_time=$("input[name='end_time']").val();
        // var show=$("input[name='show']:checked").val();
        $.ajax({
            type:'post',
            data:{'coupon_name':coupon_name,'max_price':max_price,'small_price':small_price,'money':money,'score':score,'start_time':start_time,'end_time':end_time},
            url:'couponadd',
            dataType:'json',
            success:function (msg) {
                if(msg.code==1){
                    alert(msg.msg);
                }else{
                    alert(msg.msg);
                    location.href="http://47.107.93.29:8080/couponlist"
                }
                
            }
        });

    })
</script>