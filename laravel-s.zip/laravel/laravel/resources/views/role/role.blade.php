<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <!-- 上传广告页面样式 -->
        <div class="banneradd bor">
            <div class="baTop">
                <span>角色添加</span>
            </div>
            <div class="baBody">
                <div class="bbD">
                   角色名称：<input type="text" name="node_name" id="role_name" class="input1" />
                </div>
                @foreach($arr as $v)
                <div class="bbD" id="{{$v['node_id']}}">
                    <input type="checkbox" name="node_id[]"  lay-filter="allbox" value="{{$v['node_id']}}" class="da">{{$v['node_name']}}
                    <div class="layui-field-box">
                        @foreach($v['0'] as $vv)
                        <input type="checkbox" name="node_id[{{$v['node_id']}}][]" value="{{$vv['node_id']}}" class="xiao dd">{{$vv['node_name']}}
                        @endforeach
                        <hr />
                    </div>
                </div>
                 @endforeach
                <div class="bbD">
                    <p class="bbDP">
                        <button class="btn_ok btn_yes" href="#" name="btn" id="btn">添加</button>
                        <a class="btn_ok btn_no" href="goods">取消</a>
                    </p>
                </div>
            </div>
        </div>
        <!-- 上传广告页面样式end -->
    </div>
</div>
</body>
</html>
<script>
    $(function(){
        $('.da').each(function(){
            $(this).click(function(){
                if($(this).prop('checked')){
                    $(this).parent().find('input').prop('checked',true);
                }else{
                    $(this).parent().find('input').prop('checked',false);
                }
            })    
        })  
       
        $('.xiao').each(function(){
            $(this).click(function(){
                if($(this).prop('checked')){
                    $(this).parent().siblings('.da').prop('checked',true);
                }else{
                    if($(this).prop('checked',false)&&!$(this).siblings().prop('checked')){
                        $(this).parent().siblings('.da').prop('checked',false);
                    }
                    
                }
            })
        })
        $('#btn').click(function(){
            var data={};
            var arr=[];
            var aa=[];
            var value='';
            $.each($('.da'),function(i,v){
                if($(this).prop('checked')){
                    if(($(this).val())!==''){
                        arr.push($(this).val());
                        $(this).siblings('.layui-field-box').find('input:checked').each(function(i,v){
                            aa.push(v.value);
                        });
                    }
                }
            })
            
            var role_name = $("#role_name").val();
            data.role_name = role_name;
            data.aa = aa;
            if(role_name==''){
                alert('角色名称不能为空');
                return false;
            }
            if(aa==''){
                alert('请选择权限节点');
                return false;
            }
            var url = "roleadd";
            $.ajax({
                type : "post",          
                dataType : "json",
                url : url,
                data:data,
                success:function(msg){
                    if(msg.code==1){
                        alert(msg.msg);
                        window.location.href="rolelist";
                    }else{
                        alert(msg.msg);
                    }
                }
            });
        })
    })  
</script>