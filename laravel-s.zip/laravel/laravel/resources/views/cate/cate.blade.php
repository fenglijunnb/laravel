<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <!-- 上传广告页面样式 -->
        <div class="banneradd bor">
            <div class="baBody">
                <div class="bbD">
                    商品分类：<select class="input3" name="cate_id" id="cate_id">
                        @foreach($arr as $k=>$v)
                            <option value="{{$v['cate_id']}}">{{str_repeat('&nbsp;&nbsp;',$v['level']*2)}}{{$v['cate_name']}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="bbD">
                    商品品牌：<select class="input3" name="brand_id" id="brand_id">
                        @foreach($data as $k=>$v)
                            <option value="{{$v['brand_id']}}">{{$v['brand_name']}}</option>
                        @endforeach
                    </select>
                </div>
                    <div class="bbD">
                        <p class="bbDP">
                            <button class="btn_ok btn_yes" href="#" id="sub">提交</button>
                            <a class="btn_ok btn_no" href="goods">取消</a>
                        </p>
                    </div>
                </div>
            </div>
            <!-- 上传广告页面样式end -->
        </div>
    </div>
</body>
</html>
<script src="/js/jquery.js"></script>
<script src="/js/ajaxfileupload.js"></script>
<script>
    $("#sub").click(function () {
        var data={};
        data.cate_id =  $('#cate_id option:selected').val();
        data.brand_id = $("#brand_id option:selected").val();
        $.ajax({
            type:'post',
            data:data,
            url:'cate_add',
            dataType:'json',
            success:function (msg) {
                if(msg.code==1){
                    alert(msg.msg);
                }else if(msg.code==2) {
                    alert(msg.msg);
                }else{
                    alert(msg.msg);
                    location.href="http://47.107.93.29:8080/catelist";
                }
            }
        });
    });
</script>