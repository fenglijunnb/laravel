<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
            <div class="bbD">
                <div class="bbD">
                    分类名称:<input type="text" name="cate_name"  placeholder="请输入分类名称" autocomplete="on"  class="input1">
                </div>
            </div>
            <div class="bbD">
                <div class="bbD">
                    是否展示: <input type="radio" name="cate_show" value="1" checked>是
                    <input type="radio" name="cate_show" value="2" >否
                </div>
            </div>
            <div class="bbD">
                <div class="bbD">
                    是否导航展示: <input type="radio" name="cate_navshow" value="1" checked>是
                    <input type="radio" name="cate_navshow" value="2" >否
                </div>
            </div>
            <div class="bbD">
                <div class="bbD">
                    所属分类:  <select name="pid" class="input3">
                        <option value="0">--请选择--</option>
                        @foreach($cateInfo as $v)
                            <option value="{{$v->cate_id}}">{{str_repeat('&nbsp;&nbsp;',$v->level*2)}}{{$v->cate_name}}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="bbD">
                <p class="bbDP">
                    <button class="btn_ok btn_yes" href="javascript:;">提交</button>
                    <a class="btn_ok btn_no" href="javascript">取消</a>
                </p>
            </div>
    </div>
</div>
</body>
</html>
<script>
    $(".btn_yes").click(function () {
        var flag=false;
        var cate_name=$("input[name='cate_name']").val();
        $.ajax({
            type:"post",
            dataType:"json",
            url:'only',
            data:{cate_name:cate_name},
            success:function(msg){
                if(msg.code==3){
                    alert(msg.msg);
                    flag=false
                }else{
                    var data={};
                    var cate_show=$("input[name='cate_show']:checked").val();
                    var cate_navshow=$("input[name='cate_navshow']:checked").val();
                    var cate_id=$("select[name='pid']").val();
                    data.cate_name=cate_name;
                    data.cate_show=cate_show;
                    data.cate_navshow=cate_navshow;
                    data.pid=cate_id;
                    $.ajax({
                        url : '/catedo',
                        type: 'post',
                        data : data,
                        dataType: 'json',
                        success: function(d){
                            if(d.code==1){
                                alert(d.msg);
                                location.href='/cateshow'
                            }else{
                                alert(d.msg);
                            }

                        }
                    })
                }
            }
        });

    });
</script>