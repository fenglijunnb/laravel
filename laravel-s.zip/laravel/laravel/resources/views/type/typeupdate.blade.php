<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <div class="banneradd bor">
            <input type="hidden" name="hidden" value="{{$arr->type_id}}">
            <div class="baBody">
                <div class="bbD">
                    类型名称：<input type="text" name="type_name" class="input1" value="{{$arr->type_name}}" />
                </div>
                <div class="bbD">
                    <p class="bbDP">
                        <button class="btn_ok btn_yes" href="#" id="sub">修改</button>
                        <a class="btn_ok btn_no" href="#">取消</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-1.7.2.min.js"></script>
<script>
    $('#sub').click(function () {
        var type_name=$("input[name='type_name']").val();
        var type_id=$("input[name='hidden']").val();
        if(type_name==''){
            alert('类型名称不能为空');
        }
        $.ajax({
            type:'post',
            data:{type_name:type_name,type_id:type_id},
            url:'typeupddo',
            dataType:'json',
            success:function (msg) {
                if(msg==1){
                    alert('修改成功');
                    window.location.href="type";
                }else{
                    alert('修改失败');
                }
                
            }
        });

    })
</script>