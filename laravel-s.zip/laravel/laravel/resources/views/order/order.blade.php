<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>广告-有点</title>
<link rel="stylesheet" type="text/css" href="css/css.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<!-- <script type="text/javascript" src="js/page.js" ></script> -->
</head>

<body>
	<div id="pageAll">
		<div class="pageTop">
			<div class="page">
				<img src="img/coin02.png" /><span><a href="#">首页</a>&nbsp;-&nbsp;<a
					href="#">订单管理</a>&nbsp;-</span>&nbsp;订单列表
			</div>
		</div>
		<div class="page">
			<!-- banner页面样式 -->
			<div class="banner">
				<!-- banner 表格 显示 -->
				<div class="banShow">
					<table border="1" cellspacing="0" cellpadding="0">
						<tr>
							<td width="66px" class="tdColor tdC">序号</td>
							<td width="315px" class="tdColor">订单编号</td>
							<td width="308px" class="tdColor">用户ID</td>
							<td width="450px" class="tdColor">订单总价</td>
							<td width="215px" class="tdColor">支付方式</td>
							<td width="180px" class="tdColor">订单状态</td>
							<td width="180px" class="tdColor">收货信息</td>
							<td width="180px" class="tdColor">订单创建时间</td>
						</tr>
						<tr>
							@foreach($arr as $k=>$v)
							<td>{{$v->order_id}}</td>
							<td>{{$v->order_sn}}</td>
							<td>{{$v->user_id}}</td>
							<td>{{$v->order_amount}}</td>
							@if($v->order_pay==1)
							<td>支付宝</td>
							@else
							<td>微信</td>
							@endif
							@if($v->order_pay_status==1)
							<td>未支付</td>
							@elseif($v->order_pay_status==2)
							<td>待发货</td>
							@else
							<td>已支付</td>
							@endif
							<td><a href="address_order?id={{$v->address_id}}">查看收货信息</a></td>
							<td>{{date('Y-m-d H:i:s',$v->create_time)}}</td>
						</tr>
						@endforeach
					</table>
					<div class="paging">{{$arr->links()}}</div>
				</div>
				<!-- banner 表格 显示 end-->
			</div>
			<!-- banner页面样式end -->
		</div>

	</div>
</body>


</html>
<script src="/js/jquery.js"></script>
<script>

</script>