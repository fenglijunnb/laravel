<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <!-- 上传广告页面样式 -->
        <div class="banneradd bor">
            <div class="baTop">
                <span>商品添加</span>
            </div>
            <div class="baBody">
                <div class="bbD">
                    商品名称：<input type="text" name="goods_name" class="input1" />
                </div>
                <div class="bbD">
                    商品分类：<select class="input3" name="cate_id" id="cate_id">
                        @foreach($arr as $k=>$v)
                        <option value="{{$v['cate_id']}}">{{str_repeat('&nbsp;&nbsp;',$v['level']*2)}}{{$v['cate_name']}}</option>

                        @endforeach
                    </select>
                </div>
                <div class="bbD">
                    商品品牌：<select class="input3" name="brand_id" id="brand_id">
                        @foreach($data as $k=>$v)
                        <option value="{{$v['brand_id']}}">{{$v['brand_name']}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="bbD">
                    商品价格：<input type="text" name="goods_price" class="input1" />
                </div>
                <div class="bbD">
                    商品介绍：<textarea name="goods_desc" id="" cols="30" rows="10"></textarea>
                </div>
                <div class="bbD">
                    商品状态：<input type="radio" name="is_show" value="0">不上架
                              <input type="radio" name="is_show" value="1">上架
                </div>
                <div class="bbD">
                    商品库存：<input type="text" name="goods_num" class="input1">
                </div>
                <div class="bbD">
                    是否热卖：<input type="radio" name="is_hot" value="0">热卖
                            <input type="radio" name="is_hot" value="1">非热卖
                </div>
                
               
                
                <div class="bbD">
                    市场价格：<input type="text" name="market_price" class="input1">
                </div>
                <div class="bbD">
                    购买商品所赠送的积分：<input type="text" name="point" class="input1">
                </div>
                <div class="bbD">
                    上传图片：
                        <input type="file" name="file"  id="file" />
                </div>
                <div class="bbD">
                    <div class="bbD">
                        多上传图片：
                        <div class="bbDd duo" >
                            <div class="bbDImg">+</div>
                            <input type="file" class="imgfile" id="img0"/>
                        </div>
                        <div class="bbDd duo" >
                            <div class="bbDImg">+</div>
                            <input type="file" class="imgfile"  id="img1"/>
                        </div>
                        <div class="bbDd duo" >
                            <div class="bbDImg">+</div>
                            <input type="file" class="imgfile"  id="img2"/>
                        </div>
                        <input type="hidden" id="images" value="">
                        <input type="button" onclick="imgfile()" value="上传多图片">
                    </div>
                <div class="bbD">
                    <p class="bbDP">
                        <button class="btn_ok btn_yes" href="#" id="sub">提交</button>
                        <a class="btn_ok btn_no" href="goods">取消</a>
                    </p>
                </div>
            </div>
        </div>


        <!-- 上传广告页面样式end -->
    </div>
</div>
</body>
</html>
<script src="/js/jquery.js"></script>
<script src="/js/ajaxfileupload.js"></script>
<script>    
    $('#sub').click(function(){
        var data = {};
        data.goods_name = $("input[name='goods_name']").val();
        data.cate_id =  $('#cate_id option:selected').val();
        //lert(data.cate_id);
        data.brand_id = $("#brand_id option:selected").val();
        data.goods_price = $("input[name='goods_price']").val();
        data.goods_desc = $("textarea[name='goods_desc']").val();
        data.is_show = $("input[name='is_show']:checked").val();
        data.goods_num = $("input[name='goods_num']").val();
       // data.goods_recommend = [];
        // $("input[name='goods_recommend']:checked").each(function(){
        //         data.goods_recommend.push($(this).val());
        // });
        data.is_hot = $("input[name='is_hot']:checked").val();

        data.goods_imgs = $('#images').val();
        data.market_price = $("input[name='market_price']").val();
        data.score = $("input[name='point']").val();
        status = 2;
         console.log(data);
        $.ajaxFileUpload({
            type:'post',
            url:'goodsuploadi',
            secureuri:false,
            fileElementId:'file',
            dataType:'json',
            success:function(msg){
                if(msg.code==0){
                    data.goods_img = msg.img;
                  //  console.log(data);return false;
                   $.ajax({
                        type:'post',
                        data:data,
                        url:'goodsadd',
                        success:function(mag){
                            if(mag==1){
                                window.location.href="goodslist";
                            }
                        }
                    });
                }else{
                    alert("添加失败");
                }
            }
        });         
    });

    function imgfile() {
        var imgfile=[];
        $(".imgfile").each(function () {
            imgfile.push($(this)[0].files[0]);
        });
        var form = new FormData();//表单对象
        $(imgfile).each(function (i,v) {
            form.append("file"+i,v,v.name);
        });
        $.ajax({
            type : "post",
            data : form,
            url : "uploadview",
            processData : false,
            contentType : false,
            cache : false,
            dataType : "json",
            async : true,
            success : function( res ){
                $(res).each(function (i,v) {
                    $(".duo").eq(i).html("<img src="+"/"+v+" width='200px' height='200px'>");
                });
                var b='';
                b=res.join(',');
                $("#images").val(b);
            }
        });
    }
</script>
