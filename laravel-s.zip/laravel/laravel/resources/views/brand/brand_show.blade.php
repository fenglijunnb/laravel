<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>约见管理-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <link rel="stylesheet" href="/css/bootstrap.min.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <!-- <script type="text/javascript" src="js/page.js" ></script> -->
</head>

<body>
<div id="pageAll">


    <div class="page">
        <!-- banner页面样式 -->
        <div class="connoisseur">
            <!-- banner 表格 显示 -->
            <div class="conShow">
                <table border="1" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="66px" class="tdColor tdC">商品品牌id</td>
                        <td width="355px" class="tdColor">商品品牌名称</td>
                        <td width="355px" class="tdColor">商品品牌logo</td>
                        <td width="130px" class="tdColor">操作</td>
                    </tr>
                    @foreach($data as $v)
                    <tr>
                        <td width="66px" class=" tdC">{{$v->brand_id}}</td>
                        <td width="355px" >{{$v->brand_name}}</td>
                        <td width="355px">
                            <img class="operation" src="{{$v->brand_logo}}" width="100px;" height="100px;">
                        </td>
                        <td>
                            <a href="brand_update?id={{$v->brand_id}}">
                                <img class="operation" src="img/update.png">
                            </a>
                            <img class="operation delban" src="img/delete.png" id="{{$v->brand_id}}">
                        </td>
                    </tr>
                    @endforeach
                </table>
                <div class="paging">{{$data->links()}}</div>
            </div>
            <!-- banner 表格 显示 end-->
        </div>
        <!-- banner页面样式end -->
    </div>

</div>

</body>
 
</html>
<script>
    $(document).ready(function(){
        $('.delban').click(function(){
            var data={};
            var _this=$(this);
            var id=_this.attr('id');
            data.id=id;
            var url='brand_del';
            $.ajax({
                type: 'post',
                data: data,
                url: url,
                dataType: 'json',
                success: function (msg) {
                    //console.log(res);
                    if(msg.code==1){
                        alert(msg.msg);
                        _this.parents('tr').remove()
                    }
                }
            })        
        })

    })
</script>