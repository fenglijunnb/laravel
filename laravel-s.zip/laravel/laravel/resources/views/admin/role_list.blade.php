<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>约见管理-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <link rel="stylesheet" href="/css/bootstrap.min.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <!-- <script type="text/javascript" src="js/page.js" ></script> -->
</head>

<body>
<div id="pageAll">
    <div class="page">
        <!-- banner页面样式 -->
        <div class="connoisseur">
            <!-- banner 表格 显示 -->
            <div class="conShow">
            	<input type="hidden" value="{{$admin_id}}" id="admin_id" />
                <table border="1" cellspacing="0" cellpadding="0">
                	<div class="bbD">
                		可选角色：
	                    @foreach($data as $v)
	                    <tr>
                            @if(!empty($res))
                                @if(in_array($v->role_id,$res))
                                <input type="checkbox" value="{{$v->role_id}}" class="role_id" checked/>{{$v->role_name}}
                                @else
                                <input type="checkbox" value="{{$v->role_id}}" class="role_id"  />{{$v->role_name}}
                                @endif
                            @else
                                <input type="checkbox" value="{{$v->role_id}}" class="role_id"  />{{$v->role_name}}
                            @endif
	                    </tr>
	                    @endforeach
                    </div>
					<div class="bbD">
	                    <p class="bbDP">
	                        <button class="btn_ok btn_yes" href="#" name="btn">确定</button>
	                    </p>
	                </div>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script>
$(document).ready(function(){
    $("button[name='btn']").click(function(){
        var admin_id = $("#admin_id").val();
        var role_id=[];
        $.each($('.role_id:checked'),function(i,v){
        	if($(this).prop('checked')){
            	role_id.push($(this).val());
        	}
        })
        var url = "admin_role";
        $.ajax({
            type : "post",          
            dataType : "json",
            url : url,
            data:{admin_id:admin_id,role_id:role_id},
            success:function(msg){
                if(msg.code==1){
                    alert(msg.msg);
                    window.location.href="adminlist";
                }else{
                    alert(msg.msg);
                }
            }
        });
    });
});
   
</script>