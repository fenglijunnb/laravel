<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>头部-有点</title>
    <link rel="stylesheet" type="text/css" href="css/css.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
<div id="pageAll">
    <div class="page ">
        <!-- 上传广告页面样式 -->
        <div class="banneradd bor">
            <div class="baTop">
                <span>节点添加</span>
            </div>
            <div class="baBody">
                <div class="bbD">
                   节点名称：<input type="text" name="node_name" id="node_name"class="input1" />
                </div>
                <div class="bbD">
                   控制器名：<input type="text" name="controller_name" id="controller_name" class="input1" />
                </div>
                <div class="bbD">
                   方法名称：<input type="text" name="action_name" id="action_name" class="input1" />
                </div>
                <div class="bbD">
                    所属分类:  <select id="pid" class="input3">
                        <option value="0">--请选择--</option>
                        @foreach($data as $v)
                            <option value="{{$v->node_id}}">{{$v->node_name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="bbD">
                    <p class="bbDP">
                        <button class="btn_ok btn_yes" href="#" name="btn">添加</button>
                        <a class="btn_ok btn_no" href="goods">取消</a>
                    </p>
                </div>
            </div>
        </div>
        <!-- 上传广告页面样式end -->
    </div>
</div>
</body>
</html>
<script>
$(document).ready(function(){
    $("button[name='btn']").click(function(){
        var data={};
        var action_name = $("#action_name").val();
        var node_name = $("#node_name").val();
        var controller_name = $("#controller_name").val();
        var pid = $("#pid").val();
        data.action_name = action_name;
        data.node_name = node_name;
        data.controller_name = controller_name;
        data.pid = pid;
        data.url = url;
        var url = "nodeadd";
        $.ajax({
            type : "post",          
            dataType : "json",
            url : url,
            data:data,
            success:function(msg){
                if(msg.code==1){
                    alert(msg.msg);
                    location.href="http://47.107.93.29:8080/nodelist";
                }else{
                    alert(msg.msg);
                }
            }
        });
    });
});
   
</script>