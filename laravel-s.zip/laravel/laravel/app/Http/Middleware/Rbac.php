<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Rbac
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $session = $request->session();
        $admin_id = $session->get('admin_id');
        if(empty($admin_id)){
           echo "<script>alert('尚未登陆');top.location.href='adminlogin'</script>";die;
        };
        $route = $request->path();
        $partData = DB::table('admin_role')->join('role','admin_role.role_id','=','role.role_id')->where('admin_id',$admin_id)->get();
        $part_id = [];
        foreach($partData as $v){
            $part_id[] = $v->role_id;
        }
        $perData = DB::table('role_node')->join('node','node.node_id','=','role_node.node_id')->whereIn('role_id',$part_id)->get();
        $Rurl = \Request::getRequestUri();
        $url = str_replace('/','',$Rurl);

        $arr = [];
        foreach($perData as $v){
            $arr[] = $v->action_name;
        }

        if (in_array("$url", $arr)){
            //return $next($request);
        }else{
            echo "<img src='./img/timg.jpg'>";die;
        }

        return $next($request);
    }
}
