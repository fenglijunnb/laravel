<?php

namespace App\Http\Middleware;

use Closure;

class NoMoney
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $objredis=new \redis();
        $objredis->connect("127.0.0.1",6379);
        $token="token_list";
        $data=$objredis->sPop($token);
        if(empty($data)){
            echo "调用频繁，请稍后重试";die;
        }
        return $next($request);
    }
}
