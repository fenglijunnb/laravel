<?php

namespace App\Http\Controllers\category;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class CateController extends Controller
{
    /**
     * 分类页面添加
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function cateadd()
    {
        $cateWhere = [
            'cate_show' => 1
        ];
        $cateInfo = DB::table('category')->where($cateWhere)->get()->toArray();
        $cateInfo = cateInfo($cateInfo);
        //获取分类
	return view('category.categoryadd', ['cateInfo' => $cateInfo]);
    }

    /**
     * 添加执行
     * @param Request $request
     * @return int
     */
    public function catedo(Request $request)
    {
        $data = $request->input();
        $cate_id = $data['pid'];
        $parent_data = DB::table('category')->where('cate_id', $cate_id)->get()->toArray()[0];
        $data['level'] = $parent_data->level + 1;
        $data['create_time'] = time();
        $res = DB::table('category')->insert($data);
        if ($res) {
            return json_encode(['code'=>1,'msg'=>'添加成功']);
        } else {
            return json_encode(['code'=>0,'msg'=>'添加失败']);
        }
    }

    /**
     * 分类展示
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function cateshow()
    {
        $data = $this->getInfo();
        return view('category.categoryshow', ['data' => $data]);
    }

    /**
     * 分类数据
     * @return array
     */
    public function getInfo()
    {
        $data = DB::table('category')->where('cate_show', 1)->get()->toArray();
        $info = cateInfo($data);
        return $info;
    }

    /**
     * 删除
     * @param Request $request
     * @return int
     */
    public function catedelete(Request $request)
    {
        $cate_id = $request->input('cate_id');
        $count = DB::table('category')->where('pid', $cate_id)->count();
        if ($count > 0) {
            return json_encode(['code'=>2,'msg'=>'此分类下有子分类']);
        }
        $res =DB::table('category')->where(['cate_id' => $cate_id])->delete();
        if ($res) {
            return json_encode(['code'=>1,'msg'=>'删除成功']);
        } else {
            return json_encode(['code'=>0,'msg'=>'删除失败']);
        }
    }

    /**
     * 修改
     * @param Request $request
     * @return int
     */
    public function cateupdate(Request $request)
    {
        $value=$request->input('value');
        $field=$request->input('field');
        $cate_id=$request->input('cate_id');
        $where=[
            'cate_id'=>$cate_id
        ];
        $data=[
            $field=>$value
        ];
        $result=DB::table('category')->where($where)->update($data);
        if($result){
            return 1;
        }else{
            return 0;
        }
    }

    /**
     * 验证唯一性
     * @param Request $request
     * @return int
     */
    public function only(Request $request){
        $username=$request->input('cate_name');
        $res=DB::table('category')->where('cate_name',"$username")->first();
        if(!empty($res)){
            return json_encode(['code'=>3,'msg'=>'已有重复分类']);
        }else{
            return json_encode(['code'=>1,'msg'=>'']);
        }
    }
}
