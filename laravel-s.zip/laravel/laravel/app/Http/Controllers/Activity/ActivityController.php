<?php
namespace App\Http\Controllers\Activity;
use App\model\Goods;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\ActivityModel;
class ActivityController extends Controller
{
    /**
     * 活动视图
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function activity(){
        $arr =file_get_contents("http://47.107.93.29:8080/goodsInfos");
        $arr=json_decode($arr,true);
        return view('activity.activity',['arr'=>$arr]);
    }

    /**
     * 活动添加
     * @param Request $request
     * @return false|string
     */
    public function activityadd(Request $request){
        $arr=$request->input();
        $good=$request->input('good');
        $arr['time']=time();
        $arr['start_time']=strtotime($arr['start_time']);
        $arr['end_time']=strtotime($arr['end_time']);
        if($arr['name']==''){
            return json_encode(['code'=>1,'msg'=>'活动名称不能为空']);
        }
        if($arr['activity_rules']==''){
            return json_encode(['code'=>1,'msg'=>'活动规则不能为空']);
        }
        if($arr['activity_content']==''){
            return json_encode(['code'=>1,'msg'=>'活动描述不能为空']);
        }
        if($arr['start_time']==''){
            return json_encode(['code'=>1,'msg'=>'活动开始时间不能为空']);
        }
        if($arr['end_time']==''){
            return json_encode(['code'=>1,'msg'=>'活动到期时间不能为空']);
        }
        unset($arr['good']);
        $id=ActivityModel::insertGetId($arr);
        Goods::where('goods_id',$good)->update(['activity_id'=>$id]);
        return json_encode(['code'=>0,'msg'=>'添加成功']);
    }

    /**
     * 活动展示
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function activitylist(){
        date_default_timezone_set('PRC');
        $data=ActivityModel::paginate(2)->toarray();
        $time=time();
        foreach ($data['data'] as $k=>$v){
            $start_time=$v['start_time'];
            $end_time=$v['end_time'];
            $id=$v['activity_id'];
            if ($time<$start_time){
                ActivityModel::where('activity_id',$id)->update(['is_delete'=>0]);
            }elseif ($time>$start_time&&$time<$end_time){
                ActivityModel::where('activity_id',$id)->update(['is_delete'=>1]);
            }elseif ($time>$end_time){
                ActivityModel::where('activity_id',$id)->update(['is_delete'=>2]);
            }
        }
        $data=ActivityModel::where('show',1)->paginate(2);
        return view('activity.activitylist',['data'=>$data]);
    }

    /**
     * 活动删除
     * @param Request $request
     * @return false|string
     */
    public function activitydel(Request $request){
        $activity_id=$request->input('id');
        $arr=[
            'show'=>0
        ];
        $data=ActivityModel::where('activity_id',$activity_id)->update($arr);
        if($data){
            return json_encode(['code'=>0,'msg'=>'删除成功']);
        }else{
            return json_encode(['code'=>1,'msg'=>'删除失败']);
        }
    }

    /**
     * 活动修改
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function activityupdate(Request $request){
        $dataInfo =file_get_contents("http://47.107.93.29:8080/goodsInfos");
        $arr=json_decode($dataInfo,true);
        $id=$request->input('id');
        $data=ActivityModel::where('activity_id',$id)->first();
        $data['start_time']=date('Y-m-d H:i:s',$data['start_time']);
        $data['end_time']=date('Y-m-d H:i:s',$data['end_time']);
        return view('activity.activityupdate',['arr'=>$arr,'data'=>$data]);
    }

    /**
     * 活动执行修改
     * @param Request $request
     * @return false|string
     */
    public function activityupdate_do(Request $request){
        $data=$request->input();
        $data['start_time']=strtotime($data['start_time']);
        $data['end_time']=strtotime($data['end_time']);
        $id=$request->input('hidden');
        unset($data['hidden']);
        $arr=ActivityModel::where('activity_id',$id)->update($data);
        if($arr){
            return json_encode(['code'=>0,'msg'=>'修改成功']);
        }else{
            return json_encode(['code'=>1,'msg'=>'修改失败']);
        }
    }
}