<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\model\CouponModel;

class UserController extends Controller
{
    /**
     * 用户注册
     * @param Request $request
     * @return false|string
     */
	public function register(Request $request){
		$user_tel=$request->input('user_name');
		$userPwd=$request->input('user_pwd');
        $code=$request->input('user_code');
		$repwd=$request->input('repwd');
		$user_pwd=md5($userPwd);
		if(empty($user_tel)){
			return json_encode(['code'=>1,'msg'=>'手机号不能为空']);
		}else if(empty($user_pwd)){
            return json_encode(['code'=>1,'msg'=>'密码不能为空']);
        } else if($user_pwd!=md5($repwd)){
            return json_encode(['code'=>1,'msg'=>'密码与确认密码不一致']);
		}else if(empty($code)){
            return json_encode(['code'=>1,'msg'=>'验证码不能为空']);
        }
        //判断用户唯一
        $where=[
            'user_tel'=>$user_tel
        ];
        $arr=Db::table('register')->where($where)->first();
        $user_id=$arr->user_id;
        $user_code=$arr->user_code;
        $status=$arr->status;
        if(!empty($arr) && $status==2){
            return json_encode(['code'=>1,'msg'=>'用户已存在']);
        }
        if($code!=$user_code){
            return json_encode(['code'=>1,'msg'=>'验证码有误']);
        }

        //用户添加入库
		$arrInfo=[
            'user_pwd'=>"$user_pwd",
            'create_time'=>time()
        ];
		$data=DB::table('register')->where('user_id',$user_id)->update($arrInfo);

		if($data){
            Db::table('register')->where('user_id',$user_id)->update(['status'=>2]);
            $arrInfo=DB::table('register')->orderBy('timeout','desc')->first();
            $user_id=$arrInfo->user_id;
            //入用户积分表
            $scoreInfo=[
                'user_id'=>$user_id,
                'score'=>0
            ];
            DB::table('user_score')->insert($scoreInfo);
            //user_id入用户信息表
            $userInfo=[
                'user_id'=>$user_id
            ];
            DB::table('userInfo')->insert($userInfo);
            return json_encode(['code'=>2,'msg'=>'注册成功']);
        }else{
            return json_encode(['code'=>1,'msg'=>'注册失败']);
        }
	}

    /**
     * 获取验证码
     * @param Request $request
     */
	public function getCode(Request $request){
	    $user_tel=$request->input('user_name');
        if(empty($user_tel)){
            return json_encode(['code'=>1,'msg'=>'手机号不能为空']);
        }
	    $user_code=rand(1000,9999);
	    $bool=100;
	    if($bool==100){
	        $arr=[
	            'user_tel'=>$user_tel,
                'user_code'=>$user_code,
                'timeout'=>time()+60,
                'status'=>1
            ];
	        $res=DB::table('register')->insert($arr);
	        var_dump($res);
        }
    }

    /**
     * 个人中心
     * @param Request $request
     * @return false|string
     */
    public function center(Request $request){
	    $user_id=$request->input('user_id');
	    $user_name=DB::table('register')->where('user_id',$user_id)->value('user_tel');
	    if(empty($user_id)){
            return json_encode(['code'=>1]);
        }else{
            return json_encode(['code'=>2,'user_id'=>$user_name]);
        }
    }

    /**
     * 登录执行
     * @param Request $request
     * @return false|string
     */
	public function login(Request $request){
        $user_tel=$request->input('user_name');
        $userPwd=$request->input('user_pwd');
        $user_pwd=md5($userPwd);
        //验证非空
        if(empty($user_tel)){
            return json_encode(['code'=>1,'msg'=>'用户名不能为空']);
        }else if(empty($user_pwd)){
            return json_encode(['code'=>1,'msg'=>'密码不能为空']);
        }
        $where=[
            'user_tel'=>$user_tel,
        ];
        $data=Db::table('register')->where($where)->first();

        if(!empty($data)){
            $user_id=$data->user_id;
            $time=time();
            $error_num=$data->error_num;
            $last_error_time=$data->last_error_time;

            if($data->user_pwd == $user_pwd){
                if($error_num >= 5 && $time-$last_error_time < 3600){
                    $m=60-floor(($time-$last_error_time)/60);
                    return json_encode(['code'=>1,'msg'=>'您还有'.$m.'分钟可以登录']);
                }
                return json_encode(['code'=>2,'msg'=>'登录成功','user_id'=>$user_id]);
            }else{
                if($time-$last_error_time>3600) {
                    $updateInfo = [
                        'error_num' => 1,
                        'last_error_time' => $time
                    ];
                    $res = Db::table('register')->where('user_id',$user_id)->update($updateInfo);
                    if($res){
                        $num=5-$error_num;
                        return json_encode(['code'=>1,'msg'=>'您错了一次，还有四次机会']);
                    }
                }else{
                    if($error_num>=5){
                        $m=60-floor(($time-$last_error_time)/60);
                        return json_encode(['code'=>1,'msg'=>'您还有'.$m.'分钟可以登录']);
                    }else{
                        $error_num+=1;
                        $updateInfo=[
                            'error_num'=>$error_num,
                            'last_error_time'=>$time,
                        ];
                        $res = Db::table('register')->where('user_id',$user_id)->update($updateInfo);
                        if($res){
                            $num=5-$error_num;
                            if($num==0){
                                return json_encode(['code'=>1,'msg'=>'账号已锁定，请一小时后重新登录']);
                            }else{
                                return json_encode(['code'=>1,'msg'=>'您错误了'.$error_num.'次'.',还有'.$num.'次机会']);
                            }
                        }
                    }
                }
            }
        }else{
            return json_encode(['code'=>1,'msg'=>'账号有误']);
        }
    }

    /**
     * 修改密码
     * @param Request $request
     * @return false|string
     */
    public function upPwd(Request $request){
	    $user_tel=$request->input('user_name');
	    $user_code=$request->input('user_code');
	    $uppwd=$request->input('upPwd');
	    $repwd=$request->input('rePwd');
	    $upPwd=md5($uppwd);
	    $rePwd=md5($repwd);
        //查询数据库
        $where=[
            'user_tel'=>$user_tel,
        ];
        $arr=DB::table('register')->where($where)->first();
	    $code=$arr->user_code;

	    if(empty($user_tel)){
            return json_encode(['code'=>1,'msg'=>'用户名不能为空']);
        }else if(empty($user_code)){
            return json_encode(['code'=>1,'msg'=>'验证码不能为空']);
        }else if(empty($upPwd)){
            return json_encode(['code'=>1,'msg'=>'新密码不能为空']);
        }else if(empty($rePwd)){
            return json_encode(['code'=>1,'msg'=>'确认密码不能为空']);
        }else if($user_code!=$code){
            return json_encode(['code'=>1,'msg'=>'验证码错误']);
        }
        //判断密码与确认密码
        if($arr){
            if($upPwd!=$rePwd){
                return json_encode(['code'=>1,'msg'=>'新密码与确认密码不一致']);
            }
        }
        //修改数据库
        $user_id=$arr->user_id;
        $updateInfo=[
            'user_pwd'=>$rePwd
        ];
        $data=Db::table('register')->where('user_id',$user_id)->update($updateInfo);
        if($data){
            return json_encode(['code'=>2,'msg'=>'修改成功']);
        }else{
            return json_encode(['code'=>1,'msg'=>'修改失败']);
        }
    }

    /**
     * 完善个人资料
     * @param Request $request
     * @return false|string
     */
    public function userInfo(Request $request){
        $user_age=$request->input('user_age');
        $user_school=$request->input('user_school');
        $user_email=$request->input('user_email');
        $user_id=$request->input('user_id');
        $user_name=$request->input('user_name');
        $updateInfo=[
            'user_age'=>$user_age,
            'user_school'=>$user_school,
            'user_email'=>$user_email,
            'user_name'=>$user_name,
            'update_time'=>time()
        ];
        $data=DB::table('userInfo')->where('user_id',$user_id)->update($updateInfo);
        if($data){
            return json_encode(['code'=>1,'msg'=>'完善成功']);
        }else{
            return json_encode(['code'=>2,'msg'=>'完善失败']);
        }
    }

    /**
     * 用户信息
     * @param Request $request
     * @return false|string
     */
    public function userData(Request $request){
        $user_id = $request->input('user_id');
        $where = [
            'user_id' => $user_id
        ];
        $arrInfo = DB::table('userInfo')->where($where)->first();
        $arr = json_encode($arrInfo,256);
        return $arr;
    }

    /**
     * 获取积分
     * @param Request $request
     * @return mixed
     */
    public function score(Request $request){
        $user_id=$request->input('user_id');
        $arr=DB::table('user_score')->where('user_id',$user_id)->value('score');
        return $arr;
    }

    /**
     * 积分兑换优惠券
     * @param Request $request
     * @return false|string
     */
    public function duihuan(Request $request){
        $score=$request->input('score');
        $data=CouponModel::where('score','<=',$score)->get()->toArray();
        foreach ($data as $key => $value) {
            $data[$key]['start_time']=date("Y.m.d",$value['start_time']);
            $data[$key]['end_time']=date("Y.m.d",$value['end_time']);
            $data[$key]['time']=date("Y.m.d",$value['time']);
        }
        $arr = json_encode($data,256);
        return $arr;
    }

    /**
     * 兑换优惠卷减积分
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function score_user(Request $request){
        $user_id = $request->input('user_id');
        $coupon_id = $request->input('coupon_id');
        $data = [
            'user_id'=>$user_id,
            'coupon_id'=>$coupon_id
        ];
        $res = DB::table('user_coupon')->insert($data);
        if($res){
            $coupon = DB::table('activity_coupon')->where('coupon_id','=',$coupon_id)->first();
            $user = DB::table('user_score')->where('user_id','=',$user_id)->first();
            $a = $user->score-$coupon->score;
            $score = [
                'score'=>$a
            ];
            $r = DB::table('user_score')->where('user_id','=',$user_id)->update($score);
                if($r){
                    return 200;
                }
        }
    }

    public function coupon_show(Request $request){
        $user_id = $request->input('user_id');
        $show = $request->input('show');
        $where = [
            'user_id'=>$user_id,
            'show'=>$show
        ];
        $data = DB::table('user_coupon')->where($where)->get();
        $arr = [];
        foreach($data as $k=>$v){
            $w = [
                'coupon_id'=>$v->coupon_id
            ];
            $arr[] = CouponModel::where($w)->first()->toArray();
        }
        foreach ($arr as $key => $value) {
            $arr[$key]['start_time']=date("Y.m.d",$value['start_time']);
            $arr[$key]['end_time']=date("Y.m.d",$value['end_time']);
            $arr[$key]['time']=date("Y.m.d",$value['time']);
        }
        return json_encode($arr,256);
    }

}