<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller{
	public function admin(){
		return view("admin.admin");
	}


	public function adminadd(Request $request){
		$admin_name=$request->input('admin_name');
		$name=DB::table('admin')->where('admin_name',$admin_name)->first();
		if($name){
			return (['code'=>0,'msg'=>'用户名已存在']);
		}
		$password=$request->input('password');
		$tel=$request->input('tel');
		$create_time=time();
		$password=md5($password);
		$arr=array(
			'admin_name'=>$admin_name,
			'password'=>$password,
			'create_time'=>$create_time,
			'tel'=>$tel
		);
		$data=DB::table('admin')->insert($arr);
		if($arr){
            return (['code'=>1,'msg'=>'添加成功']);
        }else{
            return (['code'=>0,'msg'=>'添加失败']);
        }
	}

	public function adminlist(){
		$data=DB::table('admin')->paginate(3);
		return view('admin.admin_show',['data'=>$data]);
	}

	public function admindel(Request $request){
		$id=$request->input('id');
        $arr=[
            'admin_del'=>2
        ];
        $data=DB::table('admin')->where('admin_id',$id)->update($arr);
        if($data){
            return (['code'=>1,'msg'=>'删除成功']);
        }else{
            return (['code'=>0,'msg'=>'删除失败']);
        }
	}

	public function admin_update(Request $request){
		$id=$request->input('id');
        $data=DB::table('admin')->where('admin_id',$id)->first();
        return view('admin.admin_update',['data'=>$data]);
	}

	public function admin_up(Request $request){
		$admin_name=$request->input('admin_name');
        $id=$request->input('hidden');
        $tel=$request->input('tel');
        $data=DB::table('admin')->where('admin_id',$id)->update(['admin_name'=>$admin_name,'tel'=>$tel]);
        if($data){
            return (['code'=>1,'msg'=>'修改成功']);
        }else{
            return (['code'=>0,'msg'=>'修改失败']);
        }
	}

	public function role_list(Request $request){
		$admin_id=$request->input('admin_id');
		$data=DB::table('role')->get();
		$role=DB::table('admin_role')->where('admin_id',$admin_id)->get()->toArray();
		if(!empty($role)){
			foreach ($role as $key => $value) {
			$res[]=$value->role_id;
			}
		}else{
			$res = [];
		}
		
		// print_r($res);exit;
		return view('admin.role_list',['data'=>$data,'admin_id'=>$admin_id,'res'=>$res]);
	}

	public function admin_role(Request $request){
		$admin_id=$request->input('admin_id');
		$role_id=$request->input('role_id');
		$where = [
			'admin_id'=>$admin_id
		];
		$es = DB::table('admin_role')->where($where)->delete();
		foreach ($role_id as $key => $value) {
			$arr[$key]=[
				'admin_id'=>$admin_id,
				'role_id'=>$value
			];
		}
		$data=DB::table('admin_role')->insert($arr);
		if($data){
            return (['code'=>1,'msg'=>'ok']);
        }else{
            return (['code'=>0,'msg'=>'ok']);
        }
	}

}