<?php

namespace App\Http\Controllers\brand;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;
use Storage;

class brandController extends Controller{
	public function brand(){
		return view("brand.brand");
	}

	public function brandadd(Request $request){
		$brand_name=$request->input('brand_name');
        if(!$brand_name){
            echo "品牌名称不能为空";die;
        }
		// print_r($brand_name);
		$date=date('Ymd');
        $key='black.log';
        $filename=Redis::get($key);
        $brand_log='/uploads/'.$date.'/'.$filename;
        $data=array(
        	'brand_name'=>$brand_name,
        	'brand_logo'=>$brand_log
        );
        if(!empty($data['brand_name'])){
            $arr=DB::table('brand')->insert($data);
            if($arr){
                return (['code'=>1,'msg'=>'添加成功']);
            }else{
                return (['code'=>0,'msg'=>'添加失败']);
            }
        }
        

	}

	public function upload(Request $request){
        if ($request->isMethod('POST')){
            $file = $request->file('file');
            //判断文件是否上传成功
            if ($file->isValid()){
                //原文件名
                $originalName = $file->getClientOriginalName();
                //扩展名
                $ext = $file->getClientOriginalExtension();
                //MimeType
                $type = $file->getClientMimeType();
                //临时绝对路径
                $realPath = $file->getRealPath();
                $filename = rand().'.'.$ext;
                Storage::disk('uploads')->put($filename,file_get_contents($realPath));
                $key='black.log';
                Redis::set($key,$filename);
                Redis::setTimeout($key, 3600);
            }
        }
       // return view('upload');
    }

    public function brandlist(){
        $data=DB::table('brand')->where('brand_del',1)->paginate(3);
        return view('brand.brand_show',['data'=>$data]);
    }

    public function brandInfo(){
        $data =DB::table('brand')->get();
        return $data;
    }

    public function brand_del(Request $request){
        $id=$request->input('id');
        $arr=[
            'brand_del'=>2
        ];
        $data=DB::table('brand')->where('brand_id',$id)->update($arr);
        if($data){
            return (['code'=>1,'msg'=>'删除成功']);
        }else{
            return (['code'=>0,'msg'=>'删除失败']);
        }
    }

    public function brand_update(Request $request){
        $id=$request->input('id');
        $data=DB::table('brand')->where('brand_id',$id)->first();
        return view('brand.brand_update',['data'=>$data]);
    }

    public function brand_up(Request $request){
        $brand_name=$request->input('brand_name');
        $id=$request->input('hidden');
        $data=DB::table('brand')->where('brand_id',$id)->update(['brand_name'=>$brand_name]);
        if($data){
            return (['code'=>1,'msg'=>'修改成功']);
        }else{
            return (['code'=>0,'msg'=>'修改失败']);
        }
    }


}