<?php

namespace App\Http\Controllers\role;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\model\nodeModel;


class roleController extends Controller{
	public function role(){
		$arr=nodeModel::where('pid',0)->get()->toArray();
		foreach ($arr as $key => $value) {
			$arr[$key][]=nodeModel::where('pid',$value['node_id'])->get()->toArray();
		}
		return view("role.role",['arr'=>$arr]);
	}

	public function roleadd(Request $request){
		$aa=$request->input('aa');
		$role_name=$request->input('role_name');
		$arr=array(
			'role_name'=>$role_name
		);
		// print_r($aa);
		$roleId=DB::table('role')->insertgetId($arr);
		// print_r($roleId);exit;
		foreach ($aa as $key => $value) {
			$c[$key]=[
				'role_id'=>$roleId,
				'node_id'=>$value
			];
		}
		$res=DB::table('role_node')->insert($c);
		if($res){
            return (['code'=>1,'msg'=>'添加成功']);
        }else{
            return (['code'=>0,'msg'=>'添加失败']);
        }
	}

	public function rolelist(){
		$data=DB::table('role')->paginate(3);
		return view("role.role_show",['data'=>$data]);
	}
	
	public function roledel(Request $request){
		$id=$request->input('id');
		$res=DB::table('role')->where('role_id',$id)->delete();
		if($res){
            return (['code'=>1,'msg'=>'删除成功']);
        }else{
            return (['code'=>0,'msg'=>'删除失败']);
        }
	}
}

?>