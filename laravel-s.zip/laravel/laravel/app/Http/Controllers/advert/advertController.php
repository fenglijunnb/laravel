<?php

namespace App\Http\Controllers\advert;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class advertController extends Controller
{
	//广告添加页面
   	public function advert(){
   			return view('advert.advert');
   	}

   	//广告添加
   	public function advert_add(Request $request){
   			$data = $request->input();
   			$res = DB::table('advert')->insert($data);
   			if($res){
   				return 1;
   			}else{
   				return 0;
   			}
   	}

   	//广告展示
   	public function advertlist(){

   		$arr = DB::table('advert')->paginate(5);
   		return view('advert.advertlist',['arr'=>$arr]);
   	}

   	//广告删除
   	public function advert_del(Request $request){
        $id = $request->input('id');
        $where = [
                'advert_id'=>$id,
            ];
        $data = [
                'is_del'=>0
            ];
        $res = DB::table('advert')->where($where)->update($data);
        if($res){
            return 1;
        }else{
            return 0;
        }
    }

    public function advert_a(){
      $where = [
          'is_del'=>1,
          'default'=>1
      ];
      $data = DB::table('advert')->where($where)->get();
      return $data;
    }

    public function advert_default(Request $request){
        $default = $request->input('default');
        $id = $request->input('id');
        if($default==1){
          $data = [
              'default'=>2
          ];
          $res = DB::table('advert')->update($data);
          if($res){
            return 1;
          }
        }else{
          $datas = [
              'default'=>2
          ];
          DB::table('advert')->update($datas);
          $where = [
              'advert_id'=>$id
          ];
          $data = [
              'default'=>1
          ];
          $res =  DB::table('advert')->where($where)->update($data);
          if($res){
            return 1;
          }
        }
    }
}
