<?php

namespace App\Http\Controllers\attr;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class AttrController extends Controller
{
    //属性添加
    public function attradd(){
        $typeList=DB::table('type')->get()->toArray();
        return view('attr.attr',['typeList'=>$typeList]);
    }
    //属性添加执行
    public function attr_do( Request $request ){
        $attr_name = $request -> input( 'attr_name' );
        $type_id = $request -> input( 'type_id' );
        $attr_input_type = $request -> input( 'attr_input_type' );
        $attr_type = $request -> input( 'attr_type' );
        $attr_value = $request -> input( 'attr_value' );
        $arr = [
            'attr_name' => $attr_name,
            'type_id' => $type_id,
            'attr_input_type' => $attr_input_type,
            'attr_type' => $attr_type,
            'attr_values' => $attr_value,
            'attr_status' => 1,
        ];
        $res = DB::table( 'attribute' ) -> insert( $arr );
        if( $res ){
            $arr = [
                'status' => 0,
                'msg' => "商品属性添加成功"
            ];
            return $arr;
        }else{
            $arr = [
                'status' => 1,
                'msg' => "商品属性添加失败"
            ];
            return $arr;
        }
    }
    //属性展示
    public function attr_show(){
        $attrList = DB::table( 'attribute' )
            -> join( 'type as t' , 'attribute.type_id','=','t.type_id' )
            ->paginate(10);
        return view("attr.attrshow") -> with(['attrList' => $attrList]);
    }
    //属性删除
    public function attr_del( Request $request ){
        $attr_id = $request -> input('attr_id');
        $where = [
            'attr_id' => $attr_id
        ];
        $update = [
            'attr_status' => 2,
        ];
        $res = DB::table( 'attribute' ) -> where( $where ) -> update( $update );
        if( $res ){
            $arr = [
                'status' => 0,
                'msg' => "商品属性删除成功"
            ];
            return $arr;
        }else{
              $arr = [
                'status' => 1,
                'msg' => "商品属性删除失败"
            ];
            return $arr;
        }
    }
    //属性修改视图
    public function attr_update( Request $request ){
        $typeList = DB::table( 'type' ) -> get();
        $attr_id = $request -> input('attr_id');
        $where = [
            'attr_id' => $attr_id
        ];
        $attrList = DB::table( 'attribute' ) -> where( $where ) -> first();
        return view("attr.attrupdate") -> with( ['typeList' => $typeList , 'attrList' => $attrList] );

    }
    //属性修改执行
    public function attr_update_do( Request $request ){
        $attr_id = $request -> input( 'attr_id' );
        $attr_name = $request -> input( 'attr_name' );
        $type_id = $request -> input( 'type_id' );
        $attr_input_type = $request -> input( 'attr_input_type' );
        $attr_type = $request -> input( 'attr_type' );
        $attr_value = $request -> input( 'attr_value' );
        $where = [
            'attr_id' => $attr_id
        ];
        $update = [
            'attr_name' => $attr_name,
            'type_id' => $type_id,
            'attr_input_type' => $attr_input_type,
            'attr_type' => $attr_type,
            'attr_values' => $attr_value,
        ];
        $res = DB::table( 'attribute' ) -> where( $where ) -> update( $update );
        if( $res ){
            $arr = [
                'status' => 0,
                'msg' => "商品属性修改成功"
            ];
            return $arr;
        }else{
            $arr = [
                'status' => 1,
                'msg' => "商品属性修改失败"
            ];
            return $arr;
        }
    }
}
