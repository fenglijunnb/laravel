<?php

namespace App\Http\Controllers\cate;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\model\Cate;
class CateController extends Controller{
    public function cb(){
        $arr = file_get_contents("http://47.107.93.29:8080/getInfo");
        $data = file_get_contents("http://47.107.93.29:8080/brandInfo");
        $arr = json_decode($arr,true);
        $data = json_decode($data,true);
        return view('cate/cate',['arr'=>$arr,'data'=>$data]);
    }
    public function cate_add(Request $request){
        $data = $request->input();
        $where=[
            'cate_id'=>$data['cate_id'],
            'brand_id'=>$data['brand_id']
        ];
        $arr=Cate::where($where)->first();
        if(empty($arr)){
            $data['time']=time();
            $res = Cate::insert($data);
            if($res){
                return json_encode(['code'=>0,'msg'=>'添加成功']);
            }else{
                return json_encode(['code'=>1,'msg'=>'添加失败']);
            }
        }else{
            return json_encode(['code'=>2,'msg'=>'已经有了']);
        }


    }
    public function catelist(){
        $where=[
            'status'=>1
        ];
        $data=DB::table('cate_brand')
            ->join('category', 'category.cate_id', '=', 'cate_brand.cate_id')
            ->join('brand', 'brand.brand_id', '=', 'cate_brand.brand_id')
            ->where($where)
            ->paginate(5);
        return view('cate.catelist',['data'=>$data]);
    }
    public function cate_del(Request $request){
        $id=$request->input('id');
        $arr=[
            'status'=>0
        ];
        $data=Cate::where('id',$id)->update($arr);
        if($data){
            return json_encode(['code'=>0,'msg'=>'删除成功']);
        }else{
            return json_encode(['code'=>1,'msg'=>'删除失败']);
        }
    }
    public function cate_update(Request $request){
        $arr = file_get_contents("http://47.107.93.29:8080/getInfo");
        $data = file_get_contents("http://47.107.93.29:8080/brandInfo");
        $arr = json_decode($arr,true);
        $data = json_decode($data,true);
        $id=$request->input('id');
        $res=Cate::where('id',$id)->first();
        return view('cate.cateupdate',['arr'=>$arr,'data'=>$data,'res'=>$res]);
    }
    public function cate_updatedo(Request $request){
        $data=$request->input();
        $where=[
            'cate_id'=>$data['cate_id'],
            'brand_id'=>$data['brand_id']
        ];
        $res=Cate::where($where)->first();
        if(empty($res)){
            $data['utime']=time();
            $id=$request->input('hidden');
            unset($data['hidden']);

            $arr=Cate::where('id',$id)->update($data);
            if($arr){
                return json_encode(['code'=>0,'msg'=>'修改成功']);
            }else{
                return json_encode(['code'=>1,'msg'=>'修改失败']);
            }
        }else{
            return json_encode(['code'=>2,'msg'=>'已经有了']);
        }

    }
}
