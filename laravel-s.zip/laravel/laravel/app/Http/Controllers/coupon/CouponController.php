<?php
namespace App\Http\Controllers\Coupon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\CouponModel;
use Illuminate\Support\Facades\DB;

class CouponController extends Controller
{
    /**
     * 优惠券  视图
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function coupon(){
        return view('coupon.coupon');
    }

    /**
     * 优惠券添加执行
     * @param Request $request
     * @return false|string
     */
    public function couponadd(Request $request){
        $arr=$request->input();
        $arr['time']=time();
        $arr['start_time']=strtotime($arr['start_time']);
        $arr['end_time']=strtotime($arr['end_time']);
        if($arr['coupon_name']==''){
            return json_encode(['code'=>1,'msg'=>'名字不能为空']);
        }
        if($arr['max_price']==''){
            return json_encode(['code'=>1,'msg'=>'最大价格不能为空']);
        }
        if($arr['small_price']==''){
            return json_encode(['code'=>1,'msg'=>'最小价格不能为空']);
        }
        if($arr['money']==''){
            return json_encode(['code'=>1,'msg'=>'优惠价格不能为空']);
        }
        if($arr['score']==''){
            return json_encode(['code'=>1,'msg'=>'需要积分不能为空']);
        }
        if($arr['start_time']==''){
            return json_encode(['code'=>1,'msg'=>'开始使用时间不能为空']);
        }
        if($arr['end_time']==''){
            return json_encode(['code'=>1,'msg'=>'到期时间不能为空']);
        }
        CouponModel::insert($arr);
        return json_encode(['code'=>0,'msg'=>'添加成功']);
    }

    /**
     * 优惠券列表展示
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function couponlist(){
        date_default_timezone_set('PRC');
        $data=CouponModel::paginate(2)->toarray();
        $time=time();
        foreach ($data['data'] as $k=>$v){
            $start_time=$v['start_time'];
            $end_time=$v['end_time'];
            $id=$v['coupon_id'];
            if($time<$start_time){
                CouponModel::where('coupon_id',$id)->update(['is_show'=>0]);
            }else if($time>$start_time&&$time<$end_time){
                CouponModel::where('coupon_id',$id)->update(['is_show'=>1]);
            }else if($time>$end_time){
                CouponModel::where('coupon_id',$id)->update(['is_show'=>2]);
            }
        };
        $data=CouponModel::where('is_del',1)->paginate(2);
        return view('coupon.couponlist',['data'=>$data]);
    }

    /**
     * 优惠券删除
     * @param Request $request
     * @return array
     */
    public function coupondel(Request $request){
        $coupon_id=$request->input('id');
        $arr=[
            'is_del'=>0
        ];
        $data=CouponModel::where('coupon_id',$coupon_id)->update($arr);
        if($data){
            return json_encode(['code'=>0,'msg'=>'删除成功']);
        }else{
            return json_encode(['code'=>1,'msg'=>'删除失败']);
        }
    }

    /**
     * 优惠劵修改
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function couponupdate(Request $request){
        $id=$request->input('id');
        $data=CouponModel::where('coupon_id',$id)->first();
        $data['start_time']=date('Y-m-d H:i:s',$data['start_time']);
        $data['end_time']=date('Y-m-d H:i:s',$data['end_time']);
        return view('coupon.couponupdate',['data'=>$data]);
    }

    /**
     * 优惠劵执行修改
     * @param Request $request
     * @return false|string
     */
    public function couponupdate_do(Request $request){
        $data=$request->input();
        $data['start_time']=strtotime($data['start_time']);
        $data['end_time']=strtotime($data['end_time']);
        $id=$request->input('hidden');
        unset($data['hidden']);
        $arr=CouponModel::where('coupon_id',$id)->update($data);

        if($arr){
            return json_encode(['code'=>0,'msg'=>'修改成功']);
        }else{
            return json_encode(['code'=>1,'msg'=>'修改失败']);
        }
    }


    public function coupon_do(Request $request){
        $user_id=$request->input('user_id');
        $is_show=$request->input('is_show');
        $a=array(
            'user_id'=>$user_id,
            'is_show'=>$is_show
        );
        $coupon_id=DB::table('user_coupon')->where($a)->pluck('coupon_id')->toarray();
        $data=CouponModel::whereIn('coupon_id',$coupon_id)->get()->toarray();
        foreach ($data as $key => $value) {
            $data[$key]['start_time']=date("Y-m-d",$value['start_time']);
            $data[$key]['end_time']=date("Y-m-d",$value['end_time']);
            $data[$key]['time']=date("Y-m-d",$value['time']);
        }
        $arr = json_encode($data,256);
        return $arr;
    }

    public function getUserCoupon(Request $request){
        $user_id=$request->input('user_id');
        $data=DB::table('user_coupon')
            ->where(['user_id'=>$user_id,'is_show'=>1])
            ->join('activity_coupon','user_coupon.coupon_id','=','activity_coupon.coupon_id')
            ->get();

        if(empty($data)){
            return json_encode(['code'=>0,'data'=>'']);
        }else{
            return json_encode(['code'=>1,'data'=>$data]);
        }
    }


}