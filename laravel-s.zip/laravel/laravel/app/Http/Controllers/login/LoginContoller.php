<?php

namespace App\Http\Controllers\login;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Gregwar\Captcha\CaptchaBuilder;

class LoginContoller extends Controller
{
    //登录的展示页面
    public function adminlogin(){
        return view('login.login');
    }
    //登陆的执行方法
    public function adminlogin_do(Request $request){
        $admin_name=$request->input('admin_name');
        $password=$request->input('password');
        $code=$request->input('code');
        if($admin_name=="" || $password==""){
            echo json_encode(['code'=>2,'msg'=>'用户名或密码不能为空！']);die;
        }
//        $codeInfo = session('verifylogin');
//        if($code !== $codeInfo){
//            echo json_encode(['code'=>2,'msg'=>'验证码有误！']);die;
//        }
        $admin_pwd=md5($password);
        $admin_info=DB::table('admin')->where('admin_name',$admin_name)->first();
        if(!empty($admin_info)){
            if($admin_info->password == $admin_pwd){
                echo json_encode(['code'=>1,'msg'=>'登录成功！']);
                session(['admin_id'=>$admin_info->admin_id,'admin_name'=>$admin_info->admin_name]);
            }else{
                echo json_encode(['code'=>2,'msg'=>'登录失败！']);
            }
        }else{
            echo json_encode(['code'=>2,'msg'=>'登录失败！']);
        }
    }

    // 验证码
    public function codeImg($tmp){
        //生成验证码图片的Builder对象，配置相应属性
        $builder = new CaptchaBuilder;
        $builder->setIgnoreAllEffects(true);
        $builder->setBackgroundColor(255, 255, 255);
        //可以设置图片宽高及字体
        $builder->build($width = 150, $height = 50, $font = null);
        //获取验证码的内容
        $phrase = $builder->getPhrase();
        //把内容存入session
        session(['verifylogin'=>$phrase]);
        //生成图片
        header("Cache-Control: no-cache, must-revalidate");
        header('Content-Type: image/jpeg');
        $builder->output();
    }
}
