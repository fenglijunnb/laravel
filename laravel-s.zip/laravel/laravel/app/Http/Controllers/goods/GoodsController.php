<?php

namespace App\Http\Controllers\goods;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\model\Goods;
use App\model\attribute;
use App\model\Product;
use App\model\GoodsAttr;
use App\model\History;

class GoodsController extends Controller
{
    /**
     * 商品添加页面
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function goodsbot(){
    	$arr = file_get_contents("http://47.107.93.29:8080/getInfo");
    	$data = file_get_contents("http://47.107.93.29:8080/brandInfo");
    	$arr = json_decode($arr,true);
    	$data = json_decode($data,true);
    	return view('goods/goodsadd',['arr'=>$arr,'data'=>$data]);
    }

    /**
     * ajax图片上传/单图
     * @param Request $request
     * @return false|string
     */
    public function goodsuploadi(Request $request){
        $file = $_FILES['file'];
        $path = $file['tmp_name'];
        $newpath = "./imgg/".$file['name'];
        //dump($path);die;
        $media = move_uploaded_file($path,$newpath);
        // $media=new \CURLFile($newpath);
        if($media){
        	$error = [
        		'seccess'=>0,
        		'code'=>0,
        		'img'=>$newpath
        	];
        	return json_encode($error);
        }else{
        	$error = [
        		'seccess'=>1,
        		'code'=>1
        	];
        	return json_encode($error);
        }

    }

    /**
     * 商品信息入库
     * @param Request $request
     * @return int
     */
    public function goodsadd(Request $request){
    	$data = $request->input();
    	$goods_sn = "SN".date('YmdHis',time()).rand(1000,9999);
    	$data['goods_sn'] = $goods_sn;
    	$createtime = time();
    	$data['createtime'] = $createtime;
    	$res = Goods::insert($data);
        if($res){
            return 1;
        }else{
            return 2;
        }
    }

    /**
     * 多图上传
     * @return false|string
     */
    public function uploadview(){
        $imgarr=$_FILES;
        foreach($imgarr as $k=>$v){
            $imgurl=$v['tmp_name'];
            $path = $v['name'];
            $address="./uploads/$path";
            if(!file_exists("./uploads")){
                mkdir("./uploads");
            }
            move_uploaded_file($imgurl,$address);
            $arr[]=$address;
        }
        return json_encode($arr);
    }

    /**
     * 所有商品信息/前台接口
     * @param Request $request
     * @return false|string
     */
    public function goodsInfo(Request $request){
        $type=$request->input('type');
        $search = $request->input('search');
        if($type=='all'){   //流加载
            $page = $request->input('page');
            $where = [
                'is_show'=>1,
                'is_del'=>1
            ];
            $arr = Goods::where($where)->paginate(6)->toArray()['data'];
            $count = count($arr);
            if($count){
                $data = ['code'  => 1, 'data'  =>$arr];
                return json_encode($data,256);
            }else{
                $data = [ 'code'=>0 , 'msg'=>'没有更多了!'];
                return json_encode($data,256);
            }
        }else if($type=='new'){
            $page = $request->input('page');
            $where = [
                'is_del'=>1
            ];
            $arr = Goods::where($where)->orderBy('sale_num','desc')->paginate(6)->toArray()['data'];
            $count = count($arr);
            if($count){
                $data = ['code'  => 1, 'data'  =>$arr];
                return json_encode($data,256);
            }else{
                $data = [ 'code' =>0 , 'msg'=>'没有更多了!'];
                return json_encode($data,256);
            }
        }else if($type=='pricex'){   //价格 降序
            $page = $request->input('page');
            $where = [
                'is_show'=>1
            ];
            $arr = Goods::where($where)->orderBy('goods_price','desc')->paginate(6)->toArray()['data'];
            $count = count($arr);
            if($count){
                $data = ['code'  => 1, 'data'  =>$arr];
                return json_encode($data,256);
            }else{
                $data = [ 'code'=>0 , 'msg'=>'没有更多了!'];
                return json_encode($data,256);
            }
        }else if($type=='prices'){   //价格 升序
            $page = $request->input('page');
            $where = [
                'is_show'=>1
            ];
            $arr = Goods::where($where)->orderBy('goods_price','asc')->paginate(6)->toArray()['data'];
            $count = count($arr);
            if($count){
                $data = ['code'  => 1, 'data'  =>$arr];
                return json_encode($data,256);
            }else{
                $data = [ 'code'=>0 , 'msg'=>'没有更多了!'];
                return json_encode($data,256);
            }
        }else if($type=='search'){
            $page = $request->input('page');
            $arr = Goods::where('goods_name','like',"%$search%")->paginate(6)->toArray()['data'];
            $count = count($arr);
            if ($count) {
                $data = ['code' => 1, 'data' => $arr];
                return json_encode($data, 256);
            } else {
                $data = ['code' => 0, 'msg' => '没有更多了!'];
                return json_encode($data, 256);
            }
        }else{
            $page = $request->input('page');
            $where = [
                'is_show'=>1,
                'is_del'=>1
            ];
            $arr = Goods::where($where)->paginate(6)->toArray()['data'];
            $count = count($arr);
            if ($count) {
                $data = ['code' => 1, 'data' => $arr];
                return json_encode($data, 256);
            } else {
                $data = ['code' => 0, 'msg' => '没有更多了!'];
                return json_encode($data, 256);
            }
        }
    }

    /**
     * 商品展示
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function goodslist(){
        $where = [
            'is_show'=>1,
            'is_del'=>1
        ];
        $arr = Goods::where($where)
        ->join('brand','brand.brand_id','=','goods.brand_id')
        ->join('category','category.cate_id','=','goods.cate_id')
        // ->join('activity','activity.ativity_id','=','goods.activity_id')
        ->paginate(5);
        foreach($arr as $k=>$v){
            if($v['activity_id']!=0){
                $da = DB::table('activity')->where('activity_id','=',$v['activity_id'])->get();
                foreach ($da as $key => $value) {
                if($value->activity_id==$v['activity_id']){
                    
                    $v['name']=$value->name;
                }
            }
            }
            
        }
       // dump($arr);die;
        return view('goods.goodslist',['arr'=>$arr]);
    }

    /**
     * sku默认页面
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function goods_attr(Request $request){
        $goods_id=$request->input('id');
        $arr=DB::table('goods_attr')->where('goods_id',$goods_id)->get()->toArray();
        foreach($arr as $v){
            $type_id[]=$v->type_id;
        }
        if(!empty($type_id)){
            $data=DB::table('type')->whereIn('type_id',$type_id)->get()->toArray();
        }else{
            $data=DB::table('type')->get()->toArray();
        }
        return view('goods.goods_attr_show',['data'=>$data,'goods_id'=>$goods_id]);

    }

    /**
     * 获取att的属性
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function getAttribute(Request $request){
        $type_id=$request->input('type_id');
        $data=DB::table('attribute')->where('type_id',$type_id)->get()->toArray();
        if($data){
            foreach($data as $k=>$v){
                if($v->attr_values){
                    $data[$k]->attr_values=explode("\r\n",trim($v->attr_values));
                }
            }
        }
        return view('goods.goods_attr',['data'=>$data]);
    }

    /**
     * 添加属性
     * @param Request $request
     * @return array
     */
    public function getattrdo(Request $request){
        $data=$request->input();
        $goods_id=$data['hidden'];
        $goods_type=$data['goods_type'];
        $attr_values_list=$data['attr_value_list'];
        if(!empty($attr_price_list)){
            $attr_price_list=$data['attr_price_list'];
        }else{
            $attr_price_list=0;
        }
        $attrInsert=[];
        foreach($attr_values_list as $k=>$v){
            if(!empty($v)){
                if(is_array($v)){
                    foreach($v as $key=>$val){
                        $attrInsert[]=[
                            'goods_id'=>$goods_id,
                            'attr_id'=>$k,
                            'attr_value'=>$val,
                            'attr_price'=>$attr_price_list[$k][$key],
                            'type_id'=>$goods_type
                        ];
                    }
                }else{
                    $attrInsert[]=[
                        'goods_id'=>$goods_id,
                        'attr_id'=>$k,
                        'attr_value'=>$v,
                        'attr_price'=>0,
                        'type_id'=>$goods_type
                    ];
                }
            }
        }
        $res=DB::table('goods_attr')->insert($attrInsert);
        if($res){
            return (['code'=>1,'msg'=>'添加成功']);
        }else{
            return (['code'=>0,'msg'=>'添加失败']);
        }
    }

    /**
     * 所有商品详情/前台接口
     * @param Request $request
     * @return false|string
     */
    function goodsDetail(Request $request){
        $goods_id = $request->input('goods_id');
        $where = [
            'is_show'=>1,
            'is_del'=>1,
           'goods_id'=>$goods_id
        ];
        $arrInfo= Goods::where($where)->first();
        $arr = json_encode($arrInfo,256);

        //浏览历史
        $user_id = $request->input('user_id');
        if(empty($user_id)){
            //游客
            $clicks=DB::table('goods')->where('goods_id',$goods_id)->value('clicks');
            $click=$clicks+1;
            DB::table('goods')->where('goods_id',$goods_id)->update(['clicks'=>$click]);
        }else{
            $a=array(
                'user_id'=>$user_id,
                'goods_id'=>$goods_id
            );
            $sel=DB::table('history')->where($a)->first();
            if($sel){
                $create_time=time();
                DB::table('history')->where($a)->update(['create_time'=>$create_time]);
            }else{
                $time=time();
                $history=array(
                    'user_id'=>$user_id,
                    'goods_id'=>$goods_id,
                    'create_time'=>$time
                );
                $data=DB::table('history')->insert($history);
            } 
        }
        return $arr;
    }

    /**
     * 货品展示
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function product(Request $request){
        $goods_id= $request->input('id');
        $goods_info=DB::table('goods')->where('goods_id',$goods_id)->select('goods_id','goods_name','goods_sn')->first();
        $attr_id=DB::table('goods_attr')->where('goods_id',$goods_id)->pluck('attr_id');
        $attr_id=DB::table('attribute')->whereIn('attr_id',$attr_id)->where('attr_input_type',1)->pluck('attr_id');
        $attr_name=DB::table('attribute')->whereIn('attr_id',$attr_id)->where('attr_input_type',1)->pluck('attr_name');
        $attr_info=DB::table('goods_attr')->where('goods_id',$goods_id)->whereIn('attr_id',$attr_id)->get();
        $product_info=DB::table('product')->where('goods_id',$goods_id)->get();
//        dump($product_info);die;
        foreach($product_info as  $k=>$v){
            $goods_attr_id=explode(',',$v->goods_attr_id);
            $product_info[$k]->goods_attr_id=DB::table('goods_attr')->whereIn('goods_attr_id',$goods_attr_id)->pluck('attr_value');
        }
        $attr_values=[];
        $attr_price=[];
        foreach($attr_info as $k=>$v){
            $attr_values[$v->attr_id][$v->goods_attr_id]=$v->attr_value;
            $attr_price[$v->attr_id][$v->goods_attr_id]=$v->attr_price;
        }
//        print_r($product_info);die;
        return view('goods.sku',['attr_values'=>$attr_values,'attr_name'=>$attr_name,'goods_info'=>$goods_info,'product_info'=>$product_info]);

    }

    /**
     * 货品添加
     * @param Request $request
     */
    public function productdo(Request $request){
        DB::beginTransaction();
        $data=$request->input();
        $attr=$data['attr'];
        $goods_id=$data['goods_id'];
        $product_number=$data['product_number'];
        $count=count($data['product_number']);
        $goods_info=DB::table('goods')->where('goods_id',$goods_id)->first();
        $goods_sn=$goods_info->goods_sn;
        for($i=0;$i<$count;$i++){
            $productInsert=[
                'goods_attr_id'=>implode(',',array_column($attr,$i)),
                'goods_id'=>$goods_id,
                'product_num' => $product_number[$i]
            ];
            $product_id=DB::table('product')->insertGetId($productInsert);
            if($product_id){
                $product_sn = $goods_sn . '_' . $product_id;
                $res=DB::table('product')->where('product_id',$product_id)->update(['product_sn'=>$product_sn]);

            }
        }
        $goods_num=array_sum($product_number);
        $res=DB::table('goods')->where('goods_id',$goods_id)->update(['goods_num'=>$goods_num]);
        if($res){
            DB::commit();
            echo json_encode(['code'=>1,'msg'=>'添加成功']);
        }else{
            DB::rollBack();
            echo json_encode(['code'=>0,'msg'=>'添加失败！']);
        }


    }

    /**
     * 商品删除
     * @param Request $request
     * @return int
     */
    public function goods_del(Request $request){
        $id= $request->input('id');
        $where= [
                'goods_id'=>$id,
            ];
        $data= [
                'is_del'=>0
            ];
        $res= Goods::where($where)->update($data);
        if($res){
            return 1;
        }else{
            return 0;
        }
    }

    public function goods_up(Request $request){
        $id = $request->input('id');
        $arr = file_get_contents("http://47.107.93.29:8080/getInfo");
        $data = file_get_contents("http://47.107.93.29:8080/brandInfo");
        $arr = json_decode($arr,true);
        $data = json_decode($data,true);
        $where = [
            'goods_id'=>$id
        ];
        $goodsInfo = Goods::where($where)->get()->toArray();
        $img = $goodsInfo[0]['goods_imgs'];
        $imgs = explode(',', $img);                    
        return view('goods.goods_up',['goodsInfo'=>$goodsInfo[0],'arr'=>$arr,'data'=>$data,'imgs'=>$imgs]);
    }

    public function goodsup(Request $request){
        $data = $request->input();
        $where = [
            'goods_id'=>$data['goods_id'],
        ];
        $data['update_time'] = time();
        $res = Goods::where($where)->update($data);
        if($res){
            return 1;
        }else{
            return 0;
        }
    }

    /**
     * 全部商品列表
     * @return false|string
     */
    public function goodsInfos(){
        $where = [
            'is_show'=>1,
            'is_del'=>1
        ];
        $arrInfo = Goods::where($where)->get()->toArray();
        $arr = json_encode($arrInfo,256);
        return $arr;   
    }

    /**
     * 展示浏览历史
     * @param Request $request
     * @return false|string
     */
    public function history(Request $request){
        $user_id=$request->input('user_id');
        if(empty($user_id)){
            //游客展示goods
            $arrInfo=DB::table('goods')->where('clicks','!=',0)->orderBy('clicks','desc')->get();
        }else{
            //用户
            $arrInfo=DB::table('history')->join('goods','history.goods_id','=','goods.goods_id')->where('user_id',$user_id)->get();
        }
        $arr = json_encode($arrInfo,256);
        // print_r($arr);die;
        return $arr;
    }

    /**
     * 清空浏览记录
     * @param Request $request
     */
    public function historyDel(Request $request){
        $user_id=$request->input('user_id');
            $data=History::where('user_id',$user_id)->get();
            $id=[];
            foreach($data as $k=>$v){
                $goods_id=$v->goods_id;
                $id[]=$goods_id;
            }
            $arr=DB::table('history')->where('user_id',$user_id)->whereIn('goods_id',$id)->delete();
            if($arr){
                return json_encode(['code' => 1, 'msg' => '清空成功']);
            }else{
                return json_encode(['code' => 2, 'msg' => '清空失败']);
            }
    }

    /**
     * 商品详情规格的接口
     */
    public function search(Request $request){
        $goods_id = $request->input('goods_id');
        $goodsinfo = DB::table('goods')->where('goods_id',$goods_id)->first();
        if($goodsinfo->goods_imgs){
            $goodsinfo->goods_imgs=explode(',',$goodsinfo->goods_imgs);
        }
        $goodsinfo->createtime = date('Y-m-d H:i:s',$goodsinfo->createtime);
        $goods_attr = DB::table('product')->where('goods_id',$goods_id)->pluck('goods_attr_id');
        if(count($goods_attr)!=0){
            $data = [];
            foreach($goods_attr as $v){
                $data[] = DB::table('goods_attr')
                    ->whereIn('goods_attr_id',explode(',',$v))
                    ->get();
            }
            $arr=[];
            foreach($data as $k=>$v){
                $arr[$k]="";
                foreach($v as $kk=>$vv){
                    $arr[$k] .= $vv->attr_value.' ';
                }
            }
            $price = [];
            foreach($data as $k=>$v){
                $price[$k]=0;
                foreach($v as $kk=>$vv){
                    $price[$k] += $vv->attr_price;
                }
            }
            $info=[];
            foreach($data as $k=>$v){
                $info[$k]['attr_price']=$price[$k];
                $info[$k]['goods_attr_id']=$goods_attr[$k];
                $info[$k]['attr_value']=$arr[$k];
            }
        }else {
            $info = "";
        }
        return json_encode(['goodsInfo'=>$goodsinfo,'attrInfo'=>$info],256);
    }

    public function length_good(){
        $data=Goods::orderBy('clicks','desc')->limit(4)->get();
        return $data;
    }

}