<?php

namespace App\Http\Controllers\type;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class TypeController extends Controller
{
    //类型展示
    public function type(){
        $arr=DB::table('type')->paginate(5);
        return view('type.type',['arr'=>$arr]);
    }
    //类型添加
    public function typeadd(){
        return view('type.typeadd');
    }
    //类型添加执行
    public function typedo(Request $request){
        $type_name=$request->input('type_name');
        if(!$type_name){
            echo "类型名称不能为空";die;
        }
        $arr=array(
            'type_name'=>$type_name
        );
        $res=DB::table('type')->insert($arr);
        if($res){
            return 1;
        }else{
            return 2;
        }
    }
    //类型删除
    public function typedelete(Request $request){
        $type_id=$request->input('type_id');
        $res=DB::table('type')->where('type_id',$type_id)->delete();
        if($res){
            return 1;
        }else{
            return 2;
        }
    }
    //类型修改
    public function typeupdate(Request $request){
        $type_id=$request->input('type_id');
        $arr=DB::table('type')->where('type_id',$type_id)->first();
        return view('type.typeupdate',['arr'=>$arr]);
    }
    //类型修改执行
    public function typeupddo(Request $request){
        $type_id=$request->input('type_id');
        $type_name=$request->input('type_name');
        $arr=DB::table('type')->where('type_id',$type_id)->update(['type_name'=>$type_name]);
        if($arr){
            return 1;
        }else{
            return 2;
        }
    }
}
