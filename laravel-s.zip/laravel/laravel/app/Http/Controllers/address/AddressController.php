<?php

namespace App\Http\Controllers\address;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class AddressController extends Controller
{
    /**
     * @param Request $request
     * @return mixed
     * 三级联动的接口
     */
    public function getregion(Request $request){
        $pid = $request->input('parent_id',1);
        $regin =DB::table('region')->where('parent_id',$pid)->get();
        $data = json_decode($regin,1);
        return $data;

    }
    /**
     * @param Request $request
     * @return mixed
     * 三级联动的接口
     */
    public function selregion(){
        $regin = DB::table('region')->get();
        $data = json_decode($regin,1);
        return $data;
    }
    /**
     * 用户地址的添加的执行方法
     */
    public function addressAdd(Request $request){
        $address=$request->input('address');
        $address_name = $request->input('address_name');
        $user_id = $request->input('user_id');
        $address_detail = $request->input('address_detail');
        $province = $request->input('province');
        $city = $request->input('city');
        $district = $request->input('district');
        $consignee_tel = $request->input('consignee_tel');
        $is_address = $request->input('is_address');
        if($is_address==1){
            DB::table('user_address')->where('user_id',$user_id)->update(['is_address'=>0]);
        }
        $info = array(
            'address_name'=>$address_name,
            'address_detail'=>$address_detail,
            'address_province'=>$province,
            'address_city'=>$city,
            'address_district'=>$district,
            'address_tel'=>$consignee_tel,
            'is_address'=>$is_address,
            'user_id'=>$user_id,
            'address'=>$address,
            'status'=>1
        );
        $res = DB::table('user_address')->insert($info);
        if($res){
            return 1;   //添加成功
        }else{
            return 2;   //添加失败
        }
    }

    /**
     * @param Request $request
     * @return int
     * 修改地址
     */
    public function upaddress(Request $request){
        $address=$request->input('address');
        $consignee_name = $request->input('consignee_name');
        $detailed_address = $request->input('detailed_address');
        $province = $request->input('province');
        $city = $request->input('city');
        $district = $request->input('district');
        $consignee_tel = $request->input('consignee_tel');
        $is_address = $request->input('is_address');
        $id = $request->input('id');
        $user_id=$request->input('user_id');
        if($is_address==1){
            DB::table('user_address')->where('id','!=',$id)->update(['is_address'=>0]);
        }
        $info = array(
            'address_name'=>$consignee_name,
            'address_detail'=>$detailed_address,
            'address_province'=>$province,
            'address_city'=>$city,
            'address_district'=>$district,
            'address_tel'=>$consignee_tel,
            'address'=>$address,
            'is_address'=>$is_address,

        );
        $res = DB::table('user_address')->where('id',$id)->update($info);
        if($res){
            return 1;   //修改成功
        }else{
            return 2;   //修改失败
        }
    }

    /**
     * @param Request $request
     * @return int
     * 防非法登录
     */
    public function addressGet(Request $request){
        $name=$request->input('user_id');
        if($name){
                $info = DB::table('user_address')->where(['user_id'=>$name])->get();
                if(count($info)>0){
                    $arr=[];
                    foreach($info as $k=>$v){
                        $arr[$k]=$v;
                        $province=DB::table('region')->where('region_id',$v->address_province)->value('region_name');
                        $city=DB::table('region')->where('region_id',$v->address_city)->value('region_name');
                        $district=DB::table('region')->where('region_id',$v->address_district)->value('region_name');
                        $arr[$k]->addressInfo=$province.$city.$district.$v->address_detail;
                        $arr[$k]->userInfo=$v->address_name." ".$v->address_tel;
                    }
                    echo json_encode(['code'=>1,'data'=>$arr]);
                }else{
                    echo json_encode(['code'=>0,'msg'=>'暂无地址，请添加！','data'=>'']);
                }
        }else{
            return 2;   //请先登陆
        }
    }

    /**
     * @param Request $request
     * 删除地址
     */
    public function addressDel(Request $request){
        $id = $request->input('add_id');
        $user_id = $request->input('user_id');
        $info = DB::table('user_address')->where('user_id',$user_id)->where('id',$id)->delete();
        if($info){
            return 1;//删除成功
        }else{
            return 2;//删除失败
        }
    }

}
