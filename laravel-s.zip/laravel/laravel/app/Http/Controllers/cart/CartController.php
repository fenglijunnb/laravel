<?php

namespace App\Http\Controllers\cart;

use App\model\CartModel;
use App\model\GoodsAttr;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    /**
     * 商品加入购物车
     * @param Request $request
     * @return false|string
     */
    public function addCart(Request $request){
       $user_id=$request->input('user_id');
       $goods_attr=$request->input('goods_attr');
       $price=$request->input('price');
        if(empty($user_id)){
            return json_encode(['code'=>3,'msg'=>'您还没有登录，请先登录']);
        }else{
            $goods_id=$request->input('goods_id');
            $where=[
                'goods_id'=>$goods_id,
            ];

            $arr=DB::table('goods')->where($where)->first();
            if(!empty($goods_attr)){
                $info=getGoodsAttr($arr->goods_id,$goods_attr);
                $info->goods_num=$arr->goods_num;
                $goodsInfo[]=$info;
            }else{
                $goodsInfo[]=$arr;
            }
            foreach ($goodsInfo as $k=>$v){
                $attr=$v->attr_value;
            }
            $goods_num=$arr->goods_num;
            $is_show=$arr->is_show;
            $goods_price=$arr->goods_price;

            if($goods_num<1){
                return json_encode(['code'=>1,'msg'=>'商品库存不足']);
            }else if($is_show!=1){
                return json_encode(['code'=>1,'msg'=>'商品已下架，再去看看别的吧']);
            }
            if(!empty($goods_attr)){
                $goods_price = $price;
            }
            $whereInfo=[
                'goods_id'=>$goods_id,
                'user_id'=>$user_id
            ];
            $cartInfo=CartModel::where($whereInfo)->first();
            if(!empty($cartInfo)){
                $buy_num=1;
                $num=$cartInfo->buy_number;
                $cart_status=$cartInfo->cart_status;
                if($cart_status==2){
                    $updateInfo=[
                        'cart_status'=>1,
                        'buy_number'=>1
                    ];
                }else{
                    $updateInfo=[
                        'buy_number'=>$num+$buy_num,
                        'update_time'=>time()
                    ];
                }
                $data=CartModel::where($whereInfo)->update($updateInfo);
                }else{
                    $dataInfo=[
                        'goods_id'=>$goods_id,
                        'user_id'=>$user_id,
                        'buy_number'=>1,
                        'goods_prices'=>$goods_price,
                        'cart_status'=>1,
                        'attr_values'=>$goods_attr,
                        'create_time'=>time()
                    ];
                    $data=CartModel::insert($dataInfo);
                }
            if($data){
                return json_encode(['code'=>2,'msg'=>'宝贝已成功加入购物车!']);
            }
        }
    }
    /**
     * 加入收藏
     * @param Request $request
     * @return false|string
     */
    public function addCollection(Request $request){
        $user_id=$request->input('user_id');
        if(empty($user_id)){
            return json_encode(['code'=>3,'msg'=>'您还没有登录，请先登录']);
        }else{
           $goods_id=$request->input('goods_id');
            $where=[
                'goods_id'=>$goods_id
            ];
            $arr=DB::table('goods')->where($where)->first();
            $goods_num=$arr->goods_num;
            $goods_price=$arr->goods_price;
            $goods_name=$arr->goods_name;
            if($goods_num<1){
                return json_encode(['code'=>1,'msg'=>'商品库存不足']);
            }

            $whereInfo=[
                'goods_id'=>$goods_id
            ];
            $collectionInfo=DB::table('collection')->where($whereInfo)->first();
            if(!empty($collectionInfo)){
                return json_encode(['code'=>1,'msg'=>'商品已在收藏中']);
            }else{
                $dataInfo=[
                    'goods_id'=>$goods_id,
                    'user_id'=>$user_id,
                    'goods_name'=>$goods_name,
                    'goods_price'=>$goods_price,
                    'create_time'=>time(),
                ];
                $data=DB::table('collection')->where($where)->insert($dataInfo);
                if($data){
                    return json_encode(['code'=>2,'msg'=>'收藏成功']);
                }
            }
        }

    }

    /**
     * 购物车列表
     * @return false|string
     */
    public function cartShow(Request $request){
        $user_id = $request->input('id');
        $goods_id=$request->input('goods_id');
        $cart_id=$request->input('cart_id');
        $cart_id = explode(',',$cart_id);
        if(empty($user_id)){
            $data=CartModel::whereIn('cart_id',$cart_id)
                ->join('goods','cart.goods_id','=','goods.goods_id')
                ->get();
        }else{
            $where=[
                'user_id'=>$user_id,
                'cart_status'=>1
            ];
            $data=CartModel::where($where)
                ->join('goods','cart.goods_id','=','goods.goods_id')
                ->get()->toArray();
                foreach ($data as $k=>$v) {
                    $goodsId=$v['goods_id'];
                    $arr=CartModel::where('user_id',$user_id)->where('goods_id',$goodsId)->value('attr_values');
                    if(!empty($arr)){
                        $goods_attr_id=explode(',',$arr);
                        $attr_value=GoodsAttr::whereIn('goods_attr_id',$goods_attr_id)->pluck('attr_value')->toArray();
                        $attr_values=implode(',',$attr_value);
                        $data[$k]['attr_value']=$attr_values;
                     }
            }
        }
        return json_encode($data,256);
    }

    /**
     * 购物车删除和批删
     * @param Request $request
     * @return false|string
     */
    public function cartdel(Request $request){
        $goods_id=$request->input('id');
        $user_id=$request->input('user_id');
        $goodsId=explode(',',$goods_id);
        $where=[
            'user_id'=>$user_id
        ];
        $cartupdate=[
            'cart_status'=>2,
            'buy_number'=>0,
            'update_time'=>time()
        ];
        $res = CartModel::where($where)->whereIn('goods_id',$goodsId)->update($cartupdate);
        if($res){
            return json_encode(['code'=>1,'msg'=>'删除成功']);
        }else{
            return json_encode(['code'=>2,'msg'=>'删除失败']);
        }
    }

    /**
     * 我的收藏
     * @return false|string
     */
    public function collection(Request $request){
        $user_id = $request->input('user_id');
        $where=[
            'status'=>1,
            'user_id'=>$user_id
        ];
        $arrInfo=DB::table('collection')->join('goods','collection.goods_id','=','goods.goods_id')->where($where)->get();
        $arr=json_encode($arrInfo,256);
        return $arr;
    }

    /**
     * 购物车数量
     * @param Request $request
     * @return mixed
     */
    public function count(Request $request){
        $user_id = $request->input('id');
        $where=[
            'user_id'=>$user_id,
            'cart_status'=>1
        ];
        $num = DB::table('cart')->where($where)->count();
        return $num;
    }

    /**
     * 取消收藏
     * @param Request $request
     * @return false|string
     */
    public function collectionDel(Request $request)
    {
        $goods_id = $request->input('goods_id');
        $user_id = $request->input('user_id');
        $where = [
            'goods_id' => $goods_id,
            'user_id' => $user_id,
        ];
        $updateInfo = [
            'status' => 2
        ];
        $res = DB::table('collection')->where($where)->update($updateInfo);
        if ($res) {
            return json_encode(['code' => 1, 'msg' => '取消收藏成功']);
        } else {
            return json_encode(['code' => 2, 'msg' => '取消收藏失败']);
        }
    }

    /**
     * 收藏数量
     * @param Request $request
     * @return mixed
     */
    public function num(Request $request){
        $user_id=$request->input('user_id');
        $num=Db::table('collection')->where('user_id',$user_id)->count();
        return $num;
    }

    /**
     * 修改购物车数量
     * @param Request $request
     */
    public function cartUpdate(Request $request){
        $user_id=$request->input('user_id');
        $goods_id=$request->input('id');
        $buy_number=$request->input('buy_number');
        $where=[
            'user_id'=>$user_id,
            'goods_id'=>$goods_id
        ];
        $data=DB::table('cart')->where($where)->first();
        if($data){
            $updateInfo=[
                'buy_number'=>$buy_number
            ];
            $arr=DB::table('cart')->where($where)->update($updateInfo);
            var_dump($arr);
        }
    }
}