<?php

namespace App\Http\Controllers\upload;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class uploadcontroller extends Controller
{



public function tokens(){
	
	// 你的 APPID AK SK
	// const APP_ID = '16107400';
	// const API_KEY = 'SWmoPa5G4KGtEGSCdWFwfIVN';
	// const SECRET_KEY = 'ykDyvFTXO4rcPAYHN0yo498B4rMMVHt9';

	// $client = new AipFace(APP_ID, API_KEY, SECRET_KEY);
	$token = $this->token();
	$tokens = json_decode($token);
	$access_token =$tokens->access_token;
	return $access_token;
}
//获取access_token
public function  token(){
	$url = 'https://aip.baidubce.com/oauth/2.0/token';
    $post_data['grant_type']       = 'client_credentials';
    $post_data['client_id']      = 'SWmoPa5G4KGtEGSCdWFwfIVN';
    $post_data['client_secret'] = 'ykDyvFTXO4rcPAYHN0yo498B4rMMVHt9';
    $o = "";
    foreach ( $post_data as $k => $v ) 
    {
    	$o.= "$k=" . urlencode( $v ). "&" ;
    }
    $post_data = substr($o,0,-1);
    
    $res = $this->request_post($url, $post_data);

    return $res;
    //var_dump($res);
}

public function request_post($url='', $param = '')
{
    if (empty($url) || empty($param)) {
        return false;
    }

    $postUrl = $url;
    $curlPost = $param;
    // 初始化curl
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $postUrl);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    // 要求结果为字符串且输出到屏幕上
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    // post提交方式
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $curlPost);
    // 运行curl
    $data = curl_exec($curl);
    curl_close($curl);

    return $data;
}

public function fice_add(Request $request){
	$face = $request->input('face');
	$user_id = $request->input('user_id');
	$access_token = $this->tokens();
	$url = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/user/add?access_token=' . $access_token;
	
	$bodys = $bodys = "{\"image\":\"$face\",\"image_type\":\"BASE64\",\"group_id\":\"2225640552\",\"user_id\":\"$user_id\",\"user_info\":\"abc\",\"quality_control\":\"LOW\",\"liveness_control\":\"NONE\"}";

	$res = $this->request_post($url, $bodys);

	return $res;
}

	public function fice_seach(Request $request){
		$access_token = $this->tokens();
		$face = $request->input('face');
		$curl = "https://aip.baidubce.com/rest/2.0/face/v3/search?access_token=" . $access_token;
		$bodysa = "{\"image\":\"$face\",\"image_type\":\"BASE64\",\"group_id_list\":\"2225640552\",\"quality_control\":\"LOW\",\"liveness_control\":\"NONE\"}";
		$rest = $this->request_post($curl, $bodysa);
		$a = json_decode($rest);
		$res = $a->result->user_list;
		
		return $res;

	}
}
