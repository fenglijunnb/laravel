<?php

namespace App\Http\Controllers\order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\Order;
use App\model\Goods;
use App\model\region;
use App\model\CartModel;
use App\model\Orders_detail;
use App\model\User_score;
use Illuminate\Support\Facades\DB;

class orderController extends Controller
{
	public function order(){
		$where = [
			'status'=>1
		];
		$arr =  Order::where($where)
				->join('order_address','order_address.order_id','=','order.order_id')
				->paginate(2);

		return view('order.order',['arr'=>$arr]);
	}

    /**
     * 订单地址
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function address_order(Request $request){
    	$id = $request->input('id');
    	$address = DB::table('user_address')->where('id','=',$id)->first();
    	$address_id[] = $address->address_province;
    	$address_id[] = $address->address_city;
    	$address_id[] = $address->address_district;
    	foreach($address_id as $k=>$v){
    	$add[] = region::where('region_id','=',$v)->get()->toArray();
    	}
    	return view('order.order_address',['address'=>$address,'add'=>$add]);
    }

    public function orderc(Request $request){
        $data = $request->input('data');
    	$order_sn = 'CRM'.rand(100,999).time();
    	$create_time = time();
        $data['order_sn']=$order_sn;
        $data['create_time']=$create_time;
    	// $data = [
    	// 	'order_sn'=>$order_sn,//商品货号
    	// 	'user_id'=>'5',//用户id
    	// 	'order_amount'=>'599',//订单总价
    	// 	// 'order_pay'=>1,//支付方式，默认1，支付宝，2，微信
    	// 	// 'order_pay_status'=>1,//支付状态  1,未支付2，已支付
    	// 	// 'status'=>1,//是否取消订单，默认1，1，未取消，2，已取消
    	// 	'create_time'=>$create_time,

    	// 	'goods_id'=>[
    	// 		'0'=>2,
    	// 		'1'=>3
    	// 	],
    	// 	'cart_id'=>[
    	// 		'0'=>3,
    	// 		'1'=>4
    	// 	],
    	// 	'address_id'=>1
    	// ];
        $data['order_amount'] = ltrim($data['order_amount'],'￥');
        $data['del_time']=time()+6000;
    	$cart_id = explode(',',$data['cart_id']);
    	$res=DB::table('cart')->whereIn('cart_id',$cart_id)->update(['cart_status'=>2]);
    	$goods_id = explode(',',$data['goods_id']);
    	$address_id = $data['address_id'];
        unset($data['goods_id']);
    	unset($data['cart_id']);
    	unset($data['address_id']);
    	$order_id = Order::insertGetId($data);
    	if($order_id){
    		$datas = Order::where('order_id','=',$order_id)->get()->toArray();
	    	//dump($datas);die;
	    	$food = Goods::whereIn('goods_id',$goods_id)->get()->toarray();
	    	$catr = CartModel::whereIn('cart_id',$cart_id)->get()->toArray();
	    	foreach($food as $key=>$val){
	    		$goods = [
		    		'order_id'=>$order_id,
		    		'goods_id'=>$val['goods_id'],
		    		'order_sn'=>$order_sn,
		    		'user_id'=>$data['user_id'],
		    		'goods_price'=>$val['goods_price'],
		    		'create_time'=>time(),
		    		'goods_img'=>$val['goods_img'],
		    	];
		    	foreach($catr as $k=>$v){
		    		if($v['goods_id']==$val['goods_id']){
		    			$goods['buy_number']=$v['buy_number'];
		    		}
		    	}
		    	$s = DB::table('order_goods')->insert($goods);
	    	}

	    	if($s){
	    		$add_data = [
	    			'order_id'=>$order_id,
	    			'address_id'=>$address_id
	    		];
	    		$e = DB::table('order_address')->insert($add_data);
	    		if($e){
                    return  json_encode(['msg'=>200,'order_id'=>$order_id,'status'=>'订单创建成功']);
	    		}else{
	    			$error = [
		    			'msg'=>403,
		    			'status'=>'数据错误'
		    		];
                    return json_encode($error,256);
	    		}
	    	}else{
	    		$error = [
	    			'msg'=>402,
	    			'status'=>'数据错误'
	    		];
                return  json_encode($error,256);
	    	}
    	
    	}else{
    		$error = [
    			'msg'=>401,
    			'status'=>'数据错误'
    		];
            return json_encode($error,256);
    	}
    }

    /**
     * 订单展示
     * @param Request $request
     * @return mixed
     */
    public function order_list(Request $request){
        $status = $request->input('status');
        $uid = $request->input('uid');
        if($status==4){
            $where = [
                'user_id'=>$uid,
                'status'=>1
            ];
            $data = Order::where($where)->get();
        }else{
            $where = [
                'user_id'=>$uid,
                'order_pay_status'=>$status,
                'status'=>1
            ];
            $data = Order::where($where)->get();
        }
        return $data;
    }

    public function orderte(Request $request){
        $id = $request->input('id');
        $where = [
                'user_id'=>$id,
                'status'=>2
        ];
        $data = Order::where($where)->get();
        if($data){
            return $data;
        }
    }

    /**
     * 取消订单
     * @param Request $request
     * @return false|string
     */
    public function order_del(Request $request){
        $id = $request->input('id');
        $where = [
            'order_id'=>$id
        ];
        $data = [
            'status'=>2
        ];
        $res = Order::where($where)->update($data);
        if($res){
            $s = DB::table('order_goods')->where($where)->update($data);
            if($s){
                $error = [
                'msg'=>200,
                'success'=>"取消成功"
            ];
            return json_encode($error,true);
            }
        }else{
            $error = [
                'msg'=>201,
                'success'=>"订单不存在"
            ];
            return json_encode($error,true);
        }
    }

    /**
     * 展示订单下的商品
     * @param Request $request
     */
    public function orderGoods(Request $request){
        $order_id=$request->input('order_id');
        $user_id=$request->input('user_id');
        $where=[
            'order_id'=>$order_id,
            'user_id'=>$user_id
        ];
        $data=DB::table('order_goods')->where($where)->get();
        $id=[];
        foreach($data as $k=>$v){
            $goods_id=$v->goods_id;
            $id[]=$goods_id;
            $goodsInfo=DB::table('goods')->whereIn('goods_id',$id)->get();
        }
        $arr=json_encode($goodsInfo,256);
        return $arr;
    }

    /**
     * 取消订单
     * @param Request $request
     * @return mixed
     */
    public function order_status(Request $request){
        $order_id=$request->input('order_id');
        $arr=DB::table('order')->where('order_id',$order_id)->update(['status'=>2]);
        return $arr;
    }

    /**
     * 订单数据
     * @param Request $request
     * @return mixed
     */
    public function order_success(Request $request){
        $order_id=$request->input('order_id');
        $arr=Order::where('order_id',$order_id)->first()->toArray();
        if($arr['del_time']<time()) {
               $orderid[] = $arr['order_id'];
        }
        $arr['del_time']=date("Y-m-d H:i:s",$arr['del_time']);
        $arr['create_time']=date("Y-m-d H:i:s",$arr['create_time']);
        if(!empty($orderid)){
            $res=DB::table('order')->whereIn('order_id',$orderid)->update(['status'=>2]);
            $error = [
                'code'=>2,
                'msg'=>"订单已取消"
            ];
            return json_encode($error,256);
        }else{
            $error = [
                'code'=>1,
                'data'=>$arr
            ];
            return json_encode($error,256);
        }

    }

    /**
     * @param Request $request
     * @return false|mixed|string
     * 支付成功的接口
     */
    public function pay(Request $request){
        $order_id=$request->input('order_id');
        $user_id=$request->input('user_id');
        $data=DB::table('order')->where('order_id',$order_id)->update(['order_pay_status'=>3]);
        $goods_id=Orders_detail::where('order_id',$order_id)->get(['goods_id','buy_number'])->toarray();
        $goods_point=Goods::whereIn('goods_id',$goods_id)->pluck('score')->toarray();
        foreach($goods_id as $k=>$v){
            $user_point[]=$v['buy_number'] * $goods_point[$k];
        }
        $user_point=array_sum($user_point);
        $total_point=User_score::where('user_id',$user_id)->pluck('score')->toArray()[0];
        $point=$total_point + $user_point;
        User_score::where('user_id',$user_id)->update(['score'=>$point]);
        //减库存
        $goods_show=Goods::whereIn('goods_id',$goods_id)->get()->toarray();
        foreach($goods_id as $k=>$v){
            $res=Goods::where('goods_id',$v['goods_id'])->update(['goods_num'=>$goods_show[$k]['goods_num']-$v['buy_number']]);
            $res=Order::where('goods_id',$v['goods_id'])->update(['order_pay_status'=>3]);
        }
        if($res){
            return json_encode([
                'code'=>1,
                'msg'=>'结算成功'
            ]);
        }else{
            return json_encode([
                'code'=>2,
                'msg'=>'结算失败'
            ]);
        }
    }

}