<?php

namespace App\Http\Controllers\config;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class configController extends Controller{
	public function config(){
		return view("config.config");
	}


	public function configadd(Request $request){
		$name=$request->input('name');
		$url=$request->input('url');
        $admin_name=session('admin_name');
		$arr=array(
			'name'=>$name,
			'url'=>$url,
            'admin_name'=>$admin_name
		);
		$data=DB::table('config')->insert($arr);
		if($arr){
            return (['code'=>1,'msg'=>'添加成功']);
        }else{
            return (['code'=>0,'msg'=>'添加失败']);
        }
	}

	public function configlist(Request $request){
		$data=DB::table('config')->where('is_del',1)->paginate(3);
		return view("config.config_show",['data'=>$data]);
	}

	public function configdel(Request $request){
		$id=$request->input('id');
        $arr=[
            'is_del'=>2
        ];
        $data=DB::table('config')->where('id',$id)->update($arr);
        if($data){
            return (['code'=>1,'msg'=>'删除成功']);
        }else{
            return (['code'=>0,'msg'=>'删除失败']);
        }
	}

	public function config_update(Request $request){
        $id=$request->input('id');
        $data=DB::table('config')->where('id',$id)->first();
        return view('config.config_update',['data'=>$data]);
    }

    public function config_up(Request $request){
    	$name=$request->input('name');
    	$url=$request->input('c_url');
        $id=$request->input('hidden');
        $data=DB::table('config')->where('id',$id)->update(['name'=>$name,'url'=>$url]);
        if($data){
            return (['code'=>1,'msg'=>'修改成功']);
        }else{
            return (['code'=>0,'msg'=>'修改失败']);
        }
    }


     public function config_default(Request $request){
        $default = $request->input('default');
        $id = $request->input('id');
        if($default==1){
            $data = [
              'default'=>2
            ];
            $res = DB::table('config')->update($data);
            if($res){
              return 1;
            }
        }else{
            $datas = [
                'default'=>2
            ];
            DB::table('config')->update($datas);
            $where = [
                'id'=>$id
            ];
            $data = [
                'default'=>1
            ];
            $res =  DB::table('config')->where($where)->update($data);
            if($res){
                return 1;
            }
        }
    }
    public function friend(){
        $arr=array(
            'is_del'=>1,
            'default'=>1
        );
        $data=DB::table('config')->where($arr)->get();
        $arr=json_encode($data,256);
        return $arr;
    }



}