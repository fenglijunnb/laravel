<?php

namespace App\Http\Controllers\index;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
   public function index(){
      return view('index.index');
   }
    public function head(Request $request){
        $session = $request->session();
        $admin_id = $session->get('admin_id');
        $user_name=DB::table('admin')->where('admin_id',$admin_id)->value('admin_name');
        if(!empty($user_name)){
            return json_encode(['code'=>1,'user_name'=>$user_name]);
        }else{
            return json_encode(['code'=>2,'user_name'=>$user_name]);
        }
    }
    public function loginout(){
        session()->pull('admin_id');
        session()->pull('admin_name  ');
        return redirect('adminlogin');
    }

    public function resetpwd(){
        $admin_id=session('admin_id');
        // print_r($admin_id);exit;
        return view('index.resetpwd',['admin_id'=>$admin_id]);
    }

    public function reset(Request $request){
        $password=$request->input('password');//旧密码
        $admin_pwd=$request->input('admin_pwd');//新密码
        $a_pwd=md5($admin_pwd);
        $admin_id=$request->input('hidden');
        $pwd=DB::table('admin')->where('admin_id',$admin_id)->value('password');
        $password=md5($password);
        if($password==$pwd){
            $arr=[
                'password'=>$a_pwd
            ];
            $pwd=DB::table('admin')->where('admin_id',$admin_id)->update($arr);
            if($pwd){
                return (['code'=>1,'msg'=>'修改密码成功']);
            }else{
                return (['code'=>0,'msg'=>'修改密码失败']);
            }
        }else{
            return (['code'=>0,'msg'=>'旧密码输入错误']);
        }
    }
}
