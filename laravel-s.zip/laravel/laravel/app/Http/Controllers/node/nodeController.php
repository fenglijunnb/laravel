<?php

namespace App\Http\Controllers\node;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class nodeController extends Controller{
	public function node(){
		$data=DB::table('node')->where('pid',0)->get();
		return view("node.node",['data'=>$data]);
	}

	public function nodeadd(Request $request){
		$node_name=$request->input('node_name');
		$controller_name=$request->input('controller_name');
		$action_name=$request->input('action_name');
		$pid=$request->input('pid');
        if($node_name==''){
            return json_encode(['code'=>0,'msg'=>'节点名称不能为空']);
        }
        if($controller_name==''){
            return json_encode(['code'=>0,'msg'=>'控制器名称不能为空']);
        }
		$arr=array(
			'node_name'=>$node_name,
			'controller_name'=>$controller_name,
			'action_name'=>$action_name,
			'pid'=>$pid
		);
		$data=DB::table('node')->insert($arr);
		if($data){
            return (['code'=>1,'msg'=>'添加成功']);
        }else{
            return (['code'=>0,'msg'=>'添加失败']);
        }
	}

	public function nodelist(){
		$data = $this->nodeInfo();
        return view('node.nodelist', ['data' => $data]);
	}

	public function nodeInfo(){
        $data = DB::table('node')->get()->toArray();
        $info = nodeInfo($data);
        return $info;
    }

    public function nodedelete(Request $request){
    	$node_id = $request->input('node_id');
        $count = DB::table('node')->where('pid', $node_id)->count();
        if ($count > 0) {
            return 2;
        }
        $res =DB::table('node')->where(['node_id' => $node_id])->delete();
        if ($res) {
            return 1;
        } else {
            return 0;
        }
    }

    public function nodeupdate(Request $request){
    	$value=$request->input('value');
        $field=$request->input('field');
        $node_id=$request->input('node_id');
        $where=[
            'node_id'=>$node_id
        ];
        $data=[
            $field=>$value
        ];
        $result=DB::table('node')->where($where)->update($data);
        if($result){
            return 1;
        }else{
            return 0;
        }
    }

}