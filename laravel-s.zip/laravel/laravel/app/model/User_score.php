<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class User_score extends Model
{
    public $timestamps = false;
    public $table = 'user_score';
}
