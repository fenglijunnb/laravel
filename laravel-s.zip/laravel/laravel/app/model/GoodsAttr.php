<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class GoodsAttr extends Model
{
    public $timestamps = false;
    public $table = 'goods_attr';
}
