<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class nodeModel extends model
{
    public $timestamps = false;
    public $table = 'node';
}
