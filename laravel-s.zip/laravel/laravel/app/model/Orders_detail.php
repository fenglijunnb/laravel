<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Orders_detail extends Model
{
    //
    public $timestamps = false;
    public $table = 'order_goods';
}
