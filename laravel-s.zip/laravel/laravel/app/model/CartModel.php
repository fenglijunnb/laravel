<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class CartModel extends Model
{
    public $timestamps = false;
    public $table = 'cart';
}
