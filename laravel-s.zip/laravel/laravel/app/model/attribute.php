<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class attribute extends Model
{
    public $timestamps = false;
    public $table = 'attribute';
}
