<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Cate extends Model
{
    public $timestamps = false;
    public $table = 'cate_brand';
}
