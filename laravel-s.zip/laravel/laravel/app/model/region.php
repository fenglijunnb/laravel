<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class region extends Model
{
    public $timestamps = false;
    public $table = 'region';
}
