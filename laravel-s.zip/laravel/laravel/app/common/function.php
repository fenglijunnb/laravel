<?php
   function aa(){
       echo 11111;
   }
   //加密
function encode($str,$key){
    $strArr = str_split(base64_encode($str));
    $strCount = count($strArr);
    foreach(str_split($key) as $k => $v) {
        $strArr[$k]=$strArr[$k].$v;
    }
    $newStr = join('',$strArr);

    return $newStr;
}
//解密
function decode($str,$key){
    $strArr = str_split($str,2);
    foreach (str_split($key) as $k => $v) {
        if($strArr[$k][1] === $v){
            $strArr[$k]=$strArr[$k][0];
        }
    }
    $newInfo = join("",$strArr);
    $newInfo = base64_decode($newInfo);

    return $newInfo;
}
/**
 * 处理分类信息
 */
function cateInfo($data,$pid=0,$level=0){
    static $info=[];
    foreach($data as $k=>$v){
        if($v->pid==$pid){
            $v->level=$level;
            $info[]=$v;
            cateInfo($data,$v->cate_id,$v->level+1);
        }
    }
    return $info;
}

function nodeInfo($data,$pid=0,$level=0){
    static $info=[];
    foreach($data as $k=>$v){
        if($v->pid==$pid){
            $v->level=$level;
            $info[]=$v;
            nodeInfo($data,$v->node_id,$v->level+1);
        }
    }
    return $info;
}
function getGoodsAttr($goods_id,$goods_attr){
    $goodsinfo = DB::table('goods')->where('goods_id',$goods_id)->first();

    $data= DB::table('goods_attr')
        ->whereIn('goods_attr_id',explode(',',$goods_attr))
        ->select('attr_value','attr_price')
        ->get();

    $info=[];

    foreach($data as $k=>$v){
        $info['attr_value']="";
        $info['attr_price']=0;
    }

    foreach($data as $k=>$v){
        $info['attr_value'].=$v->attr_value.',';
        $info['attr_price']+=$v->attr_price;
    }
    $info['attr_value']=trim($info['attr_value'],',');

    $goodsinfo->attr_value=$info['attr_value'];
    $goodsinfo->attr_price=$info['attr_price'];

    return $goodsinfo;
}